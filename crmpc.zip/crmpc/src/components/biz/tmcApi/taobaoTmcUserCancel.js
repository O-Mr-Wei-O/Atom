import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';

function taobaoTmcUserCancel({query,callback,errCallback=undefined}){
    qnapi({
        api:'taobao.tmc.user.cancel',
        params:query,
        callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','取消消息服务失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoTmcUserCancel;
