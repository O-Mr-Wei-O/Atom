import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';

function taobaoTmcUserPermit({query,callback,errCallback=undefined}){
    qnapi({
        api:'taobao.tmc.user.permit',
        params:query,
        callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','开通消息服务失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoTmcUserPermit;
