import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';

let defaultFields = 'sku.properties_name,sku.properties,sku.quantity,sku.price,sku.outer_id,outer_id,property_alias,num_iid,title';
function taobaoItemSellerGet({query,callback,errCallback=undefined}){
    query.fields = query.fields ? query.fields : defaultFields;
    qnapi({
        api:'taobao.item.seller.get',
        params:query,
        callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','获取单个商品详细信息失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoItemSellerGet;
