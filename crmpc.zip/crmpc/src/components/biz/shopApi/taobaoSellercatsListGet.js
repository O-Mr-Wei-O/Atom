import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';

function taobaoSellercatsListGet({query,callback,errCallback=undefined}){
    qnapi({
        api:'taobao.sellercats.list.get',
        params:query,
        callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','获取前台展示的店铺内卖家自定义商品类目失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoSellercatsListGet;
