import {qnapi, isEmpty} from 'utils/index';
import moment from 'moment';
import ErrorDialog from 'publicComponents/errorDialog/index';

let defaultFields = 'seller_confirm,tid,order_code,seller_nick,buyer_nick,item_title,receiver_location,status,type,company_name,created,modified,is_quick_cod_order,sub_tids,is_split';

function taobaoLogisticsOrdersDetailGet({query,callback,errCallback=undefined,reflsh = false}){
    query.fields = query.fields ? query.fields : defaultFields;

        let myTag = query.tid + 'logisticsDetail';               // 标识符

        let json    = localStorage.getItem(myTag);
        let nowDate = moment().format('YYYY-MM-DD');
        if (isEmpty(json) || window.tradeType == 'dfh' ||reflsh) {
            qnapi({
              	api:'taobao.logistics.orders.detail.get',
              	params:query,
              	callback:(rsp)=>{
                    json = {
                        modify     : nowDate,
                        dataSource : rsp
                    };
                    try{
                        localStorage.setItem(myTag, JSON.stringify(json));
                    }catch(e){
                        console.warn('用户C盘可能已经满了，存储localStorage报错');
                    }

                    callback(rsp);
                },
                errCallback:(error)=>{
                    if (errCallback) {
                    	errCallback(error);
                    } else {
                        console.error(error);
                    	// ErrorDialog('温馨提示','批量查询物流订单,返回详细信息失败，请稍候再试！',JSON.stringify(error));
                    }
                }
            });
        } else {
            json = JSON.parse(json);
            if (nowDate != json.modify) {
            // if (nowDate != json.modify -  > 24 * 60 * 60 * 1000) {
                // 大于一天
                qnapi({
                  	api:'taobao.logistics.orders.detail.get',
                  	params:query,
                  	callback:(rsp)=>{
                        json = {
                            modify     : nowDate,
                            dataSource : rsp
                        };
                        //处理 localStorage满了问题
                        try{
                            localStorage.setItem(myTag, JSON.stringify(json));
                        }catch(e){
                            console.warn('用户C盘可能已经满了，存储localStorage报错');
                        }
                        callback(rsp);
                    },
                    errCallback:(error)=>{
                        if (errCallback) {
                        	errCallback(error);
                        } else {
                            console.error(error);
                        	// ErrorDialog('温馨提示','批量查询物流订单,返回详细信息失败，请稍候再试！',JSON.stringify(error));
                        }
                    }
                });
            } else {
                callback(json.dataSource);
            }
        }
}

export default taobaoLogisticsOrdersDetailGet;
