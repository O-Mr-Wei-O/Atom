import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';

/**
 * 长链接转短链接
 * @param {String}  url    [URL最大长度：256,type=url时，content传入普通的URL连接内容；]
 */
function taobaoMaQrcodeCommonCreate({url,callback,errCallback=undefined}){
    qnapi({
        api:'taobao.ma.qrcode.common.create',
        params:{
			type: 'url',
			name: 'smsurl',
			content: url,
			style: '000000',
			size: 175
		},
        callback:(rsp)=>{
			if (rsp.ma_qrcode_common_create_response) {
				rsp = rsp.ma_qrcode_common_create_response.modules.qrcode_d_o[0].short_url;
				rsp = rsp.replace(/https:\/\//, '');
			}
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            }
        }
    })
}

export default taobaoMaQrcodeCommonCreate;
