import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';
/**
 * 搜索评价信息
 * @param  {[type]}    query            查询字段
 * @param  {Function} callback          成功之后的回调函数
 * @param  {[Function]}   errCallback   失败之后的回调函数
 */
let defaultRole = 'buyer';
function taobaoTraderatesGet({query,callback,errCallback=undefined}) {
	query.role = query.role ? query.role : defaultRole;
	qnapi({
        api:'taobao.traderates.get',
        params:query,
        callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','获取评价数据失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}
export default taobaoTraderatesGet;
