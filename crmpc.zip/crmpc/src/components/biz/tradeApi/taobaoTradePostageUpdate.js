import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';

//一件免邮
function taobaoTradePostageUpdate({query,callback,errCallback=undefined}){
    qnapi({
        api : 'taobao.trade.postage.update',
        params : {
            tid  : query.tid,
            post_fee : query.post_fee
        },
       	callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','一键免邮失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoTradePostageUpdate;
