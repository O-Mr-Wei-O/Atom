import {qnapi,api,isEmpty,beacon,getServerTime} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';
import WebSql from 'components/biz/webSql/index';
//import taobaoTradesSoldIncrementGet from './taobaoTradesSoldIncrementGet';
import taobaoTradeFullinfoGet from './taobaoTradeFullinfoGet';
import moment from 'moment';

let defaultFields   = 'modified,timeout_action_time,end_time,pay_time,adjust_fee,discount_fee,consign_time,rate_status,seller_nick,shipping_type,cod_status,orders.oid,orders.oid_str,orders.outer_iid,orders.outer_sku_id,orders.consign_time,tid,tid_str,status,end_time,buyer_nick,trade_from,credit_card_fee,buyer_rate,seller_rate,created,payment,has_buyer_message,receiver_country,receiver_state,receiver_city,receiver_district,receiver_town,receiver_address,receiver_zip,receiver_name,receiver_mobile,receiver_phone,orders.timeout_action_time,orders.adjust_fee,orders.discount_fee,orders.end_time,orders.title,orders.status,orders.price,orders.payment,orders.sku_properties_name,orders.num_iid,orders.refund_id,orders.pic_path,orders.refund_status,orders.num,orders.logistics_company,orders.invoice_no,seller_flag,type,post_fee,has_yfx,yfx_fee,buyer_message,buyer_flag,buyer_memo,seller_memo,orders.seller_rate,orders.cid';
let defaultType     = 'fixed,auction,guarantee_trade,step,independent_simple_trade,independent_shop_trade,auto_delivery,ec,cod,game_equipment,shopex_trade,netcn_trade,external_trade,instant_trade,b2c_cod,hotel_trade,super_market_trade,super_market_cod_trade,taohua,waimai,nopaid,step,eticket,tmall_i18n,o2o_offlinetrade,step';

let defaultPageNo   = 1;
let defaultPageSize = 20;
/**
 * [taobao.trades.sold.get]
 * @param  {[type]}  options.query        [description]
 * @param  {[type]}  options.callback     [description]
 * @param  {[type]}  options.errCallback  [description]
 * @param  {Boolean} options.forceRefresh [默认为false  为websql做容错如果 websql出了问题 会在调一次这个强制去取淘宝数据]
 * @return {[type]}                       [description]
 */
function taobaoTradesSoldGet({query,callback,errCallback=undefined,forceRefresh = false,getIncrementGet = true}){
    if(forceRefresh != true){
        forceRefresh = localStorage.getItem('isFast') ? true : false;//缓存有值，则不读WeblSQL，因为用户关闭了订单加速
        if(window.page != 'tradeManagement') forceRefresh = true;
    }
    query.fields    = query.fields ? query.fields : defaultFields;
    query.type      = query.type ? query.type : defaultType;

    query.page_no   = query.page_no ? query.page_no : defaultPageNo;
    query.page_size = query.page_size ? query.page_size : defaultPageSize;
    // hasGetAll 0/null 没拉取过数据  1 拉取成功 2 正在拉取数据 -10000 拉取失败

    if (query.status && (query.status == 'WAIT_SELLER_SEND_GOODS' || query.status == 'WAIT_BUYER_CONFIRM_GOODS') && !forceRefresh){
        let hasGetAll = Number(localStorage.getItem('hasGetAll_' + window.userInfo.userNick));
        let now = moment().format('YYYY-MM-DD HH:mm:ss');
        let lastIncrementGetTime = localStorage.getItem('lastIncrementGetTime_' + window.userInfo.userNick);
        if(isEmpty(lastIncrementGetTime) || hasGetAll != 1 || (!isEmpty(lastIncrementGetTime) && moment(now, 'YYYY-MM-DD HH:mm:ss').diff(moment(lastIncrementGetTime, 'YYYY-MM-DD HH:mm:ss')) > 21600000)){ //上一次获取数据时间为空||拉取数据未成功||上一次更新数据的时间大于6个小时,则降级处理，并重新构建WebSql
            // console.log('降级处理');
            getSoldGetApi(query,callback,errCallback);//先调接口展现出来第一页数据
            localStorage.setItem('lastIncrementGetTime_' + window.userInfo.userNick,now);
            hasGetAll = Number(localStorage.getItem('hasGetAll_' + window.userInfo.userNick));
            if ((hasGetAll != 2 && hasGetAll != 3) && !window.isGettingData || ((hasGetAll == 2 || hasGetAll ==3) && !window.isGettingData)) {
                    window.isGettingData = true;
                    // websql 没有数据 或需要更新  要全取数据
                    //先清除
                    WebSql.tableDrop({
                        callback:(rsp)=>{
                            query.fields = defaultFields;
                            query.page_size = 60;
                            localStorage.setItem('hasGetAll_' + window.userInfo.userNick,3);
                            taobaoTradesSoldGetAll({
                                query:query,
                                callback:callback,
                                errCallback:errCallback
                            })
                        },errCallback:(error)=>{    //加入websql有问题 直接取接口
                            window.isGettingData = false;
                            localStorage.removeItem('lastIncrementGetTime_' + window.userInfo.userNick);
                            localStorage.removeItem('hasGetAll_' + window.userInfo.userNick);
                        }
                    })
            }
        }else if(hasGetAll != 1){
			//数据正在同步中,或者已经同步出错，获取API数据保证数据最新
			getSoldGetApi(query,callback,errCallback);
		}else {
            //  console.log('进入WebSQL');
            // getSoldGetApi(query,callback,errCallback);
            // // websql  有数据 直接去取
            if(query.status == "WAIT_SELLER_SEND_GOODS" && false){
                getSoldGetApi(query,callback,errCallback);
            }else{
                WebSql.orderSelect({
                    query,
                    callback:(rsp)=>{
                        // console.log('已经获取到Web数据');
                        callback(rsp);
                        let total_results = rsp.trades_sold_get_response.total_results;
                    },
                    errCallback:(error)=>{
                        console.error('获取WebSql数据报错:',error);
                        getSoldGetApi(query,callback,errCallback);
                    }
                })
            }
			if(query.page_no  == 1){
				//第一页数据，去获取增量更新
				if(window.taobaoTradesSoldIncrementGet != 1 || isEmpty(window.taobaoTradesSoldIncrementGet)){
					window.taobaoTradesSoldIncrementGet = 1;
                    setTimeout(()=>{
						//增量更新接口5秒调用一次，防止接口重复调用和接口调用频繁造成的接口报错问题
						window.taobaoTradesSoldIncrementGet = '';
					},5000);
                            window.response = '';
                            let inRsp = '';
                            taobaoTradesSoldIncrementGet({
                                    page_no:1,
                                    query:query,
                                    callback:(resps)=>{
                                        inRsp  = inRsp + JSON.stringify(resps);
                                        if(resps == 'end'){
                                            diffResponse( query , inRsp , callback , errCallback);
                                        }
                                    }
                                })

                }
			}
        }
    }else{ //除了待发货和待付款或需要强制刷新的订单按正常逻辑走
        if(query.page_no == 1 && !forceRefresh){ //比对WebSql的结果集和APi返回的结果集是否
            taobaoTradesSoldIncrementGet({
                    page_no:1,
                    query:query,
                    callback:(resps)=>{

                    }
                })

        }
        getSoldGetApi(query,callback,errCallback);
    }
}
function diffResponse( query , inRsp , callback , errCallback){
    let q  = {};
    q = {...query}
    q.page_size = 10;
WebSql.orderSelect({
    query:q,
    callback:(rp)=>{
        let newtotal = rp.trades_sold_get_response.total_results;
        q.use_has_next = false;
        q.page_size = 60;
        qnapi({
            api:'taobao.trades.sold.get',
            params:q,
            callback:(resp)=>{
                let total = resp.trades_sold_get_response.total_results;
                if(newtotal != total){// 结果认证有异常，全量更新WebSql
                     callback(resp);
                    if(total == 0){//API返回接口为0，清理当前webSql结果
                        let tids = [];
                        for (let trade of rp.trades_sold_get_response.trades.trade) {
                            tids.push(trade.tid);
                        }
                        if(tids.length > 0){
                            tids = tids.join(",");
                            WebSql.orderDelete({
                                query:{
                                  tid :tids
                                },
                                callback:(rsp)=>{
                                },
                                errCallback:(error)=>{
                                }
                            })
                        }
                    }else if(total < 61){//api结果在一页以内，判断websql结果情况，去重插入webSql
                            let trades = [];
                            if(resp.trades_sold_get_response.trades){
                                for (let trade of resp.trades_sold_get_response.trades.trade) {
                                    if(newtotal == 0){
                                        trades.push(trade);
                                    }else{
                                        let index = rp.trades_sold_get_response.trades.trade.findIndex(c=>{
                                            return c.tid == trade.tid
                                        })
                                        if(index == -1) trades.push(trade);
                                    }
                                }
                            }
                            if(trades.length>0){
                                WebSql.orderInsert({
                                    datas: trades,
                                    callback:(data)=>{
                                        //console.log('================:webSql数据有更新:==========',rsp);
                                    }
                                })
                            }
                    }else{//api结果与webSql差异过大，全量更新webSql
                        let data = {};
                        //data.inRsp = inRsp;
                        let rsj = [];
                        let a = {};
                        a.total_results = rp.trades_sold_get_response.total_results;
                        data.query = JSON.stringify(q);
                        if(rp.trades_sold_get_response.trades  && rp.trades_sold_get_response.trades.trade){
                            rp.trades_sold_get_response.trades.trade.map( c =>{
                                let json = {};
                                json.modified = c.modified;
                                json.status = c.status;
                                json.tid = c.tid;
                                rsj.push(json);
                            })
                        }
                        a.rsp = rsj;
                        let respj = [];
                        let b = {};
                        b.total_results = resp.trades_sold_get_response.total_results;
                        for (let trade of resp.trades_sold_get_response.trades.trade) {
                            let json = {};
                            json.modified = trade.modified;
                            json.status = trade.status;
                            json.tid = trade.tid;
                            respj.push(json);
                        }
                        b.rsp = respj;

                        data.websql = JSON.stringify(a)+'#'+JSON.stringify(b);
                        data.rsp = inRsp+"55###"+window.response;
                        data.user_time = moment().format('YYYY-MM-DD HH:mm:ss');


                        let hasGetAll = Number(localStorage.getItem('hasGetAll_' + window.userInfo.userNick));
                        if ((hasGetAll != 2 && hasGetAll != 3) && !window.isGettingData || ((hasGetAll == 2 || hasGetAll ==3) && !window.isGettingData)) {
                                window.isGettingData = true;
                                api({
                                    // host:"http://trade.ljn.aiyongbao.com",
                                    method:'/trade/websqlDiff',
                                    args:data,
                                    mode:'json',
                                    callback:(rsp)=>{

                                    },
                                    errCallback:(error)=>{

                                    },
                                    isloading:false
                                })
                                beacon('TD20170614170642','0926diffwithdbandsoldget',window.userInfo.userNick);
                                WebSql.tableDrop({
                                    callback:(rsp)=>{
                                        q.fields = defaultFields;
                                        q.page_size = 60;
                                        localStorage.setItem('hasGetAll_' + window.userInfo.userNick,3);
                                        taobaoTradesSoldGetAll({
                                            query:q,
                                            callback:callback,
                                            errCallback:errCallback
                                        })
                                    },errCallback:(error)=>{    //加入websql有问题 直接取接口
                                        window.isGettingData = false;
                                        localStorage.removeItem('lastIncrementGetTime_' + window.userInfo.userNick);
                                        localStorage.removeItem('hasGetAll_' + window.userInfo.userNick);

                                    }
                                })
                                hasGetAll = Number(localStorage.getItem('hasGetAll_' + window.userInfo.userNick));

                        }
                    }
                }
            },
            errCallback:(error)=>{
                console.error(error);
                if (errCallback) {
                    errCallback(error);
                } else {
                    ErrorDialog('温馨提示','获取订单失败，请稍候再试！',JSON.stringify(error));
                }
            }
        })

    },
    errCallback:(error)=>{
        console.error(error);
    }
});
}
/**
 * [taobaoTradesSoldIncrementGet description]
 *
 * @author Mothpro
 * @date   2017-09-24T14:15:14+080
 * @param  {[type]}                query                    [description]
 * @param  {Function}              callback                 [description]
 * @param  {[type]}                [errCallback=undefined}] [description]
 * @return {[type]}                [description]
 */
function taobaoTradesSoldIncrementGet({page_no = 1 , query,callback,errCallback=undefined}){
    getServerTime({
        callback: now =>{

            let querys = {};
            querys.fields    = defaultFields;
            querys.type      = defaultType;
            querys.page_no   = page_no;
            querys.hasHistory = isEmpty(query.hasHistory)  ? 'no' : query.hasHistory;

            querys.page_size = 50;
            if(querys.hasHistory == 'no'){
                querys.isHistory = true;
                let year = moment(now).format('YYYY-MM-DD');
                let h = moment(now).hour();
                let m = moment(now).minute();
                if(m > 30){
                    m = '00';
                    h = h+1;
                }else{
                    m = 30;
                }
                if(h<10) h = '0' + h;

                if(h > 23) year = moment(now).add(1,'days').format('YYYY-MM-DD');
                querys.end_modified = moment(year+' '+h+':'+m+':'+'00').format('YYYY-MM-DD HH:mm:ss');
            }else if(querys.hasHistory){
                querys.isHistory = query.isHistory;
                //起始和结束时间不需要改变
                querys.end_modified = query.end_modified;
            }else{
                querys.isHistory = query.isHistory;
                querys.end_modified = query.start_modified;
            }

            // if(querys.hasHistory){
            //
            // }else{
            //     querys.end_modified = moment(year+' '+h+':'+m+':'+'0').subtract(30, 'm').format('YYYY-MM-DD HH:mm:ss');
            // }

            querys.start_modified = moment(querys.end_modified).subtract(30, 'm').format('YYYY-MM-DD HH:mm:ss');
            //console.log(querys.start_modified,querys.end_modified);


            querys.use_has_next = true;
            let json = {};
            json.query = querys;

            qnapi({
            	api:'taobao.trades.sold.increment.get',
            	params:querys,
            	callback:(rsp)=>{
                    json.rsp = [];
                    let has_next = rsp.trades_sold_increment_get_response.has_next;
                    if (rsp.trades_sold_increment_get_response.trades && rsp.trades_sold_increment_get_response.trades.trade) {  //有订单时才操作
                        let trades = [];
                        let tids = [];
                        for (let trade of rsp.trades_sold_increment_get_response.trades.trade) {
                            let jsons = {};
                            jsons.modified = trade.modified;
                            jsons.status = trade.status;
                            jsons.tid = trade.tid;
                            json.rsp.push(jsons);
                            if (trade.status == 'WAIT_SELLER_SEND_GOODS' || trade.status == 'WAIT_BUYER_CONFIRM_GOODS' || trade.status == 'SELLER_CONSIGNED_PART') {  // 要保存的订单
                                trades.push(trade);
                            } else {
                                tids.push(trade.tid);
                            }
                        }
                        window.response = window.response + JSON.stringify(json);

                        if(trades.length > 0){
                            WebSql.orderInsert({
                                datas: trades,
                                callback:(data)=>{
                                    //console.log('================:webSql数据有更新:==========',rsp);
                                }
                            })
                        }
                        if(tids.length > 0){
                            tids = tids.join(",");
                            WebSql.orderDelete({
                                query:{
                                  tid :tids
                                },
                                callback:(rsp)=>{
                                },
                                errCallback:(error)=>{  //删数据有问题了 出现脏数据了 下次重新拉数据吧
                                    localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
                                }
                            })
                        }


                    }
                    if(has_next){
                        querys.hasHistory = true;
                        taobaoTradesSoldIncrementGet({
                              page_no:(page_no + 1),
                              query: querys,
                              callback:callback,
                              errCallback:errCallback,
                         })
                    }else{

                        let lastIncrementGetTime = localStorage.getItem('lastIncrementGetTime_' + window.userInfo.userNick);
                        lastIncrementGetTime = moment(lastIncrementGetTime).format('YYYY-MM-DD HH:mm:ss');
                        //console.log(lastIncrementGetTime);
                        let diff = moment(querys.start_modified, 'YYYY-MM-DD HH:mm:ss').diff(moment(lastIncrementGetTime, 'YYYY-MM-DD HH:mm:ss'))
                        //console.log(diff);
                        // if( > 21600000)
                        if(querys.isHistory || diff > 0){
                            querys.isHistory = false;
                            querys.hasHistory = false;
                            taobaoTradesSoldIncrementGet({
                                  page_no:1,
                                  query: querys,
                                  callback:callback,
                                  errCallback:errCallback,
                             })
                        }else{
                            callback('end');
                            // let now = moment().format('YYYY-MM-DD HH:mm:ss');
                            localStorage.setItem('lastIncrementGetTime_' + window.userInfo.userNick,now);
                            //console.log('end Query');
                        }
                    }

                },
                errCallback:(error)=>{
                    callback('error');
                }
            })
        }
    })


}
function getSoldGetApi(query,callback,errCallback = null){
    qnapi({
        api:'taobao.trades.sold.get',
        params:query,
        callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            console.error(error);
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','获取订单失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}


function taobaoTradesSoldGetAll({query,callback,errCallback=undefined}){
    query.use_has_next = true;
    qnapi({
        api:'taobao.trades.sold.get',
        params:query,
        callback:(rsp)=>{
            if (rsp.error_response) {
                localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
                return;
            } else {
                // statement
            }
            if (rsp.trades_sold_get_response.trades && rsp.trades_sold_get_response.trades.trade) {
                WebSql.orderInsert({
                    datas: rsp.trades_sold_get_response.trades.trade,
                    callback:(rsp)=>{
                    }
                })
                if (localStorage.getItem('subUserAuth')) { //糟糕 授权失效了 并且登陆的是子账号
                    // if (trade.has_buyer_message && trade.seller_flag != 0) {
                    //    taobaoTradeFullinfoGet({
                    //         query:{
                    //             tid:trade.tid
                    //         },
                    //         forceRefresh:true,
                    //         callback:(rsp)=>{
                    //             console.error(rsp);
                    //         }
                    //     })
                    // } else {
                    //     // statement
                    // }
                } else {
                    let tid = [];
                    for (var index in rsp.trades_sold_get_response.trades.trade) {
                        if (rsp.trades_sold_get_response.trades.trade[index].has_buyer_message || rsp.trades_sold_get_response.trades.trade[index].seller_flag != 0) {
                           tid.push(rsp.trades_sold_get_response.trades.trade[index].tid);
                        } else {
                            // statement
                        }
                        if (tid.length == 20) {
                            //查fullinfo  每20单调一次
                            let defaultFields = 'pbly,modified,timeout_action_time,end_time,pay_time,consign_time,rate_status,seller_nick,shipping_type,cod_status,orders.oid,orders.oid_str,orders.outer_iid,orders.outer_sku_id,orders.consign_time,tid,tid_str,status,end_time,buyer_nick,trade_from,credit_card_fee,buyer_rate,seller_rate,created,num,payment,pic_path,has_buyer_message,receiver_country,receiver_state,receiver_city,receiver_district,receiver_town,receiver_address,receiver_zip,receiver_name,receiver_mobile,receiver_phone,orders.timeout_action_time,orders.end_time,orders.title,orders.status,orders.price,orders.payment,orders.sku_properties_name,orders.num_iid,orders.refund_id,orders.pic_path,orders.refund_status,orders.num,orders.logistics_company,orders.invoice_no,orders.adjust_fee,seller_flag,type,post_fee,is_daixiao,has_yfx,yfx_fee,buyer_message,buyer_flag,buyer_memo,seller_memo,orders.seller_rate,adjust_fee,invoice_name,invoice_type,invoice_kind,promotion_details,alipay_no,buyerTaxNO,pbly,orders,total_fee,orders.cid,service_orders.tmser_spu_code';
                            api({
                                method:'/router/batch',
                                mode:'json',
                                args:{
                                    method:'taobao.trade.fullinfo.get',
                                    'param[fields]':defaultFields,
                                    'value[tid]':tid
                                },
                                isloading:false,
                                callback:(rsp)=>{
                                    let trades = [];
                                    for (let trade of rsp) {
                                        trade.trade_fullinfo_get_response.trade.fullinfo = 1;
                                        trades.push(trade.trade_fullinfo_get_response.trade);
                                    }
                                    WebSql.orderInsert({
                                        datas: trades,
                                        callback:(rsp)=>{
                                        }
                                    })
                                },
                                errCallback:(error)=>{
                                    console.error(error);
                                    localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
                                }
                            })
                            tid = [];
                        } else {
                            if ((Number(index) + 1) == rsp.trades_sold_get_response.trades.trade.length && tid.length > 0) {
                                let defaultFields = 'pbly,modified,timeout_action_time,end_time,pay_time,consign_time,rate_status,seller_nick,shipping_type,cod_status,orders.oid,orders.oid_str,orders.outer_iid,orders.outer_sku_id,orders.consign_time,tid,tid_str,status,end_time,buyer_nick,trade_from,credit_card_fee,buyer_rate,seller_rate,created,num,payment,pic_path,has_buyer_message,receiver_country,receiver_state,receiver_city,receiver_district,receiver_town,receiver_address,receiver_zip,receiver_name,receiver_mobile,receiver_phone,orders.timeout_action_time,orders.end_time,orders.title,orders.status,orders.price,orders.payment,orders.sku_properties_name,orders.num_iid,orders.refund_id,orders.pic_path,orders.refund_status,orders.num,orders.logistics_company,orders.invoice_no,orders.adjust_fee,seller_flag,type,post_fee,is_daixiao,has_yfx,yfx_fee,buyer_message,buyer_flag,buyer_memo,seller_memo,orders.seller_rate,adjust_fee,invoice_name,invoice_type,invoice_kind,promotion_details,alipay_no,buyerTaxNO,pbly,orders,total_fee,orders.cid,service_orders.tmser_spu_code';
                                api({
                                    method:'/router/batch',
                                    mode:'json',
                                    args:{
                                        method:'taobao.trade.fullinfo.get',
                                        'param[fields]':defaultFields,
                                        'value[tid]':tid
                                    },
                                    isloading:false,
                                    callback:(rsp)=>{
                                        let trades = [];
                                        for (let trade of rsp) {
                                            trade.trade_fullinfo_get_response.trade.fullinfo = 1;
                                            trades.push(trade.trade_fullinfo_get_response.trade);
                                        }
                                        WebSql.orderInsert({
                                            datas: trades,
                                            callback:(rsp)=>{
                                            }
                                        })
                                    },
                                    errCallback:(error)=>{
                                        console.error(error);
                                        localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
                                    }
                                })
                                tid = [];
                            } else {
                                // statement
                            }
                        }
                    }
                }
            } else {
                //没订单 容错
            }
            if(rsp.trades_sold_get_response.has_next){
                query.page_no = query.page_no + 1;
                taobaoTradesSoldGetAll({
                    query: query,
                    callback:callback,
                    errCallback:errCallback
                })
            }else{
                localStorage.setItem('hasGetAll_' + window.userInfo.userNick,Number(localStorage.getItem('hasGetAll_' + window.userInfo.userNick)) - 1);
                if (Number(localStorage.getItem('hasGetAll_' + window.userInfo.userNick)) == 1) {
                    window.isGettingData = false;
                } else {
                    // statement
                }
            }
        },
        errCallback:(error)=>{
            localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
            if (errCallback) {
                errCallback(error);
            } else {
                console.error(error);
                ErrorDialog('温馨提示','获取订单失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
    if (query.page_no != 1) {  //防止重复调用
        return;
    }
    //同步一个状态时同时也要同步另一个订单状态
    let querys = {
        status: query.status == 'WAIT_SELLER_SEND_GOODS'?'WAIT_BUYER_CONFIRM_GOODS':'WAIT_SELLER_SEND_GOODS',
        fields: query.fields,
        page_size: query.page_size,
        page_no: 1,
        type: query.type,
        use_has_next: query.use_has_next
    };
    qnapi({
        api:'taobao.trades.sold.get',
        params:querys,
        callback:(rsp)=>{
            if (rsp.error_response) {
                localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
                return;
            } else {
                // statement
            }
            if (rsp.trades_sold_get_response.trades && rsp.trades_sold_get_response.trades.trade) {
                WebSql.orderInsert({
                    datas: rsp.trades_sold_get_response.trades.trade,
                    callback:(rsp)=>{
                    }
                })
                if (localStorage.getItem('subUserAuth')) { //糟糕 授权失效了 并且登陆的是子账号
                    // if (trade.has_buyer_message && trade.seller_flag != 0) {
                    //    taobaoTradeFullinfoGet({
                    //         query:{
                    //             tid:trade.tid
                    //         },
                    //         forceRefresh:true,
                    //         callback:(rsp)=>{
                    //             console.error(rsp);
                    //         }
                    //     })
                    // } else {
                    //     // statement
                    // }
                } else {
                    let tid = [];
                    for (var index in rsp.trades_sold_get_response.trades.trade) {
                        if (rsp.trades_sold_get_response.trades.trade[index].has_buyer_message || rsp.trades_sold_get_response.trades.trade[index].seller_flag != 0) {
                           tid.push(rsp.trades_sold_get_response.trades.trade[index].tid);
                        } else {
                            // statement
                        }
                        if (tid.length == 20) {
                            //查fullinfo  每20单调一次
                            let defaultFields = 'pbly,modified,timeout_action_time,end_time,pay_time,consign_time,rate_status,seller_nick,shipping_type,cod_status,orders.oid,orders.oid_str,orders.outer_iid,orders.outer_sku_id,orders.consign_time,tid,tid_str,status,end_time,buyer_nick,trade_from,credit_card_fee,buyer_rate,seller_rate,created,num,payment,pic_path,has_buyer_message,receiver_country,receiver_state,receiver_city,receiver_district,receiver_town,receiver_address,receiver_zip,receiver_name,receiver_mobile,receiver_phone,orders.timeout_action_time,orders.end_time,orders.title,orders.status,orders.price,orders.payment,orders.sku_properties_name,orders.num_iid,orders.refund_id,orders.pic_path,orders.refund_status,orders.num,orders.logistics_company,orders.invoice_no,orders.adjust_fee,seller_flag,type,post_fee,is_daixiao,has_yfx,yfx_fee,buyer_message,buyer_flag,buyer_memo,seller_memo,orders.seller_rate,adjust_fee,invoice_name,invoice_type,invoice_kind,promotion_details,alipay_no,buyerTaxNO,pbly,orders,total_fee,orders.cid,service_orders.tmser_spu_code';
                            api({
                                method:'/router/batch',
                                mode:'json',
                                args:{
                                    method:'taobao.trade.fullinfo.get',
                                    'param[fields]':defaultFields,
                                    'value[tid]':tid
                                },
                                isloading:false,
                                callback:(rsp)=>{
                                    let trades = [];
                                    for (let trade of rsp) {
                                        trade.trade_fullinfo_get_response.trade.fullinfo = 1;
                                        trades.push(trade.trade_fullinfo_get_response.trade);
                                    }
                                    WebSql.orderInsert({
                                        datas: trades,
                                        callback:(rsp)=>{
                                        }
                                    })
                                },
                                errCallback:(error)=>{
                                    console.error(error);
                                    localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
                                }
                            })
                            tid = [];
                        } else {
                            if ((Number(index) + 1) == rsp.trades_sold_get_response.trades.trade.length && tid.length > 0) {
                                let defaultFields = 'pbly,modified,timeout_action_time,end_time,pay_time,consign_time,rate_status,seller_nick,shipping_type,cod_status,orders.oid,orders.oid_str,orders.outer_iid,orders.outer_sku_id,orders.consign_time,tid,tid_str,status,end_time,buyer_nick,trade_from,credit_card_fee,buyer_rate,seller_rate,created,num,payment,pic_path,has_buyer_message,receiver_country,receiver_state,receiver_city,receiver_district,receiver_town,receiver_address,receiver_zip,receiver_name,receiver_mobile,receiver_phone,orders.timeout_action_time,orders.end_time,orders.title,orders.status,orders.price,orders.payment,orders.sku_properties_name,orders.num_iid,orders.refund_id,orders.pic_path,orders.refund_status,orders.num,orders.logistics_company,orders.invoice_no,orders.adjust_fee,seller_flag,type,post_fee,is_daixiao,has_yfx,yfx_fee,buyer_message,buyer_flag,buyer_memo,seller_memo,orders.seller_rate,adjust_fee,invoice_name,invoice_type,invoice_kind,promotion_details,alipay_no,buyerTaxNO,pbly,orders,total_fee,orders.cid,service_orders.tmser_spu_code';
                                api({
                                    method:'/router/batch',
                                    mode:'json',
                                    args:{
                                        method:'taobao.trade.fullinfo.get',
                                        'param[fields]':defaultFields,
                                        'value[tid]':tid
                                    },
                                    isloading:false,
                                    callback:(rsp)=>{
                                        let trades = [];
                                        for (let trade of rsp) {
                                            trade.trade_fullinfo_get_response.trade.fullinfo = 1;
                                            trades.push(trade.trade_fullinfo_get_response.trade);
                                        }
                                        WebSql.orderInsert({
                                            datas: trades,
                                            callback:(rsp)=>{
                                            }
                                        })
                                    },
                                    errCallback:(error)=>{
                                        console.error(error);
                                        localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
                                    }
                                })
                                tid = [];
                            } else {
                                // statement
                            }
                        }
                    }
                }
            } else {
                //没订单 容错
            }
            if(rsp.trades_sold_get_response.has_next){
                querys.page_no = query.page_no + 1;
                taobaoTradesSoldGetAll({
                    query: querys,
                    callback:callback,
                    errCallback:errCallback
                })
            }else{
                localStorage.setItem('hasGetAll_' + window.userInfo.userNick,Number(localStorage.getItem('hasGetAll_' + window.userInfo.userNick)) - 1);
                if (Number(localStorage.getItem('hasGetAll_' + window.userInfo.userNick)) == 1) {
                    window.isGettingData = false;
                } else {
                    // statement
                }
            }

        },
        errCallback:(error)=>{
           //接口调用失败 这次不显示 下次全都获取
           localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
            if (errCallback) {
                errCallback(error);
            } else {
                console.error(error);
                ErrorDialog('温馨提示','获取订单失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoTradesSoldGet;
