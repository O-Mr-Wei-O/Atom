import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';

function taobaoTradeReceivetimeDelay({query,callback,errCallback=undefined}){
    qnapi({
        api : 'taobao.trade.receivetime.delay',
        params : {
            tid  : query.tid,
            days : query.days
        },
       	callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','延长交易收货时间失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoTradeReceivetimeDelay;
