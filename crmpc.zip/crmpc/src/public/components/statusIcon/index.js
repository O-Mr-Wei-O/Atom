import React from 'react';
import {Balloon} from 'qnui';
import './index.scss';

/**
 * 状态图标 status_str 状态值
 * @author zdh
 * @type {[type]}
 */
class StatusIcon extends React.Component {
    constructor(props) {
        super(props);
    }
    /**
     *
     * 退：#e41010  该笔订单有退款的宝贝
     拆：#1dc11d  该笔订单为拆分的订单
     合：#f57745  该笔订单为合并的订单
     票：#ffe2d0  该笔订单有发票信息
     货到付款：是张图片  该笔订单为货到付款的订单
     发：#3089dc   该笔订单为部分发货的订单
     改：00BE92
     惠：FF8400
     * @author zdh
     * @dateTime 2017-08-07T20:56:48+080
     * @return   {[type]}                [description]
     */
    render(){
        const {status_str} = this.props;
        let status_color = "";
        let status_tips = "";
        switch (status_str) {
            case "退":
                status_color = "#e41010";
                status_tips = "该笔订单有退款的宝贝";
                break;
            case "拆":
                status_color = "#1dc11d";
                status_tips = "该笔订单为拆分的订单";
                break;
            case "合":
                status_color = "#f57745";
                status_tips = "该笔订单为合并的订单";
                break;
            case "票":
                status_color = "#F700FF";
                status_tips = "该笔订单有发票信息";
                break;
            case "货":
                status_color = "";
                status_tips = "该笔订单为货到付款的订单";
                break;
            case "发":
                status_color = "#3089dc";
                status_tips = "该笔订单为部分发货的订单";
                break;
            case "改":
                status_color = "#00BE92";
                status_tips = "手动改价";
                break;
            case "惠":
                status_color = "#FF8400";
                status_tips = "卖家优惠";
                break;
            default:

        }

        if(status_str == "货"){
            return (
                <Balloon  trigger={
                    <div className="status-icon-img" >
                        <img width={16} height={16} src="//q.aiyongbao.com/trade/img/hdfk.png" alt=""/>
                    </div>
                } triggerType="hover" closable={false}>
                    {
                        status_tips
                    }
                </Balloon>

            );
        }else {
            return (
                <Balloon  trigger={
                    <div className="status-icon-div" style={{backgroundColor:status_color}} >
                        {
                            status_str
                        }
                    </div>
                } triggerType="hover" closable={false}>
                    {
                        status_tips
                    }
                </Balloon>

            );
        }
    }
}
export default StatusIcon;
