import React from 'react';
import {Icon} from 'qnui';
import './index.scss';

/**
 *  单选组合
 *  dataSource  选择项数据源
 *  {
 *      label 显示的值
 *      value 对应id
 *  }
 *  selectedValue 选中值（id）
 *  onChange 选中的回调函数
 *      参数  value  选中的id
 *           label  选中项对应的显示值
 * @type {[type]}
 */
class SelectTag extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedValue :props.selectedValue
        }
    }
    onChange(v,e){
        const {callback} = this.props;
        this.setState({
            selectedValue:v
        })
        callback(v,e);
    }
    componentWillReceiveProps(nextProps){
        this.setState({
            selectedValue:nextProps.selectedValue
        })

    }


    render(){
        const {dataSource,callback} = this.props;
        const {selectedValue} = this.state;
        return (
            <div style={{display:"inline-block"}}>
                {
                    dataSource.map((item,index)=>{
                        if(item.value == selectedValue){
                            return (
                                <div key={`select_tag_item${item.value}`} onClick={()=>{
                                    this.onChange(item.value,item.label);
                                }} className="select-tag-item-selected">
                                    {item.label}
                                    <div className="select-tag-triangle"></div>
                                    <Icon style={{position: "absolute",right: "1px",bottom: "-8px",color: "#fff"}} size="xxs" type="select" />
                                </div>
                            );
                        }else {
                            return (
                                <div key={`select_tag_item${item.value}`} onClick={()=>{
                                    this.onChange(item.value,item.label);
                                }} className="select-tag-item">
                                    {item.label}
                                </div>
                            );
                        }
                    })
                }
            </div>
        );
    }
}
export default SelectTag;
