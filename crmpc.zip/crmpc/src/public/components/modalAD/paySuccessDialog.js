import React from 'react';
import {Button} from 'qnui';

class PaySuccessDialog extends React.Component {
    constructor(props) {
        super(props);

    }

    render(){
        const {closeDialog,title,successImageUrl} = this.props;
        return (
            <div className="modal-ad-div">
                <div className="modal-ad-for-center">
                    <div className="pay-success-dialog-div">
                        <span onClick={closeDialog} className="icon-cancel-span">
                            <svg className="ad-icon-cancel">
                                <use xlinkHref="#icon-cancel"></use>
                            </svg>
                        </span>
                        <div className="pay-success-dialog-div-head">
                            <svg className="psd-icon-chenggong">
                                <use xlinkHref="#icon-chenggong"></use>
                            </svg>
                            <span className="pay-success-dialog-div-head-span">
                                {title}
                            </span>
                        </div>
                        <div className="pay-success-dialog-div-body">
                            <div className="pay-success-dialog-div-body-title">
                                尊敬的高级版用户，您可在手机端及pc端使用以下专属功能
                            </div>
                            <div className="pay-success-dialog-div-body-div">
                                <img width={370} height={190} src={successImageUrl}/>
                            </div>
                        </div>
                        <div className="pay-success-dialog-div-foot">
                            <Button onClick={()=>{
                                window.location.reload();
                            }} style={{fontSize: "16px"}} size="large" type="primary">立即体验</Button>
                            <Button onClick={()=>{
                                window.location.reload();
                            }} style={{fontSize: "16px",marginLeft: "100px"}} size="large" type="secondary">返回首页</Button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default PaySuccessDialog;
