import React from 'react';
import {Button,Dialog} from 'qnui';
import PayFailDialog from './payFailDialog'
import PaySuccessDialog from './paySuccessDialog'
import {confirmUserInfo,isEmpty} from 'utils';

class SurePayDialog extends React.Component {
    constructor(props) {
        super(props);

    }

    refshvip(){
        const {closeDialog,vipDate,adDialog,successImageUrl,clickPay,isSubuser,subuser,btnUrl,wangwangPCModalAD} = this.props;

        confirmUserInfo(userInfo,(vipResult)=>{
            /**
             * vipResult 付费结果
             * 1 升级成功
             * -1 升级失败
             * 2 续费成功
             * -2 续费失败
             */
            closeDialog();

            if(!isEmpty(adDialog)){
                adDialog.hide();
            }
            if(vipResult == 1){/*升级成功*/
                vipDate('save');
                const paySuccessDialog = Dialog.alert({
                    needWrapper: false,
                    content: "",
                    title: "",
                    autoFocus:false,
                    footer: <PaySuccessDialog successImageUrl={successImageUrl} title="升级成功！" closeDialog={()=>{paySuccessDialog.hide();}}/>
                });
            }
            if(vipResult == -1){/*升级失败*/
                const payFailDialog = Dialog.alert({
                    needWrapper: false,
                    content: "",
                    title: "",
                    autoFocus:false,
                    footer: <PayFailDialog clickPay={clickPay} isSubuser={isSubuser} subuser={subuser} btnUrl={btnUrl} lxkf={this.lxkf.bind(this)} wangwangPCModalAD={wangwangPCModalAD} title="升级失败！" closeDialog={()=>{payFailDialog.hide();}}/>
                });
            }
            if(vipResult == 2){/*续费成功*/
                vipDate('save');
                const paySuccessDialog = Dialog.alert({
                    needWrapper: false,
                    content: "",
                    title: "",
                    autoFocus:false,
                    footer: <PaySuccessDialog successImageUrl={successImageUrl} title="续费成功！" closeDialog={()=>{paySuccessDialog.hide();}}/>
                });
            }
            if(vipResult == -2){/*续费失败*/
                const payFailDialog = Dialog.alert({
                    needWrapper: false,
                    content: "",
                    title: "",
                    autoFocus:false,
                    footer: <PayFailDialog clickPay={clickPay} isSubuser={isSubuser} subuser={subuser} btnUrl={btnUrl} lxkf={this.lxkf.bind(this)} wangwangPCModalAD={wangwangPCModalAD} title="续费失败！" closeDialog={()=>{payFailDialog.hide();}}/>
                });
            }

        });

    }

    lxkf(){
        const {groupName,typeText,wangwangPCModalAD} = this.props;
        wangwangPCModalAD("你好，我想订购爱用"+groupName+"高级版，但是"+typeText+"失败，我该怎么办？",1);
    }

    render(){
        const {closeDialog,vipDate,groupName,typeText,successImageUrl} = this.props;
        return (
            <div className="modal-ad-div">
                <div className="modal-ad-for-center">
                    <div className="sure-pay-dialog-content">
                        <div className="sure-pay-dialog-head">
                            <div className="sure-pay-dialog-head-div">
                                温馨提示
                            </div>
                            <span onClick={closeDialog} className="sure-pay-dialog-head-close">
                                <i className="next-icon next-icon-close next-icon-small"></i>
                            </span>
                        </div>
                        <div className="sure-pay-dialog-line"></div>
                        <div className="sure-pay-dialog-body">
                            <div className="sure-pay-dialog-body-div">
                                请您在新开的页面上完成付款，付款完成前请不要关闭此窗口。完成付款后请根据您的情况点击下面的按钮。
                            </div>
                        </div>
                        <div className="sure-pay-dialog-foot">
                            <div className="sure-pay-dialog-foot-btn-div">
                                <Button onClick={this.refshvip.bind(this)} type="primary">已完成付款</Button>
                                <Button style={{marginLeft: "50px"}} type="secondary" onClick={()=>{
                                    this.lxkf();
                                }}>付款遇到问题</Button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default SurePayDialog;
