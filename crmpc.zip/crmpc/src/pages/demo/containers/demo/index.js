import React from 'react';
import './index.scss';

/**
 * [constructor description]
 *
 * @author Mothpro
 * @date   2017-12-26T17:15:20+080
 * @param  {[type]}                props [description]
 * @return {[type]}                [description]
 */
class Demo extends React.Component {
    constructor(props) {
        super(props);
    }

    render(){
        return (
            <div>Hellow wolrd!</div>
        )
    }
}

export default Demo;
