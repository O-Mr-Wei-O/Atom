import React from 'react';
import './index.scss';

export default class DescLi extends React.Component{
    constructor(props){
        super(props);

        this.state={arr: this.props.arr};
        this.deleteRow=this.deleteRow.bind(this);
    }

    deleteRow(event){
        const index=event.target.getAttribute("data-index");
        const Array=this.state.arr;
        Array.splice(index,1);
        console.log(Array);
        this.setState({arr: Array});
    }

    render() {
        const newArray=[];
        const LiArr=this.state.arr;
        console.log("----"+this.state.arr);
        for(let i=0;i<LiArr.length;i++){
            newArray.push(<li>{LiArr[i]}<a style={{'cursor':'pointer','marginLeft':'10'}} data-index={i} onClick={this.deleteRow}>删除</a></li>);
        }
        return <ul>{newArray}</ul>;
    }
}
