import React from 'react';
import './index.scss';
import DescLi from './DescLi';

/**
 * [constructor description]
 *
 * @author Mothpro
 * @date   2017-12-26T17:15:20+080
 * @param  {[type]}                props [description]
 * @return {[type]}                [description]
 */

let arr=[];

class Demo extends React.Component {
    constructor(props) {
        super(props);

        this.state={value:arr};
        this.handleClick=this.handleClick.bind(this);
        // this.deleteRow=this.deleteRow.bind(this);
    }

    handleClick(e){
        arr.push(this.refs.Input.value);
        this.setState({value: arr});
    }

    render(){
        console.log("index.js+"+arr);
        return (
            <div>
                <input ref="Input"></input>
                <input type="button" value="Input some text" onClick={this.handleClick}></input>
                <DescLi arr={this.state.value}/>
            </div>
        )
    }
}

export default Demo;
