/**
 * 重新授权
 * author cbl
 * @param  {[type]} state [tradeindex  tradepcreminder tradepcdefen tradepcsms tradepczdrate]
 * @return {[type]}       [description]
 */
function translateUrl(state){
    try{
        QN.application.invoke({
            cmd: 'translateUrl',
            param: {
                url: '//oauth.taobao.com/authorize?response_type=code&client_id=21085840&redirect_uri=https://trade.aiyongbao.com/tc/trades2?scope=item&view=web&state=' + state
            },
            success: function(rsp) {
                if(typeof rsp=== 'string'){
                    rsp = JSON.parse(rsp);
                }
                window.location.href = rsp.url
            }
        })
    }catch(e){
        console.error(e);
        setTimeout(function(){
            translateUrl(state);
        },100);
    }
    
}

export default translateUrl;