function itemDetail(iid){
    QN.application.invoke( {
        cmd : 'itemDetail',
        param : {
            iid : iid
        }
    });
}

export default itemDetail;