import taobaoTradeFullinfoGet from 'components/biz/tradeApi/taobaoTradeFullinfoGet'
import moment from 'moment'
import {api} from 'utils/index';
var WebSql = {
    orderCreate:function ({callback,errCallback=undefined}){
        try{
            window.db.transaction(function (context) {
                context.executeSql(`CREATE TABLE IF NOT EXISTS 'trade' ('tid' varchar(40) NOT NULL,
                    'status' varchar(32) NOT NULL,
                    'trade_attr' varchar(32) DEFAULT NULL,
                    'type' varchar(32) NOT NULL,
                    'seller_nick' varchar(32) NOT NULL,
                    'buyer_nick' varchar(32) NOT NULL,
                    'created' datetime ,
                    'pay_time' datetime ,
                    'consign_time' datetime ,
                    'has_buyer_message' varchar(10),
                    'end_time' datetime ,
                    'timeout_action_time' datetime ,
                    'modified' datetime ,
                    'receiver_phone' varchar(32) DEFAULT NULL,
                    'receiver_mobile' varchar(32) DEFAULT NULL,
                    'receiver_zip' varchar(32) DEFAULT NULL,
                    'receiver_address' varchar(150) NOT NULL,
                    'receiver_state' varchar(32) DEFAULT NULL,
                    'receiver_city' varchar(32) DEFAULT NULL,
                    'receiver_district' varchar(32) DEFAULT NULL,
                    'receiver_country' varchar(32) DEFAULT NULL,
                    'receiver_town' varchar(32) DEFAULT NULL,
                    'receiver_name' varchar(50) NOT NULL,
                    'seller_rate' tinyint(4) NOT NULL,
                    'buyer_rate' tinyint(4) NOT NULL,
                    'seller_flag' int(10) DEFAULT 0,
                    'num' int(10) DEFAULT NULL,
                    'invoice_type' varchar(32) DEFAULT NULL,
                    'invoice_name' varchar(32) DEFAULT NULL,
                    'invoice_kind' int(2) DEFAULT NULL,
                    'trade_from' varchar(32) NOT NULL,
                    'credit_card_fee' varchar(32) DEFAULT NULL,
                    'payment' varchar(32) NOT NULL,
                    'post_fee' varchar(32) NOT NULL,
                    'adjust_fee' varchar(32) DEFAULT NULL,
                    'promotion_details' mediumtext,
                    'buyer_message' varchar(250) DEFAULT NULL,
                    'seller_memo' varchar(250) DEFAULT NULL,
                    'buyer_memo' varchar(250) DEFAULT NULL,
                    'refund_status' varchar(32) DEFAULT NULL,
                    'shipping_type' varchar(32) DEFAULT NULL,
                    'pic_path' varchar(32) DEFAULT NULL,
                    'is_daixiao' tinyint(4) NOT NULL,
                    'fullinfo' tinyint(4) DEFAULT 0,
                    'union' tinyint(1) DEFAULT 0,
                    'service_orders' varchar(250) DEFAULT NULL,
                    'is_o2o_passport' tinyint(1) DEFAULT NULL,
                    'alipay_no' varchar(32) DEFAULT NULL,
                    'yfx_fee' varchar(32) DEFAULT NULL,
                    PRIMARY KEY ('tid'))`, [], function (context, results) {
                        context.executeSql('CREATE INDEX ISX_TID ON trade (`tid`)');
                        context.executeSql('CREATE INDEX IDX_CREATED ON trade (`created`)');
                        context.executeSql('CREATE INDEX IDX_RECEIVER_MOBILE ON trade (`receiver_mobile`)');
                        context.executeSql('CREATE INDEX IDX_SELLER_FLAG ON trade (`seller_flag`)');
                        context.executeSql('CREATE INDEX IDX_SELLER_MEMO ON trade (`seller_memo`)');
                        context.executeSql('CREATE INDEX IDX_BUYER_MESSAGE ON trade (`buyer_message`)');
                        context.executeSql('CREATE INDEX IDX_RECEIVER_CITY ON trade (`receiver_city`)');
                        context.executeSql('CREATE INDEX IDX_RECEIVER_STATE ON trade (`receiver_state`)');
                        context.executeSql('CREATE INDEX IDX_RECEIVER_DISTRICT ON trade (`receiver_district`)');
                        context.executeSql('CREATE INDEX IDX_RECEIVER_ZIP ON trade (`receiver_zip`)');
                        context.executeSql('CREATE INDEX IDX_MODIFIED ON trade (`modified`)');
                        context.executeSql('CREATE INDEX IDX_RECEIVER_ADDRESS ON trade (`receiver_address`)');
                        context.executeSql('CREATE INDEX IDX_RECEIVER_NAME ON trade (`receiver_name`)');
                        context.executeSql('CREATE INDEX IDX_TAO_STATUS ON trade (`status`)');
                        context.executeSql('CREATE INDEX IDX_CONSIGN_TIME ON trade (`consign_time`)');
                        callback(results);
                    },function (context, error) {
                        if (errCallback) {
                            errCallback(error);
                        } else {
                            console.error(error);
                        }

                    });

                //查看索引
                // window.db.transaction(function (context) {
                //     context.executeSql('SELECT * FROM sqlite_master WHERE type = ?', ['index'], function (context, results) {
                //         console.log(results);
                //     },function (context, error) {
                //         if (errCallback) {
                //             errCallback(error);
                //         } else {
                //             console.log(error);
                //         }
                //     });
                // });
            });
        }catch(e){}
    },
    orderInsert:function ({datas,callback,errCallback=undefined}){
        try{
            window.db.transaction(function (context) {
                var tradeCount = 0;
                let orderCount = 0;
                for(var data of datas){
                    //插入订单数据
                    context.executeSql('INSERT OR REPLACE INTO trade (`tid`,`status`,`trade_attr`,`type`,`seller_nick`,`buyer_nick`,`created`,`pay_time`,`has_buyer_message`,`consign_time`,`end_time`,`timeout_action_time`,`modified`,`receiver_phone`,`receiver_mobile`,`receiver_zip`,`receiver_address`,`receiver_state`,`receiver_city`,`receiver_district`,`receiver_country`,`receiver_town`,`receiver_name`,`seller_rate`,`buyer_rate`,`seller_flag`,`num`,`invoice_type`,`invoice_name`,`invoice_kind`,`trade_from`,`credit_card_fee`,`payment`,`post_fee`,`adjust_fee`,`promotion_details`,`buyer_message`,`seller_memo`,`buyer_memo`,`refund_status`,`shipping_type`,`pic_path`,`is_daixiao`,`fullinfo`,`union`,`service_orders`,`is_o2o_passport`,`alipay_no`,`yfx_fee`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    [data.tid,
                    data.status,
                    data.trade_attr?data.trade_attr:undefined,
                    data.type,
                    data.seller_nick,
                    data.buyer_nick,
                    data.created,
                    data.pay_time?data.pay_time:'',
                    (data.has_buyer_message || data.buyer_message)?true:false,
                    data.consign_time?data.consign_time:'',
                    data.end_time?data.end_time:'',
                    data.timeout_action_time?data.timeout_action_time:'',
                    data.modified,
                    data.receiver_phone?data.receiver_phone:'',
                    data.receiver_mobile?data.receiver_mobile:'',
                    data.receiver_zip?data.receiver_zip:'',
                    data.receiver_address?data.receiver_address:'',
                    data.receiver_state?data.receiver_state:'',
                    data.receiver_city?data.receiver_city:'',
                    data.receiver_district?data.receiver_district:'',
                    data.receiver_country?data.receiver_country:'',
                    data.receiver_town?data.receiver_town:'',
                    data.receiver_name?data.receiver_name:'',
                    data.seller_rate?data.seller_rate:'',
                    data.buyer_rate?data.buyer_rate:'',
                    data.seller_flag?data.seller_flag:0,
                    data.num?data.num:'',
                    data.invoice_type?data.invoice_type:'',
                    data.invoice_name?data.invoice_name:'',
                    data.invoice_kind?data.invoice_kind:'',
                    data.trade_from?data.trade_from:'',
                    data.credit_card_fee?data.credit_card_fee:'',
                    data.payment?data.payment:'',
                    data.post_fee?data.post_fee:'',
                    data.adjust_fee?data.adjust_fee:'',
                    data.promotion_details?JSON.stringify(data.promotion_details):'',
                    data.buyer_message?data.buyer_message:'',
                    data.seller_memo?data.seller_memo:'',
                    data.buyer_memo?data.buyer_memo:'',
                    data.refund_status?data.refund_status:'',
                    data.shipping_type?data.shipping_type:'',
                    data.pic_path?data.pic_path:'',
                    data.is_daixiao?data.is_daixiao:'',
                    data.fullinfo?data.fullinfo:0,
                    0,
                    data.service_orders?JSON.stringify(data.service_orders):'',
                    data.is_o2o_passport == true ? 1 :null,
                    data.alipay_no || null,
                    data.yfx_fee || null
                  ],
                    function (context, results) {
                        tradeCount++;
                        if (orderCount >= data.orders.order.length && tradeCount >= datas.length) {     //订单全部插入成功
                            callback(results);
                        } else {
                            // statement
                        }
                    },function (context, error) {
                        tradeCount++;
                        if (errCallback) {
                            if (orderCount >= data.orders.order.length && tradeCount >= datas.length) {    //订单全部插入成功
                                errCallback(error);
                            } else {
                              // statement
                            }

                        } else {
                            console.error(error);
                        }
                    });

                    //插入订单信息
                    if(data.orders && data.orders.order){
                        for(var order of data.orders.order){
                            context.executeSql('INSERT OR REPLACE INTO subOrder (`oid`,`tid`,`status`,`consign_time`,`end_time`,`pay_time`,`type`,`created`,`timeout_action_time`,`modified`,`seller_rate`,`buyer_rate`,`num`,`order_from`,`payment`,`price`,`adjust_fee`,`discount_fee`,`refund_id`,`refund_status`,`item_meal_name`,`item_meal_id`,`pic_path`,`outer_iid`,`cid`,`title`,`num_iid`,`sku_id`,`outer_sku_id`,`sku_properties_name`,`invoice_no`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                            [order.oid,
                            data.tid,
                            order.status?order.status:'',
                            order.consign_time?order.consign_time:'',
                            order.end_time?order.end_time:'',
                            order.pay_time?order.pay_time:'',
                            order.type?order.type:'',
                            order.created?order.created:'',
                            order.timeout_action_time?order.timeout_action_time:'',
                            order.modified?order.modified:'',
                            order.seller_rate?order.seller_rate:'',
                            order.buyer_rate?order.buyer_rate:'',
                            order.num?order.num:'',
                            order.order_from?order.order_from:'',
                            order.payment?order.payment:'',
                            order.price?order.price:'',
                            order.adjust_fee?order.adjust_fee:'',
                            order.discount_fee?order.discount_fee:'',
                            order.refund_id?order.refund_id:'',
                            order.refund_status?order.refund_status:'',
                            order.item_meal_name?order.item_meal_name:'',
                            order.item_meal_id?order.item_meal_id:'',
                            order.pic_path?order.pic_path:'',
                            order.outer_iid?order.outer_iid:'',
                            order.cid?order.cid:'',
                            order.title?order.title:'',
                            order.num_iid?order.num_iid:'',
                            order.sku_id?order.sku_id:'',
                            order.outer_sku_id?order.outer_sku_id:'',
                            order.sku_properties_name?order.sku_properties_name:'',
                            order.invoice_no?order.invoice_no:''],
                            function (context, results) {
                              orderCount++;
                              if (orderCount >= data.orders.order.length && tradeCount >= datas.length) {     //订单全部插入成功
                                  callback(results);
                              } else {
                                  // statement
                              }
                            },function (context, error) {
                                orderCount++;
                                    if (errCallback) {
                                        if (orderCount>=data.orders.order.length && tradeCount >= datas.length) {   //订单全部插入成功
                                            errCallback(error);
                                        } else {
                                            // statement
                                        }
                                    } else {
                                        console.error(error);
                                    }
                            });
                        }
                    }

                }
            });
        }catch(e){}
    },
    orderSelect:function ({query,callback,errCallback=undefined}){
        try{
            window.db.transaction(function (context) {
                // context.executeSql(sql, [], function (context, results) {
                //     callback(results);
                // },function (context, error) {
                //     if (errCallback) {
                //         errCallback(error);
                //     } else {
                //         console.log(error);
                //     }
                // });
                // 接口提供基本的过滤条件
                let option = '';
                if (query.status == 'WAIT_SELLER_SEND_GOODS') {
                    option = option + "(status = 'WAIT_SELLER_SEND_GOODS' OR status = 'SELLER_CONSIGNED_PART')";
                } else {
                    option = option + "status = 'WAIT_BUYER_CONFIRM_GOODS'";
                }
                if (query.buyer_nick) {
                    option = option + " AND buyer_nick = '" + query.buyer_nick + "'";
                }
                // console.log("SELECT COUNT(tid) AS total FROM trade WHERE " + option);
                context.executeSql("SELECT COUNT(tid) AS total FROM trade WHERE " + option, [], function (context, totalResult) {
                    // console.log("SELECT * FROM trade WHERE " + option + " ORDER BY created desc LIMIT ? OFFSET ?");
                    context.executeSql("SELECT * FROM trade WHERE " + option + " ORDER BY created desc LIMIT ? OFFSET ?", [query.page_size,(query.page_no -1) * query.page_size], function (context, tradeResult) {
                        let tids = [];
                        let trades = [];//模拟的订单返回数组
                        for (var index in tradeResult.rows) {
                            if (tradeResult.rows[index].tid) {
                                tids.push(tradeResult.rows[index].tid);
                                if (tradeResult.rows[index].promotion_details) {
                                    tradeResult.rows[index].promotion_details = JSON.parse(tradeResult.rows[index].promotion_details);
                                } else {
                                }
                                if (tradeResult.rows[index].service_orders) {
                                    tradeResult.rows[index].service_orders = JSON.parse(tradeResult.rows[index].service_orders);
                                } else {
                                }
                                if (tradeResult.rows[index].is_o2o_passport == 1 || tradeResult.rows[index].is_o2o_passport == '1') {
                                    tradeResult.rows[index].is_o2o_passport = true;
                                } else {
                                    tradeResult.rows[index].is_o2o_passport = false;
                                }
                                trades.push(tradeResult.rows[index]);
                            } else {
                                // statement
                            }
                        }
                        let num = 0;
                        //递归获取子订单order信息，解决webSql搜索条件没有索引的性能问题 by Mothpro
                        let getSubOrder = (tids)=>{
                            let results = {}
                            if (trades.length == 0 || totalResult.rows[0].total == 0) { //搜索记录为空，直接返回空数据
                                results = {
                                    trades_sold_get_response:{
                                        total_results: totalResult.rows[0].total
                                    }
                                }
                                callback(results);
                            }else{
                                if(num < tids.length){
                                    getSubOrderForSql(tids); //递归拼装查询完order后的trades信息
                                }else{
                                    // console.log('~~~~~~~~~~~~~~~~~~');
                                    // console.log(trades);
                                    results = {
                                        trades_sold_get_response:{
                                            total_results: totalResult.rows[0].total,
                                            trades: {
                                                trade: trades
                                            }
                                        }
                                    }
                                    callback(results);
                                }
                            }
                        }
                        let getSubOrderForSql = (tids)=>{
                            let tid = tids[num];
                            num++;
                            context.executeSql("SELECT * FROM subOrder WHERE tid  = '" + tid + "'", [], function (context, orderResult) {
                                let orders = [];
                                for (let index in orderResult.rows){
                                    if(orderResult.rows[index].tid == tid) orders.push(orderResult.rows[index])
                                }
                                let index = trades.findIndex(c=>{
                                    return c.tid == tid
                                })
                                trades[index].orders = {
                                       order: orders
                                }
                                getSubOrder(tids)
                            },function (context, error) {
                                trades[index].orders = {
                                       order: []
                                }
                                getSubOrder(tids)
                            });
                        }
                        getSubOrder(tids)
                        // console.log('SELECT * FROM subOrder WHERE tid in (' + tids.join(',') + ')');
                        // context.executeSql('SELECT * FROM subOrder WHERE tid in (' + tids.join(',') + ')', [], function (context, orderResult) {
                        //     for (var trade of trades){   //循环组子订单
                        //         let orders = []
                        //         for (var index in orderResult.rows){
                        //             if (orderResult.rows[index].tid == trade.tid) {  //子订单tid和tid
                        //                 orders.push(orderResult.rows[index]);
                        //             } else {
                        //                 // statement
                        //             }
                        //         }
                        //         trade.orders = {
                        //             order: orders
                        //         }
                        //     }
                        //     let results = {}
                        //     if (trades.length == 0 || totalResult.rows[0].total == 0) {
                        //         results = {
                        //             trades_sold_get_response:{
                        //                 total_results: totalResult.rows[0].total
                        //             }
                        //         }
                        //     } else {
                        //         results = {
                        //             trades_sold_get_response:{
                        //                 total_results: totalResult.rows[0].total,
                        //                 trades: {
                        //                     trade: trades
                        //                 }
                        //             }
                        //         }
                        //     }
                        //     // console.error('websql trades_sold_get_response result');
                        //     // console.log(results);
                        //     callback(results);
                        // },function (context, error) {
                        //     if (errCallback) {
                        //         errCallback(error);
                        //     } else {
                        //         console.error(error);
                        //     }
                        // });
                    },function (context, error) {
                        if (errCallback) {
                            errCallback(error);
                        } else {
                            console.error(error);
                        }
                    });
                },function (context, error) {
                    if (errCallback) {
                        errCallback(error);
                    } else {
                        console.error(error);
                    }
                });
            });
        }catch(e){}
    },
    orderSelectWithTid:function ({query,callback,errCallback=undefined}){
        try{
            window.db.transaction(function (context) {
                context.executeSql('SELECT * FROM trade WHERE tid = "' + query.tid + '" AND fullinfo = 1', [], function (context, result) {
                    if (result.rows.length != 0) { //WebSql里有fullInfo
                            context.executeSql('SELECT * FROM subOrder WHERE tid = "' + query.tid + '"', [], function (context, orderResult) {
                                let orders = [];
                                let trade = result.rows[0];
                                for (var index in orderResult.rows){
                                    if (orderResult.rows[index].tid == trade.tid) {  //子订单tid和tid
                                        orders.push(orderResult.rows[index]);
                                    } else {
                                        // statement
                                    }
                                }
                                trade.orders = {
                                    order: orders
                                }
                                if (result.rows[0].promotion_details) {
                                    trade.promotion_details = JSON.parse(result.rows[0].promotion_details);
                                } else {
                                }
                                if (result.rows[0].service_orders) {
                                    trade.service_orders = JSON.parse(result.rows[0].service_orders);
                                } else {
                                }
                                let results = {
                                    trade_fullinfo_get_response:{
                                        trade: trade
                                    }
                                }
                                // console.error('websql trade_fullinfo_get_response result');
                                // console.log(results);
                                callback(results);
                            },function (context, error) {
                                console.error(error);
                                //数据库报错了 去掉接口获取详情
                                taobaoTradeFullinfoGet({
                                    query:{
                                        tid : query.tid
                                    },
                                    callback:(rsp)=>{
                                        callback(rsp)
                                    }
                                })
                            });
                    }else{
                        callback(result);
                    }

                },function (context, error) {
                        if (errCallback) {
                            errCallback(error);
                        } else {
                            console.error(error);
                        }
                });
            });
        }catch(e){}
    },
    orderDelete:function ({query,callback,errCallback=undefined}){
        try{
            window.db.transaction(function (context) {
                context.executeSql('DELETE FROM trade WHERE tid in (' + query.tid + ')', [], function (context, results) {
                    context.executeSql('DELETE FROM subOrder WHERE tid in (' + query.tid + ')', [], function (context, results) {
                        callback(results);
                    },function (context, error) {
                        if (errCallback) {
                            errCallback(error);
                        } else {
                            console.error(error);
                        }
                    });
                },function (context, error) {
                    if (errCallback) {
                        errCallback(error);
                    } else {
                        console.error(error);
                    }
                });
            });
        }catch(e){}
    },
    orderDrop:function ({callback,errCallback=undefined}){
        try{
            window.db.transaction(function (context) {
                context.executeSql('DROP TABLE trade', [], function (context, results) {
                    callback(results);
                },function (context, error) {
                    if (errCallback) {
                        errCallback(error);
                    } else {
                        console.error(error);
                    }
                });
            });
        }catch(e){}
    },
    subOrderCreate:function ({callback,errCallback=undefined}){
        try{
            window.db.transaction(function (context) {
                context.executeSql(`CREATE TABLE IF NOT EXISTS 'subOrder' (
                    'oid' varchar(30) NOT NULL,
                    'tid' varchar(30) DEFAULT NULL,
                    'status' varchar(32) DEFAULT NULL,
                    'consign_time' datetime,
                    'end_time' datetime,
                    'pay_time' datetime,
                    'type' varchar(32) DEFAULT NULL,
                    'created' datetime,
                    'timeout_action_time' datetime,
                    'modified' datetime,
                    'seller_rate' tinyint(4) DEFAULT NULL,
                    'buyer_rate' tinyint(4) DEFAULT NULL,
                    'num' int(11) NOT NULL,
                    'order_from' varchar(32) DEFAULT NULL,
                    'payment' varchar(32) DEFAULT NULL,
                    'price' varchar(32) DEFAULT NULL,
                    'adjust_fee' varchar(32) DEFAULT NULL,
                    'discount_fee' varchar(32) DEFAULT NULL,
                    'refund_id' int(11) DEFAULT NULL,
                    'refund_status' varchar(32) DEFAULT NULL ,
                    'item_meal_name' varchar(150) DEFAULT NULL,
                    'item_meal_id' bigint(20) DEFAULT NULL,
                    'pic_path' varchar(250) DEFAULT NULL,
                    'outer_iid' varchar(50) DEFAULT NULL,
                    'cid' bigint(20) DEFAULT NULL,
                    'title' varchar(200) NOT NULL,
                    'num_iid' int(20) DEFAULT NULL,
                    'sku_id' varchar(40) DEFAULT NULL,
                    'outer_sku_id' varchar(50) DEFAULT NULL,
                    'sku_properties_name' varchar(120) DEFAULT NULL,
                    'invoice_no' varchar(32) DEFAULT NULL,
                    PRIMARY KEY ('oid'))`, [],
                function (context, results) {
                    context.executeSql('CREATE INDEX IDX_TID ON subOrder (`tid`)');
                    context.executeSql('CREATE INDEX IDX_OID ON subOrder (`oid`)');
                    context.executeSql('CREATE INDEX IDX_TITLE ON subOrder (`title`)');
                    callback(results);
                },function (context, error) {
                    if (errCallback) {
                        errCallback(error);
                    } else {
                        console.error(error);
                    }

                });

                //查看索引
                // window.db.transaction(function (context) {
                //     context.executeSql('SELECT * FROM sqlite_master WHERE type = ?', ['index'], function (context, results) {
                //         console.log(results);
                //     },function (context, error) {
                //         if (errCallback) {
                //             errCallback(error);
                //         } else {
                //             console.log(error);
                //         }
                //     });
                // });
            });
        }catch(e){}
    },
    subOrderInsert:function ({tid,data,callback,errCallback=undefined}){
        let count = 0;
        let index = 0;
        for (var i = 0; i < data.length; i++) {
            try{
                window.db.transaction(function (context) {
                    context.executeSql('INSERT OR REPLACE INTO subOrder (`oid`,`tid`,`status`,`consign_time`,`end_time`,`pay_time`,`type`,`created`,`timeout_action_time`,`modified`,`seller_rate`,`buyer_rate`,`num`,`order_from`,`payment`,`price`,`adjust_fee`,`discount_fee`,`refund_id`,`refund_status`,`item_meal_name`,`item_meal_id`,`pic_path`,`outer_iid`,`cid`,`title`,`num_iid`,`sku_id`,`outer_sku_id`,`sku_properties_name`,`invoice_no`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                     [data[index].oid,
                      tid,
                      data[index].status?data[index].status:'',
                      data[index].consign_time?data[index].consign_time:'',
                      data[index].end_time?data[index].end_time:'',
                      data[index].pay_time?data[index].pay_time:'',
                      data[index].type?data[index].type:'',
                      data[index].created?data[index].created:'',
                      data[index].timeout_action_time?data[index].timeout_action_time:'',
                      data[index].modified?data[index].modified:'',
                      data[index].seller_rate?data[index].seller_rate:'',
                      data[index].buyer_rate?data[index].buyer_rate:'',
                      data[index].num?data[index].num:'',
                      data[index].order_from?data[index].order_from:'',
                      data[index].payment?data[index].payment:'',
                      data[index].price?data[index].price:'',
                      data[index].adjust_fee?data[index].adjust_fee:'',
                      data[index].discount_fee?data[index].discount_fee:'',
                      data[index].refund_id?data[index].refund_id:'',
                      data[index].refund_status?data[index].refund_status:'',
                      data[index].item_meal_name?data[index].item_meal_name:'',
                      data[index].item_meal_id?data[index].item_meal_id:'',
                      data[index].pic_path?data[index].pic_path:'',
                      data[index].outer_iid?data[index].outer_iid:'',
                      data[index].cid?data[index].cid:'',
                      data[index].title?data[index].title:'',
                      data[index].num_iid?data[index].num_iid:'',
                      data[index].sku_id?data[index].sku_id:'',
                      data[index].outer_sku_id?data[index].outer_sku_id:'',
                      data[index].sku_properties_name?data[index].sku_properties_name:'',
                      data[index].invoice_no?data[index].invoice_no:''],
                    function (context, results) {
                        count++;
                        if (count>=data.length) {   //子订单全部插入成功
                            callback(results);
                        } else {
                            // statement
                        }

                    },function (context, error) {
                        count++;
                        if (errCallback) {
                            if (count>=data.length) {   //子订单全部插入成功
                                errCallback(error);
                            } else {
                                // statement
                            }
                        } else {
                            console.error(error);
                        }
                    });
                    index++;
                });
            }catch(e){}
        }
    },
    subOrderSelect:function ({sql,callback,errCallback=undefined}){
        try{
            window.db.transaction(function (context) {
                context.executeSql(sql, [], function (context, results) {
                    callback(results);
                },function (context, error) {
                    if (errCallback) {
                        errCallback(error);
                    } else {
                        console.error(error);
                    }
                });
            });
        }catch(e){}
    },
    subOrderDelete:function ({tid,callback,errCallback=undefined}){
        try{
            window.db.transaction(function (context) {
                context.executeSql('DELETE FROM subOrder WHERE tid = ?', [tid], function (context, results) {
                    callback(results);
                },function (context, error) {
                    if (errCallback) {
                        errCallback(error);
                    } else {
                        console.error(error);
                    }
                });
            });
        }catch(e){}
    },
    subOrderDrop:function ({callback,errCallback=undefined}){
        try{
            window.db.transaction(function (context) {
                context.executeSql('DROP TABLE subOrder', [], function (context, results) {
                    callback(results);
                },function (context, error) {
                    if (errCallback) {
                        errCallback(error);
                    } else {
                        console.error(error);
                    }
                });
            });
        }catch(e){}
    },
    tableDrop:function ({callback,errCallback=undefined}){
        if(!window.db){
            window.db = openDatabase(encodeURIComponent(window.userInfo.userNick), '1.0', 'trade', 1024 * 1024 * 1024);
        }
        try{
            window.db.transaction(function (context) {
                context.executeSql('DELETE FROM  trade', [], function (context, results) {
                    context.executeSql('DELETE FROM  subOrder', [], function (context, results) {
                    callback(results);
                    },function (context, error) {
                        if (errCallback) {
                            errCallback(error);
                        } else {
                            console.error(error);
                        }
                    });
                },function (context, error) {
                    callback(error);
                });
            });
        }catch(e){}
    },
    tableDropAll:function ({callback}){
        try{
            window.db.transaction(function (context) {
            //查询trade表中有没有trade_attr 这个字段  一旦sql报错表示没有表或者表中没有trade_attr字段
            context.executeSql('SELECT * FROM trade WHERE yfx_fee = ?', [undefined], function (context, results) {
                    callback(results);
                },function (context, error) {
                    //无论有没有表都先进行删表操作
                    localStorage.removeItem('hasGetAll_' + window.userInfo.userNick)
                    context.executeSql('DROP TABLE trade', [], function (context, results) {
                        context.executeSql('DROP TABLE subOrder', [], function (context, results) {
                            callback(results);
                        },function (context, error) {
                            callback(error);
                        });
                    },function (context, error) {
                        context.executeSql('DROP TABLE subOrder', [], function (context, results) {
                            callback(results);
                        },function (context, error) {
                            callback(error);
                        });
                    });
                });
            });
        }catch(e){}
    },
    tradeSearch:function ({query,param = [],callback,errCallback=undefined}){
        window.db.transaction(function (context) {
            context.executeSql(query, param, function (context, result) {
                callback(result);
            },function (context, error) {
                if (errCallback) {
                    errCallback(error);
                } else {
                    console.error(error);
                }
            });
        });
    },
    orderSelectWithUnion:function ({query,callback,errCallback=undefined}){
        let option = '';
        if (query.type == 'WAIT_SELLER_SEND_GOODS') {
          option = option + "(status = 'WAIT_SELLER_SEND_GOODS' OR status = 'SELLER_CONSIGNED_PART')";
        } else {
          option = option + "(status = 'WAIT_BUYER_CONFIRM_GOODS')";
        }
        if (localStorage.getItem(`union_${window.userInfo.userNick}`) == '1') {
            try{
                window.db.transaction(function (context) {
                    // 接口提供基本的过滤条件
                    let sortStyle = localStorage.getItem('sortStyle_'+window.userInfo.userNick) ? localStorage.getItem('sortStyle_'+window.userInfo.userNick) : 'ORDER BY pay_time ASC';
                    context.executeSql("SELECT *,count(*) as cnt FROM trade WHERE " + option + " GROUP BY buyer_nick,receiver_phone,receiver_mobile,receiver_zip,receiver_address,receiver_state,receiver_city,receiver_district,receiver_country,receiver_town,receiver_name,consign_time " + sortStyle, [], function (context, unionResult) {
                        //合单后订单总数
                        context.executeSql("SELECT * FROM trade WHERE " + option + sortStyle, [], function (context, result) {
                            let trades = [];
                            let tids = new Set();
                            let index = 0
                            let count = 0;
                            //循环组主订单
                            for (var i = 0; i < unionResult.rows.length; i++) {
                                if (unionResult.rows[index].promotion_details) {
                                    unionResult.rows[index].promotion_details = JSON.parse(unionResult.rows[index].promotion_details);
                                } else {
                                }
                                if (unionResult.rows[index].service_orders) {
                                    unionResult.rows[index].service_orders = JSON.parse(unionResult.rows[index].service_orders);
                                } else {
                                }
                                if (unionResult.rows[index].is_o2o_passport == 1 || unionResult.rows[index].is_o2o_passport == '1') {
                                    unionResult.rows[index].is_o2o_passport = true;
                                } else {
                                    unionResult.rows[index].is_o2o_passport = false;
                                }
                                let j = i;
                                trades.push(Object.assign({},unionResult.rows[i]));
                                count++;
                                if (unionResult.rows[i].cnt > 1) {
                                    context.executeSql("SELECT * FROM trade WHERE  tid != ? AND buyer_nick = ? AND receiver_phone = ? AND receiver_mobile = ? AND receiver_zip = ? AND receiver_address = ? AND receiver_state = ? AND receiver_city = ? AND receiver_district = ? AND receiver_country = ? AND receiver_town = ? AND receiver_name = ? AND consign_time = ? AND" + option + sortStyle,
                                     [unionResult.rows[i].tid
                                     ,unionResult.rows[i].buyer_nick
                                     ,unionResult.rows[i].receiver_phone
                                     ,unionResult.rows[i].receiver_mobile
                                     ,unionResult.rows[i].receiver_zip
                                     ,unionResult.rows[i].receiver_address
                                     ,unionResult.rows[i].receiver_state
                                     ,unionResult.rows[i].receiver_city
                                     ,unionResult.rows[i].receiver_district
                                     ,unionResult.rows[i].receiver_country
                                     ,unionResult.rows[i].receiver_town
                                     ,unionResult.rows[i].receiver_name
                                     ,unionResult.rows[i].consign_time
                                 ], function (context, unionSingleResult) {
                                     count = count + unionSingleResult.rows.length;
                                     for (let k = 0; k < unionSingleResult.rows.length; k++) {
                                         if (unionSingleResult.rows[k].union == 0) {
                                             trades.push(Object.assign({},unionSingleResult.rows[k]));
                                         }else{
                                             if (trades[j].union == 0) {
                                                 trades.push(Object.assign({},trades[j]));
                                                 trades[j] = Object.assign({},unionSingleResult.rows[k]);
                                             } else {
                                                 trades[j].tid = trades[j].tid + ',' + unionSingleResult.rows[k].tid;
                                                 trades[j].buyer_message = trades[j].buyer_message + '!@#,#@!' + unionSingleResult.rows[k].buyer_message;
                                                 trades[j].seller_memo = trades[j].seller_memo + '!@#,#@!' + unionSingleResult.rows[k].seller_memo;
                                                 trades[j].seller_flag = trades[j].seller_flag + ',' + unionSingleResult.rows[k].seller_flag;
                                                 trades[j].payment = trades[j].payment + ',' + unionSingleResult.rows[k].payment;
                                                 trades[j].post_fee = trades[j].post_fee + ',' + unionSingleResult.rows[k].post_fee;
                                                 trades[j].status = trades[j].status + ',' + unionSingleResult.rows[k].status;
                                                 trades[j].type = trades[j].type + ',' + unionSingleResult.rows[k].type;
                                                 trades[j].created = trades[j].created + ',' + unionSingleResult.rows[k].created;
                                                 trades[j].pay_time = trades[j].pay_time + ',' + unionSingleResult.rows[k].pay_time;
                                                 trades[j].has_buyer_message = trades[j].has_buyer_message + ',' + unionSingleResult.rows[k].has_buyer_message;
                                             }
                                         }
                                     }
                                     if (count == result.rows.length) { //所有订单已经组合完成  准备取子订单
                                         makeUpSubOrder(context,trades,callback);
                                     }
                                 },function (context, error) {
                                     if (errCallback) {
                                         errCallback(error);
                                     } else {
                                         console.error(error);
                                     }
                                 });

                                }else{
                                    if (count == result.rows.length) { //所有订单已经组合完成  准备取子订单
                                        makeUpSubOrder(context,trades,callback);
                                    }
                                }

                            }


                        },function (context, error) {
                            if (errCallback) {
                                errCallback(error);
                            } else {
                                console.error(error);
                            }
                        });
                    },function (context, error) {
                        if (errCallback) {
                            errCallback(error);
                        } else {
                            console.error(error);
                        }
                    });
                });
            }catch(e){
                if (errCallback) {
                    errCallback(e);
                } else {
                    console.error(e);
                }
            }
        } else{
            try{
                window.db.transaction(function (context) {
                    // 接口提供基本的过滤条件
                    let sortStyle = localStorage.getItem('sortStyle_'+window.userInfo.userNick) ? localStorage.getItem('sortStyle_'+window.userInfo.userNick) : 'ORDER BY pay_time ASC';
                    //合单后订单总数
                    context.executeSql("SELECT * FROM trade WHERE " + option + sortStyle, [], function (context, result) {
                        let trades = [];
                        let tids = new Set();
                        let index = 0
                        for (var i = 0; i < result.rows.length; i++) {
                            if (result.rows[index].promotion_details) {
                                result.rows[index].promotion_details = JSON.parse(result.rows[index].promotion_details);
                            } else {
                            }
                            if (result.rows[index].service_orders) {
                                result.rows[index].service_orders = JSON.parse(result.rows[index].service_orders);
                            } else {
                            }
                            if (result.rows[index].is_o2o_passport == 1 || result.rows[index].is_o2o_passport == '1') {
                                result.rows[index].is_o2o_passport = true;
                            } else {
                                result.rows[index].is_o2o_passport = false;
                            }
                            trades.push(result.rows[i]);
                        }
                        makeUpSubOrder(context,trades,callback);
                    },function (context, error) {
                        if (errCallback) {
                            errCallback(error);
                        } else {
                            console.error(error);
                        }
                    });
                });
            }catch(e){
                if (errCallback) {
                    errCallback(e);
                } else {
                    console.error(e);
                }
            }
        }
    },

    /**
     * type : 1所有订单改为合单状态自动拆开非合单状态订单 0全都是拆单状态
     */
    unionSet:function ({type,callback,errCallback=undefined}){
        try{
            window.db.transaction(function (context) {
                context.executeSql("UPDATE trade SET `union` = ? WHERE (status = 'WAIT_SELLER_SEND_GOODS' OR status = 'SELLER_CONSIGNED_PART' OR status = 'WAIT_BUYER_CONFIRM_GOODS') ", [type], function (context, results) {
                    if (type == 1) {
                        api({
                            method:'/set/getUnion',
                            mode:'json',
                            callback:(rsp)=>{
                                window.db.transaction(function (context) {
                                    context.executeSql("UPDATE trade SET `union` = 0 WHERE tid in (" + rsp.result.join(',') + ")", [], function (context, results) {
                                        callback(results);
                                    },function (context, error) {

                                    });
                                });
                            }
                        })
                    } else {
                        callback(results);
                    }
                },function (context, error) {
                    if (errCallback) {
                        errCallback(error);
                    } else {
                        console.error(error);
                    }
                });
            });
        }catch(e){}
    },
    setTradeWithoutUnion:function ({callback,errCallback=undefined}){
        api({
            method:'/set/getUnion',
            mode:'json',
            callback:(rsp)=>{
                try{
                    window.db.transaction(function (context) {
                        context.executeSql("UPDATE trade SET `union` = 0 WHERE tid in (" + rsp.result.join(',') + ")", [], function (context, results) {
                            callback(results);
                        },function (context, error) {

                        });
                    });
                }catch(e){}
            }
        })
    }
};
/**
 * 根据主订单信息取子订单信息
 */
function makeUpSubOrder(context,trades,callback){
    let count = 0;
    if (trades.length == 0) {
        let results = {}
        results = {
            trades_sold_get_response:{
                total_results: 0
            }
        }
        callback(results);
        return;
    }
    for (let trade of trades) {
        if (trade) {
            context.executeSql('SELECT * FROM subOrder WHERE tid in (' + trade.tid.split(',') + ')', [], function (context, orderResult) {
                count++;
                let orders = []
                for (var i = 0; i < orderResult.rows.length; i++) {
                    orders.push(orderResult.rows[i]);
                }
                trade.orders = {
                    order: orders
                }
                if (count >= trades.length) {
                    let results = {}
                    if (trades.length == 0) {
                        results = {
                            trades_sold_get_response:{
                                total_results: 0
                            }
                        }
                    } else {
                        results = {
                            trades_sold_get_response:{
                                total_results: trades.length,
                                trades: {
                                    trade: trades
                                }
                            }
                        }
                    }
                    callback(results);
                }
            },function (context, error) {
                if (errCallback) {
                    errCallback(error);
                } else {
                    console.error(error);
                }
            });
        }
    }




    // for (let trade of trades) {
    //     if (trade) {
    //         temp.push(trade.tid);
    //     }
    // }
    //
    // context.executeSql('SELECT * FROM subOrder WHERE tid in (' + temp.join(',') + ')', [], function (context, orderResult) {
    //     console.time('makeUpSubOrder');
    //     for (var trade of trades){   //循环组子订单
    //         if (!trade) {
    //             continue;
    //         }
    //         let orders = []
    //         for (var index in orderResult.rows){
    //             if (trade.tid.indexOf(orderResult.rows[index].tid) > -1) {  //子订单tid和tid
    //                 orders.push(orderResult.rows[index]);
    //             } else {
    //                 // statement
    //             }
    //         }
    //         trade.orders = {
    //             order: orders
    //         }
    //     }
        // let results = {}
        // if (trades.length == 0) {
        //     results = {
        //         trades_sold_get_response:{
        //             total_results: 0
        //         }
        //     }
        // } else {
        //     results = {
        //         trades_sold_get_response:{
        //             total_results: trades.length,
        //             trades: {
        //                 trade: trades
        //             }
        //         }
        //     }
        // }
    //     console.timeEnd('makeUpSubOrder');
    //     callback(results);
    // },function (context, error) {
    //     if (errCallback) {
    //         errCallback(error);
    //     } else {
    //         console.error(error);
    //     }
    // });
}

export default WebSql;
