import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';

let defaultFields = 'refund_id,alipay_no,tid,oid,buyer_nick,seller_nick,total_fee,status,created,refund_fee,good_status,has_good_return,payment,reason,desc,num_iid,title,price,num,good_return_time,company_name,sid,address,shipping_type,refund_remind_timeout,refund_phase,refund_version,operation_contraint,attribute,outer_id,sku';

function taobaoRefundGet({query,callback,errCallback=undefined}){
    query.fields = query.fields ? query.fields : defaultFields;
    qnapi({
      	api:'taobao.refund.get',
      	params:query,
      	callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
            	errCallback(error);
            } else {
            	ErrorDialog('温馨提示','获取单笔退款详情失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoRefundGet;
