import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';

let defaultFields = 'content,owner_role,created,owner_nick,pic_urls';

function taobaoRefundMessagesGet({query,callback,errCallback=undefined}){
    query.fields = query.fields ? query.fields : defaultFields;
    if(window.userInfo.sellerInfo){
        if(window.userInfo.sellerInfo.type == "B"){
            query.refund_phase = "onsale";
        }
    }
    qnapi({
      	api:'taobao.refund.messages.get',
      	params:query,
      	callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
            	errCallback(error);
            } else {
            	ErrorDialog('温馨提示','获取退款详情失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoRefundMessagesGet;
