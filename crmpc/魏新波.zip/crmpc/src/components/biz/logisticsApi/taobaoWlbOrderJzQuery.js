import {qnapi} from 'utils/index';
import Tools from 'utils';
import ErrorDialog from 'publicComponents/errorDialog/index';

/**
 * 查询家装服务商列表
 * @param  {[type]} options.query       [description]
 * @param  {[type]} options.callback    [description]
 * @param  {[type]} options.errCallback [description]
 */
function taobaoWlbOrderJzQuery({query,callback,errCallback=undefined}){
    qnapi({
        api:'taobao.wlb.order.jz.query',
        params:query,
        callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','查询家装服务商列表失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoWlbOrderJzQuery;
