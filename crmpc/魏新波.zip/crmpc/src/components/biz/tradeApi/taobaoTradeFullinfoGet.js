import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';
import WebSql from 'components/biz/webSql/index';

let defaultFields = 'step,modified,timeout_action_time,end_time,pay_time,consign_time,rate_status,seller_nick,shipping_type,cod_status,orders.oid,orders.oid_str,orders.outer_iid,orders.outer_sku_id,orders.consign_time,tid,tid_str,status,end_time,buyer_nick,trade_from,credit_card_fee,buyer_rate,seller_rate,created,num,payment,pic_path,has_buyer_message,receiver_country,receiver_state,receiver_city,receiver_district,receiver_town,receiver_address,receiver_zip,receiver_name,receiver_mobile,receiver_phone,orders.timeout_action_time,orders.end_time,orders.title,orders.status,orders.price,orders.payment,orders.sku_properties_name,orders.num_iid,orders.refund_id,orders.pic_path,orders.refund_status,orders.num,orders.logistics_company,orders.invoice_no,orders.adjust_fee,seller_flag,type,post_fee,is_daixiao,has_yfx,yfx_fee,buyer_message,buyer_flag,buyer_memo,seller_memo,orders.seller_rate,adjust_fee,invoice_name,invoice_type,invoice_kind,promotion_details,alipay_no,buyerTaxNO,pbly,orders,total_fee,orders.cid,service_orders.tmser_spu_code';

function taobaoTradeFullinfoGet({query,callback,errCallback=undefined,forceRefresh = false}){
    if(window.page != 'tradeManagement') forceRefresh = true;
    query.fields = query.fields ? query.fields : defaultFields;
    if (!forceRefresh) {
        WebSql.orderSelectWithTid({
            query:query,
            callback:(rsp)=>{
                // callback(rsp);
                if (rsp.trade_fullinfo_get_response) {   //websql有数据
                    callback(rsp);
                } else {   //没有数据
                    if (query.fields == defaultFields) {   //所有字段全都取  要存到websql里
                        qnapi({
                            api:'taobao.trade.fullinfo.get',
                            params:query,
                            callback:(rsp)=>{
                                if (rsp.trade_fullinfo_get_response.trade.status == 'WAIT_SELLER_SEND_GOODS' || rsp.trade_fullinfo_get_response.trade.status == 'WAIT_BUYER_CONFIRM_GOODS' || rsp.trade_fullinfo_get_response.trade.status == 'SELLER_CONSIGNED_PART') {
                                      //存起来
                                      let trades = [];
                                      trades.push(rsp.trade_fullinfo_get_response.trade);
                                      trades[0].fullinfo = 1;
                                      WebSql.orderInsert({
                                          datas: trades,
                                          callback:(rsp)=>{
                                          }
                                      })
                                } else {
                                    //其他状态先不存
                                }
                                callback(rsp);
                            },
                            errCallback:(error)=>{
                                if (errCallback) {
                                  errCallback(error);
                                } else {
                                  console.error(error);
                                  ErrorDialog('温馨提示','获取订单失败，请稍候再试！',JSON.stringify(error));
                                }
                            }
                        });
                    } else {  // 只调用我想要的字段 这时直接取接口
                        qnapi({
                            api:'taobao.trade.fullinfo.get',
                            params:query,
                            callback:(rsp)=>{
                                callback(rsp);
                            },
                            errCallback:(error)=>{
                                if (errCallback) {
                                  errCallback(error);
                                } else {
                                  console.error(error);
                                  ErrorDialog('温馨提示','获取订单失败，请稍候再试！',JSON.stringify(error));
                                }
                            }
                        });
                    }
                }
            },errCallback:(rsp)=>{
                query.fields == defaultFields;
                qnapi({
                    api:'taobao.trade.fullinfo.get',
                    params:query,
                    callback:(rsp)=>{
                        if (rsp.trade_fullinfo_get_response.trade.status == 'WAIT_SELLER_SEND_GOODS' || rsp.trade_fullinfo_get_response.trade.status == 'WAIT_BUYER_CONFIRM_GOODS' || rsp.trade_fullinfo_get_response.trade.status == 'SELLER_CONSIGNED_PART') {
                              //存起来
                              let trades = [];
                              trades.push(rsp.trade_fullinfo_get_response.trade);
                              trades[0].fullinfo = 1;
                              WebSql.orderInsert({
                                  datas: trades,
                                  callback:(rsp)=>{

                                  }
                              })
                        } else {

                        }
                        callback(rsp);
                    },
                    errCallback:(error)=>{
                        if (errCallback) {
                          errCallback(error);
                        } else {
                          console.error(error);
                          ErrorDialog('温馨提示','获取订单失败，请稍候再试！',JSON.stringify(error));
                        }
                    }
                });
            }
        })
    } else {
        qnapi({
            api:'taobao.trade.fullinfo.get',
            params:query,
            callback:(rsp)=>{
                if (rsp.trade_fullinfo_get_response.trade.status == 'WAIT_SELLER_SEND_GOODS' || rsp.trade_fullinfo_get_response.trade.status == 'WAIT_BUYER_CONFIRM_GOODS' || rsp.trade_fullinfo_get_response.trade.status == 'SELLER_CONSIGNED_PART') {
                    //存起来
                    let trades = [];
                    trades.push(rsp.trade_fullinfo_get_response.trade);
                    trades[0].fullinfo = 1;
                    WebSql.orderInsert({
                        datas: trades,
                        callback:(rsp)=>{

                        }
                    })
                } else {

                }
                callback(rsp);
            },
            errCallback:(error)=>{
                if (errCallback) {
                  errCallback(error);
                } else {
                  console.error(error);
                  ErrorDialog('温馨提示','获取订单失败，请稍候再试！',JSON.stringify(error));
                }
            }
        });
    }

}

export default taobaoTradeFullinfoGet;
