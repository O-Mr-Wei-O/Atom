import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';

function taobaoTradeClose({query,callback,errCallback=undefined}){
    qnapi({
        api : 'taobao.trade.close',
        params : {
            tid:query.tid,
            close_reason:query.close_reason
        },
       	callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','关闭订单失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoTradeClose;
