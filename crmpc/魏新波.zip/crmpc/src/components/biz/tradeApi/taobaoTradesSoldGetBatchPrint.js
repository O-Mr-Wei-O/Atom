import {qnapi,api,isEmpty,beacon} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';
import WebSql from 'components/biz/webSql/index';
//import taobaoTradesSoldIncrementGet from './taobaoTradesSoldIncrementGet';
import taobaoTradeFullinfoGet from './taobaoTradeFullinfoGet';
import moment from 'moment';

let defaultFields   = 'modified,timeout_action_time,end_time,pay_time,adjust_fee,discount_fee,consign_time,rate_status,seller_nick,shipping_type,cod_status,orders.oid,orders.oid_str,orders.outer_iid,orders.outer_sku_id,orders.consign_time,tid,tid_str,status,end_time,buyer_nick,trade_from,credit_card_fee,buyer_rate,seller_rate,created,num,payment,pic_path,has_buyer_message,receiver_country,receiver_state,receiver_city,receiver_district,receiver_town,receiver_address,receiver_zip,receiver_name,receiver_mobile,receiver_phone,orders.timeout_action_time,orders.adjust_fee,orders.discount_fee,orders.end_time,orders.title,orders.status,orders.price,orders.payment,orders.sku_properties_name,orders.num_iid,orders.refund_id,orders.pic_path,orders.refund_status,orders.num,orders.logistics_company,orders.invoice_no,seller_flag,type,post_fee,is_daixiao,has_yfx,yfx_fee,buyer_message,buyer_flag,buyer_memo,seller_memo,orders.seller_rate,orders.cid,service_orders.tmser_spu_code';
let defaultType     = 'fixed,auction,guarantee_trade,step,independent_simple_trade,independent_shop_trade,auto_delivery,ec,cod,game_equipment,shopex_trade,netcn_trade,external_trade,instant_trade,b2c_cod,hotel_trade,super_market_trade,super_market_cod_trade,taohua,waimai,nopaid,step,eticket,tmall_i18n,o2o_offlinetrade';
let defaultPageNo   = 1;
let defaultPageSize = 60;
/**
 * [taobao.trades.sold.get]
 * @param  {[type]}  options.query        [description]
 * @param  {[type]}  options.callback     [description]
 * @param  {[type]}  options.errCallback  [description]
 * @param  {Boolean} options.forceRefresh [默认为false  为websql做容错如果 websql出了问题 会在调一次这个强制去取淘宝数据]
 * @return {[type]}                       [description]
 */
function taobaoTradesSoldGetBatchPrint({query,callback,errCallback=undefined}){
    query.fields    = query.fields ? query.fields : defaultFields;
    query.type      = query.type ? query.type : defaultType;
    query.page_no   = query.page_no ? query.page_no : defaultPageNo;
    query.page_size = query.page_size ? query.page_size : defaultPageSize;
    query.use_has_next = true;
    qnapi({
        api:'taobao.trades.sold.get',
        params:query,
        callback:(rsp)=>{
            if (rsp.error_response) {
                localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
                return;
            } else {
                // statement
            }
            if (rsp.trades_sold_get_response.trades && rsp.trades_sold_get_response.trades.trade) {
                WebSql.orderInsert({
                    datas: rsp.trades_sold_get_response.trades.trade,
                    callback:(rsp)=>{
                    }
                })
                if (localStorage.getItem('subUserAuth')) { //糟糕 授权失效了 并且登陆的是子账号
                    if (trade.has_buyer_message && trade.seller_flag != 0) {
                       taobaoTradeFullinfoGet({
                            query:{
                                tid:trade.tid
                            },
                            forceRefresh:true,
                            callback:(rsp)=>{
                                console.error(rsp);
                            }
                        })
                    } else {
                        // statement
                    }
                } else {
                    let tid = [];
                    for (var index in rsp.trades_sold_get_response.trades.trade) {
                        if (rsp.trades_sold_get_response.trades.trade[index].has_buyer_message || rsp.trades_sold_get_response.trades.trade[index].seller_flag != 0) {
                           tid.push(rsp.trades_sold_get_response.trades.trade[index].tid);
                        } else {
                            // statement
                        }
                        if (tid.length == 20) {
                            //查fullinfo  每20单调一次
                            let defaultFields = 'pbly,modified,timeout_action_time,end_time,pay_time,consign_time,rate_status,seller_nick,shipping_type,cod_status,orders.oid,orders.oid_str,orders.outer_iid,orders.outer_sku_id,orders.consign_time,tid,tid_str,status,end_time,buyer_nick,trade_from,credit_card_fee,buyer_rate,seller_rate,created,num,payment,pic_path,has_buyer_message,receiver_country,receiver_state,receiver_city,receiver_district,receiver_town,receiver_address,receiver_zip,receiver_name,receiver_mobile,receiver_phone,orders.timeout_action_time,orders.end_time,orders.title,orders.status,orders.price,orders.payment,orders.sku_properties_name,orders.num_iid,orders.refund_id,orders.pic_path,orders.refund_status,orders.num,orders.logistics_company,orders.invoice_no,orders.adjust_fee,seller_flag,type,post_fee,is_daixiao,has_yfx,yfx_fee,buyer_message,buyer_flag,buyer_memo,seller_memo,orders.seller_rate,adjust_fee,invoice_name,invoice_type,invoice_kind,promotion_details,alipay_no,buyerTaxNO,pbly,orders,total_fee,orders.cid,service_orders.tmser_spu_code';
                            api({
                                method:'/router/batch',
                                mode:'json',
                                args:{
                                    method:'taobao.trade.fullinfo.get',
                                    'param[fields]':defaultFields,
                                    'value[tid]':tid
                                },
                                isloading:false,
                                callback:(result)=>{
                                    let trades = [];
                                    for (let trade of result) {
                                        trade.trade_fullinfo_get_response.trade.fullinfo = 1;
                                        if (trade.trade_fullinfo_get_response) {
                                            trades.push(trade.trade_fullinfo_get_response.trade);
                                        }else{
                                            console.log('trade_fullinfo_get_response error');
                                        }
                                    }

                                    WebSql.orderInsert({
                                        datas: trades,
                                        callback:(result)=>{
                                            if ((rsp.trades_sold_get_response.trades.trade.length == 20 && query.page_no == 1) || rsp.trades_sold_get_response.trades.trade.length == Number(index) + 1) {
                                                callback('666');
                                            }else{

                                            }
                                        }
                                    })
                                },
                                errCallback:(error)=>{
                                    console.error(error);
                                    localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
                                }
                            })
                            tid = [];
                        } else {
                            if ((Number(index) + 1) == rsp.trades_sold_get_response.trades.trade.length && tid.length > 0) {
                                let defaultFields = 'pbly,modified,timeout_action_time,end_time,pay_time,consign_time,rate_status,seller_nick,shipping_type,cod_status,orders.oid,orders.oid_str,orders.outer_iid,orders.outer_sku_id,orders.consign_time,tid,tid_str,status,end_time,buyer_nick,trade_from,credit_card_fee,buyer_rate,seller_rate,created,num,payment,pic_path,has_buyer_message,receiver_country,receiver_state,receiver_city,receiver_district,receiver_town,receiver_address,receiver_zip,receiver_name,receiver_mobile,receiver_phone,orders.timeout_action_time,orders.end_time,orders.title,orders.status,orders.price,orders.payment,orders.sku_properties_name,orders.num_iid,orders.refund_id,orders.pic_path,orders.refund_status,orders.num,orders.logistics_company,orders.invoice_no,orders.adjust_fee,seller_flag,type,post_fee,is_daixiao,has_yfx,yfx_fee,buyer_message,buyer_flag,buyer_memo,seller_memo,orders.seller_rate,adjust_fee,invoice_name,invoice_type,invoice_kind,promotion_details,alipay_no,buyerTaxNO,pbly,orders,total_fee,orders.cid,service_orders.tmser_spu_code';
                                api({
                                    method:'/router/batch',
                                    mode:'json',
                                    args:{
                                        method:'taobao.trade.fullinfo.get',
                                        'param[fields]':defaultFields,
                                        'value[tid]':tid
                                    },
                                    isloading:false,
                                    callback:(result)=>{
                                        let trades = [];
                                        for (let trade of result) {
                                            trade.trade_fullinfo_get_response.trade.fullinfo = 1;
                                            if (trade.trade_fullinfo_get_response) {
                                                trades.push(trade.trade_fullinfo_get_response.trade);
                                            }else{
                                                console.log('trade_fullinfo_get_response error');
                                            }
                                        }
                                        WebSql.orderInsert({
                                            datas: trades,
                                            callback:(result)=>{
                                                if (rsp.trades_sold_get_response.trades.trade.length == Number(index) + 1 && query.page_no == 1) {
                                                    callback('666');
                                                }else{
                                                }
                                            }
                                        })
                                    },
                                    errCallback:(error)=>{
                                        console.error(error);
                                        localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
                                    }
                                })
                                tid = [];
                            } else if ((Number(index) + 1) == rsp.trades_sold_get_response.trades.trade.length && tid.length == 0) {
                                callback('666');
                            } else {
                                // statement
                            }
                        }
                    }
                }
            } else {
                //没订单 容错
            }
            if (!rsp.trades_sold_get_response.has_next) {
                localStorage.setItem('batchSendHasGetNoSend_' + window.userInfo.userNick,1);
                if (query.page_no != 1) {
                    callback('666');
                }
            } else {
                query.page_no = query.page_no + 1;
                taobaoTradesSoldGetBatchPrint({
                    query: query,
                    callback:callback,
                    errCallback:errCallback
                })
            }
        },
        errCallback:(error)=>{
            ErrorDialog('温馨提示','获取订单失败，请稍候再试！',JSON.stringify(error));
        }
    })

}

export default taobaoTradesSoldGetBatchPrint;
