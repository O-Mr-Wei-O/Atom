import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';


let defaultFields = 'num_iid,pic_url,title';
function taobaoItemsOnsaleGet({query,callback,errCallback=undefined}){
    query.fields = query.fields ? query.fields : defaultFields;
    qnapi({
        api:'taobao.items.onsale.get',
        params:query,
        callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','获取当前会话用户出售中的商品列表失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoItemsOnsaleGet;
