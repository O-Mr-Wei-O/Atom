'use strict';

/**
 * Domain
 */
export default {
  trade:{
    host          : '//trade.aiyongbao.com',
    // host          : 'https://iytest.aiyongbao.com',
    article_code  : 'FW_GOODS-1827490',
    vipcode       : 'FW_GOODS-1827490-v2',
    price_type    : ['20元/月','52元/季度','78元/半年','148元/年'],
    links         : [
      'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170630195953;agentId:fuwu.taobao.com%7Cmarketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002030739]&subParams=cycleNum:1,cycleUnit:2,itemCode:FW_GOODS-1827490-v2&sign=081C7AA692E868B41E5C668E1DA725B6',
      'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170630195953;agentId:fuwu.taobao.com%7Cmarketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002030739]&subParams=cycleNum:3,cycleUnit:2,itemCode:FW_GOODS-1827490-v2&sign=4035B88340D2BD759D9CAAC8430B47BC',
      'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170630195953;agentId:fuwu.taobao.com%7Cmarketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002030739]&subParams=cycleNum:6,cycleUnit:2,itemCode:FW_GOODS-1827490-v2&sign=3BA4C370AE049B82D4BE68E3247FD615',
      'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170630195953;agentId:fuwu.taobao.com%7Cmarketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002030739]&subParams=cycleNum:12,cycleUnit:2,itemCode:FW_GOODS-1827490-v2&sign=F5ECA56F1C6AC7400A122887C2B53089'
    ],
    modal_info    :{
        'ad-text' : '升级高级版',
        'btn1-android-url' : 'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170630195953;agentId:fuwu.taobao.com%7Cmarketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002030739]&subParams=cycleNum:1,cycleUnit:2,itemCode:FW_GOODS-1827490-v2&sign=081C7AA692E868B41E5C668E1DA725B6',
        'btn1-iphone-url' : 'https://tb.cn/2TAt7hw',
        'btn1-text' : '20元/月',
        'btn2-android-url' : 'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170630195953;agentId:fuwu.taobao.com%7Cmarketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002030739]&subParams=cycleNum:3,cycleUnit:2,itemCode:FW_GOODS-1827490-v2&sign=4035B88340D2BD759D9CAAC8430B47BC',
        'btn2-iphone-url' : 'https://tb.cn/pcur7hw',
        'btn2-text' : '52元/季度',
        'btn3-android-url' : 'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170630195953;agentId:fuwu.taobao.com%7Cmarketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002030739]&subParams=cycleNum:6,cycleUnit:2,itemCode:FW_GOODS-1827490-v2&sign=3BA4C370AE049B82D4BE68E3247FD615',
        'btn3-iphone-url' : 'https://tb.cn/TCpr7hw',
        'btn3-text' : '78元/半年',
        'btn4-android-url' : 'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170630195953;agentId:fuwu.taobao.com%7Cmarketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002030739]&subParams=cycleNum:12,cycleUnit:2,itemCode:FW_GOODS-1827490-v2&sign=F5ECA56F1C6AC7400A122887C2B53089',
        'btn4-iphone-url' : 'https://tb.cn/Pzir7hw',
        'btn4-text' : '148元/年',
        're-button' : '3',
        'service' : '我要订购，20元/月 https://tb.cn/2TAt7hw \r\n 52元/季度 https://tb.cn/pcur7hw \r\n 78元/半年 https://tb.cn/TCpr7hw \r\n  148元/年 https://tb.cn/Pzir7hw\r\n',
        'subuser' : '我要订购，需要主账号才能订购，帮我订下，点击链接即可：【URL】'
    },
    creative_imgpath   : '//q.aiyongbao.com/trade/web/images/qap_img/mobile/modalVipUpdate.png',
    newuser_banner_pid : '1015',
    newuser_modal_pid  : '1014',
    beacon_proj        : 'TD20170114090141',
    beacon_event       : 'zdtcdjmdmobile'
  },
  item:{
      host          : '//item.aiyongbao.com',
      article_code  : 'FW_GOODS-1828810',
      vipcode       : 'FW_GOODS-1828810-v2',
      price_type    : ['48元/季度','78元/半年','128元/年'],
      links         : [
        'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170713203844;agentId:fuwu.taobao.com|marketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002061142]&subParams=cycleNum:3,cycleUnit:2,itemCode:FW_GOODS-1828810-v2&sign=5E242B8B4B1288D4E8A07590DC2AD00A',
        'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170713203844;agentId:fuwu.taobao.com|marketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002061142]&subParams=cycleNum:6,cycleUnit:2,itemCode:FW_GOODS-1828810-v2&sign=E66176E390E3D79227050F5310589DF0',
        'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170713203844;agentId:fuwu.taobao.com|marketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002061142]&subParams=cycleNum:12,cycleUnit:2,itemCode:FW_GOODS-1828810-v2&sign=B47CFAAE9F088494D2DAA579AEE1A2A6'
      ],
      modal_info    :{
          'ad-text' : '升级高级版',
          'btn1-android-url' : 'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170713203844;agentId:fuwu.taobao.com|marketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002061142]&subParams=cycleNum:3,cycleUnit:2,itemCode:FW_GOODS-1828810-v2&sign=5E242B8B4B1288D4E8A07590DC2AD00A',
          'btn1-iphone-url' : 'https://tb.cn/2m9Zefw',
          'btn1-text' : '48元/季度',
          'btn2-android-url' : 'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170713203844;agentId:fuwu.taobao.com|marketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002061142]&subParams=cycleNum:6,cycleUnit:2,itemCode:FW_GOODS-1828810-v2&sign=E66176E390E3D79227050F5310589DF0',
          'btn2-iphone-url' : 'https://tb.cn/utvYefw',
          'btn2-text' : '78元/半年',
          'btn3-android-url' : 'https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170713203844;agentId:fuwu.taobao.com|marketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002061142]&subParams=cycleNum:12,cycleUnit:2,itemCode:FW_GOODS-1828810-v2&sign=B47CFAAE9F088494D2DAA579AEE1A2A6',
          'btn3-iphone-url' : 'https://tb.cn/MOnYefw',
          'btn3-text' : '128元/年',
          're-button' : '3',
          'service' : '我要订购，48元/季度 https://tb.cn/2m9Zefw \r\n 78元/半年 https://tb.cn/utvYefw \r\n 128元/年 https://tb.cn/MOnYefw \r\n ',
          'subuser' : '我要订购，需要主账号才能订购，帮我订下，点击链接即可：【URL】'
      },
      creative_imgpath   : '//q.aiyongbao.com/item/web/images/qap_img/mobile/ads/ad_item_mobile.png',
      newuser_banner_pid : '1018',
      newuser_modal_pid  : '1019',
      beacon_proj        : 'TD20170117100133',
      beacon_event       : 'pay-click-mo'
  }
}
