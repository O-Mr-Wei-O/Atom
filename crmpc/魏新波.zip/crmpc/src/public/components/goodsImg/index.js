import React from 'react';
import './index.scss';

/**
 * 商品图片显示
 * img_url 图片地址
 * order_status 显示状态 不传值则不显示状态
 * @type {[type]}
 */
class GoodsImg extends React.Component {
    constructor(props) {
        super(props);
    }

    /**
     * 待付款：FFA033
        待发货：42C4CF
        已发货：4A90E2
        退款中：F23C3C
        已关闭：9B9B9B
        待评价：AF62BF
        已成功：417505
     * [render description]
     * @author zdh
     * @dateTime 2017-08-07T19:24:16+080
     * @return   {[type]}                [description]
     */
    render(){
        const {img_url,order_status} = this.props;
        let order_status_color = null;
        switch (order_status) {
            case "待付款":
                order_status_color = "#FFA033";
                break;
            case "待发货":
                order_status_color = "#42C4CF";
                break;
            case "已发货":
                order_status_color = "#4A90E2";
                break;
            case "退款中":
                order_status_color = "#F23C3C";
                break;
            case "已关闭":
                order_status_color = "#9B9B9B";
                break;
            case "待评价":
                order_status_color = "#AF62BF";
                break;
            case "已成功":
                order_status_color = "#417505";
                break;
            default:

        }

        let order_status_cell = null;
        if(order_status_color){
            order_status_cell = (
                <div className="goods-img-div-status" style={{backgroundColor:order_status_color}}>
                    {order_status}
                </div>
            );
        }

        return (
            <div className="goods-img-div">
                <img width={60} height={60}  src={`${img_url}_60x60.jpg`} alt=""/>
                {
                    order_status_cell
                }
            </div>
        );
    }
}
export default GoodsImg;
