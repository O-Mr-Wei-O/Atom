import React from 'react';
import moment from 'moment';
import './index.scss';
import Tools from 'utils';

/**
 * 爱用通告栏组件
 * @author yxm
 *  [this.props.isRender]和[this.props.callback] 用于父组件的回调刷新state，可以不传
 */
 class AYTextAlert extends React.Component{
     constructor(props){
         super(props);
         this.state = {
             isRender:props.isRender?props.isRender:false
         }
     }
     close(){
         let nowDate = moment().format('YYYY-MM-DD');
        //  let element = document.getElementById("AYTextAlert");
        //  if(element) element.parentNode.removeChild(element);
         localStorage.setItem(`${window.userInfo.userNick}CloseAYTextAlert`,nowDate);
         if(this.props.callback) this.props.callback(!this.state.isRender);
     }
     render(){
         let useA = false;
         let nowDate = moment().format('YYYY-MM-DD');
         let userInfo = window.userInfo;
         if(userInfo==undefined||userInfo==null) return
         let AYTextAlert = localStorage.getItem(`${window.userInfo.userNick}AYTextAlert`);
         if(AYTextAlert!=undefined){
             AYTextAlert = JSON.parse(AYTextAlert)
             if(!Tools.isEmpty(AYTextAlert.adlink)){
                 useA = true;
             }
         }
         if(localStorage.getItem(`${window.userInfo.userNick}CloseAYTextAlert`) == nowDate) AYTextAlert=undefined;
         return (
             <div>
                {
                    AYTextAlert!=undefined && (
                        <div id='AYTextAlert' className='single-dog-day' >
                            {
                                useA?(
                                    <a className='ad-link' target='_blank' href={AYTextAlert.adlink}>
                                         <img src="//q.aiyongbao.com/trade/web/images/qap_img/mobile/laba.png" width = "16px" height='16px' style={{marginRight:'8px'}}/>
                                         <span>{AYTextAlert.content}</span>
                                    </a>
                                )
                                :(
                                    <span className='ad-link' style={{cursor:'default'}}>
                                        <img src="//q.aiyongbao.com/trade/web/images/qap_img/mobile/laba.png" width = "16px" height='16px' style={{marginRight:'8px'}}/>
                                        <span>{AYTextAlert.content}</span>
                                    </span>
                                )
                            }
                           <div className='right'>
                               <span className='close' onClick={this.close.bind(this)}>X</span>
                           </div>
                        </div>
                    )
                }
             </div>
         )
     }
 }
 export default AYTextAlert
