import React from 'react';
import {ww,beacon} from 'utils';
class ADDialog extends React.Component {
    constructor(props) {
        super(props);

    }

    payMoney(btnUrl){
        const {clickPay,groupName,creativeId,pid,creativeName,subuser,isSubuser,wangwangPCModalAD,feedbackClicked,adBeacon} = this.props;
        let subuserStr = subuser;
        clickPay(clickPay,isSubuser,subuser,btnUrl);
        if (groupName == '交易') {
            beacon('TD20170614170642', 'zdtcdjmd', userInfo.userNick,pid,creativeName,creativeId);
        }else{
            beacon('TD20170622100602', 'pay-click-pc', userInfo.userNick,pid,creativeName,creativeId);
        }
        /*判断子账号*/
        if(isSubuser){
            subuserStr=subuserStr.replace("【URL】",btnUrl);
            wangwangPCModalAD(subuserStr,0);
        }else{
            /*跳转支付宝*/
            window.open(btnUrl);
        }

        adBeacon();
        feedbackClicked(btnUrl);
    }

    render(){
        const {clickPay,closeDialog,imgPath,btnGroup,adText,btnWidth,reButton,buttonImage,subuser,isSubuser} = this.props;
        let subuserStr = subuser;
        return (
            <div className="modal-ad-div">
                <div className="modal-ad-for-center">
                    <div className="ad-dialog-con">
                        <span onClick={closeDialog} className="icon-cancel-span">
                            <svg className="ad-icon-cancel">
                                <use xlinkHref="#icon-cancel"></use>
                            </svg>
                        </span>
                        <div className="ad-dialog-con-img">
                            <img width={500} height={400} src={imgPath}/>
                        </div>
                        <div className="ad-dialog-con-btn">
                            <div className="ad-dialog-con-title">
                                <img className="ad-dialog-line-left" src="http://q.aiyongbao.com/trade/web/images/adline-left.png" alt=""/>
                                {adText}
                                <img className="ad-dialog-line-right" src="http://q.aiyongbao.com/trade/web/images/adline-right.png" alt=""/>
                            </div>
                            <div className="ad-dialog-con-btn-group">
                                {
                                    btnGroup.map((value,index)=>{
                                        if(index == reButton){
                                            if(buttonImage){
                                                return (
                                                    <button onClick={()=>{
                                                        this.payMoney(value.btnUrl);
                                                    }} style={{backgroundImage:url(buttonImage)}} className={`ad-dialog-con-pay-btn con-pay-btn-${btnGroup.length}-img`}>
                                                        {
                                                            value.btnText
                                                        }
                                                    </button>
                                                );
                                            }else {
                                                return (
                                                    <button style={{backgroundColor:"#3089DC",color:"#fff"}} onClick={()=>{
                                                        this.payMoney(value.btnUrl);
                                                    }} className={`ad-dialog-con-pay-btn con-pay-btn-${btnGroup.length}`}>
                                                        {
                                                            value.btnText
                                                        }
                                                    </button>
                                                );
                                            }
                                        }else {
                                            return (
                                                <button onClick={()=>{
                                                    this.payMoney(value.btnUrl);
                                                }} className={`ad-dialog-con-pay-btn con-pay-btn-${btnGroup.length}`}>
                                                    {
                                                        value.btnText
                                                    }
                                                </button>
                                            );
                                        }
                                    })
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default ADDialog;
