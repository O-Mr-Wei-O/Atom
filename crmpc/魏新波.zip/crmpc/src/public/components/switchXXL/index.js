import React from 'react';
import {Switch} from 'qnui';
import './index.scss';

/**
 * 正方形大开关 API与quui的switch开关组件相同
 * @author zdh
 */
class SwitchXXL extends React.Component {
    constructor(props) {
        super(props);
    }
    render(){
        return (
            <span className="SwitchXXL-span">
                <Switch unCheckedChildren="关" {...this.props}/>
            </span>
        );
    }
}
export default SwitchXXL;
