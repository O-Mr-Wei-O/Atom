import React from 'react';
import {Switch} from 'qnui';
import './index.scss';

/**
 * 蓝色开关组件 API与quui的switch开关组件相同
 * @author zdh
 */
class SwitchBlue extends React.Component {
    constructor(props) {
        super(props);
    }
    render(){
        const {disabled} = this.props;
        let switchClass;
        if(disabled == true){/*禁用*/
            switchClass = "switch-blue-span-disabled";
        }else {
            switchClass = "switch-blue-span";
        }

        return (
            <span className={switchClass}>
                <Switch {...this.props}/>
            </span>
        );
    }
}
export default SwitchBlue;
