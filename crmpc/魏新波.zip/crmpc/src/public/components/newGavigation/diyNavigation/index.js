import { isEmpty } from 'utils/index';
import React from 'react';
import {Navigation,Dialog,Button,Menu} from 'qnui';
import MsgToast from 'public/components/msgToast';
import reactDragula from 'react-dragula';
const {Item} = Navigation;
import ModalAD from 'public/components/modalAD/index';
import {api,beacon} from 'utils/index';
import './index.scss';
// 实际选择的导航功能
var selectFunctionValue = new Array();
// 默认勾选复选框数据，供恢复默认时复选框使用
var itemDefaultSelect = ['mobileDesc','autoJust','autoWindow','titleOptimization','promotionWatermark','badWordTesting','batchModification'];
var tradeDefaultSelect = ['logisticsManagement','printSendnew','customPrint','refuseNegativeComment','autoRate','evaluate','smsCare'];
/**
 * @author youxiaowei
 * DIY导航条
 * 2017-10-31
 */
class diyNavigation extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            //选择的导航功能，通过该数组来控制选择数量，不大于7个，大于7个后面的不能勾选
            selectValue:[],
            //选择个数 
            selectNum:'', 
            //是否恢复默认标志
            defaultFlag:false
        };
        this.componentBackingInstance = '';
    }
    componentWillMount() {
        //获取上次导航数据
        let navigationList = '';
        if(this.props.type == "item") {
            navigationList = window.localStorage.getItem(window.userInfo.userNick + 'itemNavigationList');
        } else {
            navigationList = window.localStorage.getItem(window.userInfo.userNick + 'tradeNavigationList');
        }
        selectFunctionValue = JSON.parse(decodeURIComponent(navigationList));
        if(selectFunctionValue) {
            //同步勾选已选择的导航
            let selected = [];
            let length = selectFunctionValue.length;
            for(let i = 0;i < length;i++){
                selected[i] = selectFunctionValue[i].key;
            }
            this.setState({
                selectValue:selected,
                selectNum:length
            });
        } else {
            if(this.props.type == "item") {
                this.setState({
                    selectValue:itemDefaultSelect,
                    selectNum:itemDefaultSelect.length
                });
            } else {
                this.setState({
                    selectValue:tradeDefaultSelect,
                    selectNum:tradeDefaultSelect.length
                });
            }
            selectFunctionValue = [...this.props.defaultNavigation];
        }
    }
    /**
     * 自定义弹框底部按钮
     * @author  Jiang
     * @return {[type]} [description]
     */
    renderDialogFooter = () => {
        return (
            <div>
                <span className="selectedNum">
                    最多可选7项&nbsp;（已选：<span >{this.state.selectNum == '' ? 0 : this.state.selectNum}</span>）
                </span>
                <Button type='primary' onClick={this.confirm.bind(this)}>确定</Button>
                <Button onClick={this.resetDefault.bind(this)}>恢复默认</Button>
            </div>
        );
    }
    /**
     * [resetDefault 点击恢复默认]
     * @author  Jiang
     * @return {[type]} [description]
     */
    resetDefault() {
        // 恢复默认选项功能
        selectFunctionValue = [...this.props.defaultNavigation];
        if(this.props.type == "item") {
            this.setState({
                //恢复默认勾选项
                selectValue : itemDefaultSelect,
                selectNum   : itemDefaultSelect.length,
                defaultFlag : !this.state.defaultFlag,
            });
        } else {
            this.setState({
                selectValue : tradeDefaultSelect,
                selectNum   : tradeDefaultSelect.length,
                defaultFlag : !this.state.defaultFlag,
            });
        }
    }
    /**
     * [confirm 点击确定按钮]
     * @author  Jiang
     * @return {[type]} [description]
     */
    confirm() {
        let { onClose,buyVip,callback } = this.props;
        if(!isEmpty(window.userInfo)) {
            if(window.userInfo.vipFlag == '1') {
                onClose();
                // 保存数据到数据库里面，并将结果返回
                // 用户勾选以后，还可能拖动顺序，这里我通过获取li 的顺序，重新赋值。
                let navigationDrag = document.getElementsByClassName('navigationDragList');
                let finalSelectFunctionValue = [];
                for(let i = 0;i < navigationDrag.length;i++) {
                    if(navigationDrag[i].id == "promotionWatermark") {
                        finalSelectFunctionValue.push({
                            'key':navigationDrag[i].id,
                            'text':"促销水印",
                            'order':i,
                            'imgurl':"//q.aiyongbao.com/item/web/images/syyd4.png"
                        });
                    } else {
                        finalSelectFunctionValue.push({
                            'key':navigationDrag[i].id,
                            'text':navigationDrag[i].innerText,
                            'order':i,
                            'imgurl':navigationDrag[i].childNodes[1].children[0].attributes[0].nodeValue
                        });
                    }
                }
                selectFunctionValue = finalSelectFunctionValue;
                callback(selectFunctionValue);
                let method = '',navigationList = '';
                if(this.props.type == "item") {
                    navigationList = window.localStorage.getItem(window.userInfo.userNick + 'itemNavigationList');
                } else {
                    navigationList = window.localStorage.getItem(window.userInfo.userNick + 'tradeNavigationList');
                }
                if(navigationList === encodeURIComponent(JSON.stringify(selectFunctionValue))) {
                    return;
                }
                if(this.props.type == "item") {
                    window.localStorage.setItem(window.userInfo.userNick + 'itemNavigationList',encodeURIComponent(JSON.stringify(selectFunctionValue)));
                } else {
                    window.localStorage.setItem(window.userInfo.userNick + 'tradeNavigationList',encodeURIComponent(JSON.stringify(selectFunctionValue)));
                }
                if(this.props.type == "item") {
                    method = '/itemnavigation/savetopposition';
                } else {
                    method = '/set/savetopposition';
                }
                api({
                    method:method,
                    mode:'json',
                    args:{
                        position: encodeURIComponent(JSON.stringify(selectFunctionValue))
                    },
                    callback:(e)=>{

                    },
                    err_callback:(msg)=>{
                        ErrorDialog('温馨提示','操作失败！',msg);
                    }
                });
            } else {
                if(this.props.type == "trade") {
                    //如果不是高级版用户，弹广告框
                    buyVip();
                    onClose();
                } else {
                    let deaconObj = '';
                    beacon('TD20170622100602','1210index-setsortsure',window.userInfo.userNick);
                    if(this.props.itemPid == 889) {
                        deaconObj = ['TD20170622100602','0614-renew','旗标立即续费'];
                    } else {
                        deaconObj = ['TD20170622100602','0614-update','旗标-立即升级'];
                    }
                    ModalAD(this.props.itemPid,1,deaconObj);
                }
            }
        }
        if(this.props.type == "item") {

        } else {
            if(!isEmpty(window.userInfo)) {
                if(window.userInfo.vipFlag == '1') {
                    //自定义导航保存高级版
                    beacon('TD20170614170642','1106navsetsavevip',window.userInfo.userNick);
                } else {
                    //自定义导航保存初级版
                    beacon('TD20170614170642','1106navstesavef',window.userInfo.userNick);
                }
            }
        }
    }
    /**
     * [diffB 这不是我写的。。。]
     * @param  {[type]} a [description]
     * @param  {[type]} b [description]
     * @return {[type]}   [description]
     */
    diffB(a, b) {
        var flag = false;
        for (var j = 0 ; j < b.length; j++){
            flag = false;
            for (var i = 0; i < a.length; i++){
                if (a[i] == b[j].key){
                    flag = true;
                    break;
                }
            }
            if (flag == false){
                return j;
            }
        }
    }
    /**
     * [diffA 这也不是我写的]
     * @param  {[type]} a [description]
     * @param  {[type]} b [description]
     * @return {[type]}   [description]
     */
    diffA(a, b) {
        var flag = false;
        for (var i = 0; i < a.length; i++){
            flag = false;
            for (var j = 0 ; j < b.length; j++){
                if (a[i] == b[j].key){
                    flag = true;
                    break;
                }
            }
            if (flag == false){
                return i;
            }
        }
    }
    /**
     * [复选框点击时，触发该事件，勾选/取消 都会触发， 并且会传入 key 数组，已经勾选的元素的key 值]
     * @param  {[type]} key [description]
     * @param  {[type]} b   [description]
     * @param  {[type]} c   [description]
     * @return {[type]}     [description]
     */
    onSelect = (key, b, c) => {
       let len = key.length;
       // 最多选7个
       if(len < 8) {
            this.setState({
                selectValue:key,
                selectNum:len
            });
            let pos;
            //如果 a 比 b 长，表示它勾选的，需要追加上去
            if (key.length > selectFunctionValue.length){
                //添加上没有的
                // 比较两个数组，找出那个a 中有 b 中没有的元素
                pos = this.diffA(key,selectFunctionValue);
                // 根据该元素的值，去获取b中相关元素的值，并追加到b 上
                let lastElementClassName = key[pos];
                let addElement = document.getElementsByClassName(lastElementClassName);
                let text = addElement[0].innerText;
                let imgurl = '';
                if(addElement[0].attributes.data == undefined) {
                    imgurl = addElement[0].lastChild.lastChild.src;
                } else {
                    imgurl = addElement[0].attributes.data.value;
                }
                selectFunctionValue.push({
                    'key':lastElementClassName,
                    'text':text,
                    'imgurl':imgurl
                });
            } else if (key.length < selectFunctionValue.length){
                //删除没有的  如果 b 比a 长，表示去掉勾选，找出b中有，a 没有的那个元素删除
                pos = this.diffB(key,selectFunctionValue);
                selectFunctionValue.splice(pos,1);
            }
        } else {
            key.pop();
            MsgToast('error','最多选7项',500);
        }
    }
    watermarkOver() {
        let watermark = document.querySelector('.waterMarkTwoDiv');
        watermark.setAttribute("style","background-image:url(//q.aiyongbao.com/item/web/images/syyd3.png);");
    }
    watermarkOut() {
        let watermark = document.querySelector('.waterMarkTwoDiv');
        watermark.setAttribute("style","background-image:url(//q.aiyongbao.com/item/web/images/syyd4.png);");
    }
    dragulaDecorator(componentBackingInstance) {
        if (componentBackingInstance) {
            let options = {
                isContainer: function (el) {
                    // return el.classList.contains('dragula-container');
                    return false; // only elements in drake.containers will be taken into account
                },
                moves: function (el, source, handle, sibling) {
                    //return handle.classList.contains('handle');
                    return true; // elements are always draggable by default
                },
                accepts: function (el, target, source, sibling) {
                    return true; // elements can be dropped in any of the `containers` by default
                },
                invalid: function (el, handle) {
                    return false; // don't prevent any drags from initiating by default
                },
                direction: 'horizontal',             // Y axis is considered when determining where an element would be dropped
                copy: false,                       // elements are moved by default, not copied
                copySortSource: true,             // elements in copy-source containers can be reordered
                revertOnSpill: false,              // spilling will put the element back where it was dragged from, if this is true
                removeOnSpill: false,              // spilling will `.remove` the element, if this is true
                mirrorContainer: document.body,    // set the element that gets mirror elements appended
                ignoreInputTextSelection: true     // allows users to select input text, see details below
            };
            reactDragula([componentBackingInstance], options);
        }
    }
    /**
     * [renderContent 渲染内容]
     * @author Jiang
     * @return {[type]} [description]
     */
    renderContent() {
        if(this.props.type == "item") {
            return (
                <div className="selectFunction">
                    <h2>选择导航功能：</h2>
                    <div className="selectFunctionList">
                    <Menu className="customize-limit" onSelect={this.onSelect} selectedKeys={this.state.selectValue}>
                        <Menu.Group label="宝贝管理">
                            <Menu.CheckboxItem key="releaseBaby" className="releaseBaby" data='//q.aiyongbao.com/item/web/images/releaseBaby.png'>发布宝贝</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="copyBaby" className="copyBaby" data='///q.aiyongbao.com/item/web/images/copyBaby.png'>复制宝贝</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="batchModification" className="batchModification" data='///q.aiyongbao.com/item/web/images/batchModification.png'>批量修改</Menu.CheckboxItem>
                        </Menu.Group>
                        <Menu.Group label="引流优化">
                            <Menu.CheckboxItem key="autoJust" className="autoJust" data='//q.aiyongbao.com/item/web/images/autoJust.png'>自动上下架</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="autoWindow" className="autoWindow" data='//q.aiyongbao.com/item/web/images/autoWindow.png'>自动橱窗</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="titleOptimization" className="titleOptimization" data='//q.aiyongbao.com/item/web/images/titleOptimization.png'>标题优化</Menu.CheckboxItem>
                        </Menu.Group>
                        <Menu.Group label="宝贝装修">
                            <Menu.CheckboxItem key="mobileDesc" className="mobileDesc" data='//q.aiyongbao.com/item/web/images/mobileDesc.png'>手机详情</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="activePageDecoration" className="activePageDecoration"  data='//q.aiyongbao.com/item/web/images/activePageDecoration.png'>活动页装修</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="associatedSales" className="associatedSales" data='//q.aiyongbao.com/item/web/images/associatedSales.png'>关联销售</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="promotionWatermark" className="promotionWatermark" data='//q.aiyongbao.com/item/web/images/promotionWatermark.png'>促销水印</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="masterVideo" className="masterVideo" data='//q.aiyongbao.com/item/web/images/masterVideo.png'>主图视频</Menu.CheckboxItem>
                        </Menu.Group>
                        <Menu.Group label="店铺诊断">
                            <Menu.CheckboxItem key="badWordTesting" className="badWordTesting" data='//q.aiyongbao.com/item/web/images/badWordTesting.png'>违规词检测</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="babyTesting" className="babyTesting" data='//q.aiyongbao.com/item/web/images/babyTesting.png'>宝贝体检</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="shopTesting" className="shopTesting" data='//q.aiyongbao.com/item/web/images/shopTesting.png'>店铺体检</Menu.CheckboxItem>
                        </Menu.Group>
                    </Menu>
                    </div>
                </div>
            );
        } else {
            return (
                <div className="selectFunction">
                    <h2>选择导航功能：</h2>
                    <div className="selectFunctionList">
                    <Menu className="customize-limit" onSelect={this.onSelect} selectedKeys={this.state.selectValue}>
                        <Menu.Group label="订单管理">
                            <Menu.CheckboxItem key="logisticsManagement" className="logisticsManagement" data='//q.aiyongbao.com/trade/web/img/logisticsManagement.png'>物流管理</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="refundManagement" className="refundManagement" data='///q.aiyongbao.com/trade/web/img/refundManagement.png'>退款管理</Menu.CheckboxItem>
                        </Menu.Group>
                        <Menu.Group label="打单发货">
                            <Menu.CheckboxItem key="printSendnew" className="printSendnew" data='//q.aiyongbao.com/trade/web/img/printSendnew.png'>批量打印</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="customPrint" className="customPrint" data='//q.aiyongbao.com/trade/web/img/customPrint.png'>自由打印</Menu.CheckboxItem>
                        </Menu.Group>
                        <Menu.Group label="评价管理">
                            <Menu.CheckboxItem key="refuseNegativeComment" className="refuseNegativeComment" data='//q.aiyongbao.com/trade/web/img/refuseNegativeComment.png'>差评师拦截</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="autoRate" className="autoRate"  data='//q.aiyongbao.com/trade/web/img/autoRate.png'>自动评价</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="batchEvaluation" className="batchEvaluation" data='//q.aiyongbao.com/trade/web/img/batchEvaluation.png'>批量评价</Menu.CheckboxItem>
                            <Menu.CheckboxItem key="evaluate" className="evaluate" data='//q.aiyongbao.com/trade/web/img/evaluate.png'>评价管理</Menu.CheckboxItem>
                        </Menu.Group>
                        <Menu.Group className="customize-limit" label="短信关怀">
                            <Menu.CheckboxItem key="smsCare" className="smsCare" data='//q.aiyongbao.com/trade/web/img/smsCare.png'>短信关怀</Menu.CheckboxItem>
                        </Menu.Group>
                    </Menu>
                    </div>
                </div>
            );
        }
    }
    render() {
        const { defaultFlag } = this.state;
        let { DIYVisible,onClose } = this.props;
        let itemContent = [],icon = '',text = '';
        if(this.props.type == "item") {
            text = '点击导航上的功能，拖拽来更改显示顺序。（宝贝列表、设置、全部功能不可以拖动位置）';
            icon = (
                <div>
                    <li className="navigation-logo-zone">
                        <img style={{width: '36px', verticalAlign: 'middle'}} src="//q.aiyongbao.com/trade/web/img/wn.png"/>
                        <span style={{'marginLeft':'3px'}}>爱用商品</span>
                    </li>
                    <li className='next-navigation-item next-navigation-item-align-center not-move' key="itemManagement">
                        <div className='next-navigation-item-content'>
                            <a className='next-navigation-item-content-inner'>
                                <span>宝贝列表</span>
                            </a>
                        </div>
                        <div>
                            <img src="//q.aiyongbao.com/item/web/images/itemManagement.png"></img>
                        </div>
                    </li>
                </div>
            );
        } else {
            text = '点击导航上的功能，拖拽来更改显示顺序。（订单列表、设置、全部功能不可以拖动位置）';
            icon = (
                <div>
                    <li className="navigation-logo-zone">
                        <img style={{width: '36px', verticalAlign: 'middle'}} src="//q.aiyongbao.com/trade/web/img/wn.png"/>
                        <span style={{'marginLeft':'3px'}}>爱用交易</span>
                    </li>
                    <li className='next-navigation-item next-navigation-item-align-center not-move' key="tradeManagement">
                        <div className='next-navigation-item-content'>
                            <a className='next-navigation-item-content-inner'>
                                <span>订单列表</span>
                            </a>
                        </div>
                        <div>
                            <img src="//q.aiyongbao.com/trade/web/img/tradeManagement.png"></img>
                        </div>
                    </li>
                </div>
            );
        }
        //动态改变导航的个数
        if(selectFunctionValue.length > 0) {
            for(let i = 0;i < selectFunctionValue.length;i++) {
                if(selectFunctionValue[i].key == 'promotionWatermark') {
                    itemContent.push (
                        <li className="next-navigation-item next-navigation-item-align-center navigationDragList" style={{height:'65px'}} id={selectFunctionValue[i].key} key={selectFunctionValue[i].key}>
                            <div className="waterMarkTwoDiv" onMouseOver={this.watermarkOver.bind(this)} onMouseOut={this.watermarkOut.bind(this)}>

                            </div>
                        </li>
                    );
                } else {
                    itemContent.push (
                        <li className='next-navigation-item next-navigation-item-align-center navigationDragList' id={selectFunctionValue[i].key} key={selectFunctionValue[i].key}>
                            <div className='next-navigation-item-content'>
                                <a className='next-navigation-item-content-inner'>
                                    <span>{selectFunctionValue[i].text}</span>
                                </a>
                            </div>
                            <div>
                                <img src={selectFunctionValue[i].imgurl}></img>
                            </div>
                        </li>
                    );
                }
            }
        }
        return (
            <Dialog
                style={{width:'1110px',height:'480px'}}
                visible={DIYVisible}
                className="DIYNavigationDialog"
                onClose={onClose}
                footer={this.renderDialogFooter()}
                title="自定义导航"
                >
                <Navigation
                    className = "layout-header"
                    type="filling"
                    leaf='none'
                    activeDirection="bottom"
                    >
                    {icon}
                    <li>
                        {
                            defaultFlag && <div><ul ref={this.dragulaDecorator}>{[...itemContent]}</ul></div> || <ul ref={this.dragulaDecorator}> {[...itemContent]}</ul>
                        }
                    </li>
                    <li className='next-navigation-item next-navigation-item-align-center not-move' key="setting">
                        <div className='next-navigation-item-content'>
                            <a className='next-navigation-item-content-inner'>
                                <span>设置</span>
                            </a>
                        </div>
                        <div>
                            <img src="//q.aiyongbao.com/trade/web/img/setting.png"></img>
                        </div>
                    </li>
                    <li className='next-navigation-item next-navigation-item-align-center not-move' key="allList">
                        <div className='next-navigation-item-content'>
                            <a className='next-navigation-item-content-inner'>
                                <span>全部功能</span>
                            </a>
                        </div>
                        <div>
                            <img src="//q.aiyongbao.com/trade/web/img/allList.png"></img>
                        </div>
                    </li>
                </Navigation>
                <div className = "promptWarn">
                    <span className="wanIcon">!</span>
                    <span className="promptWarnText">{text}</span>
                </div>
                {this.renderContent()}
            </Dialog>
        );
    }
}
export default diyNavigation;