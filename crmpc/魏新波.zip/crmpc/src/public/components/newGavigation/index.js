/**
 * 新版导航
 * @author  Jiang
 */
import { isEmpty } from 'utils/index';
import ModalAD from 'public/components/modalAD/index'
import React from 'react';
import moment from 'moment';
import { Navigation,Menu,Balloon,Button } from 'qnui';
import ErrorDialog from 'publicComponents/errorDialog/index';
import DiyNavigation from './diyNavigation/index';
const { Item } = Navigation;
import { api,beacon,ww } from 'utils/index';
//来控制全部功能是否显示
var allListVisible = false;
//赠送的短信条数
var smsNum = 0;
//导航列表
var navigationList = new Array();
import './index.scss';
//商品页面链接
const itemLinks = {
    'itemManagement': 'index.html',
    'itemsedit': 'itemsedit.html?qntag=1',
    'itemscheck': 'itemscheck.html?qntag=1',
    'shopcheck':'shopcheck.html?qntag=1',
    'autoJust': "autolist.html",
    'titleOptimize':  "titleOptimize.html?qntag=1",
    'activePageDecoration' :  "activePageDecorationIndex.html?qntag=1",
    'index': 'index.html?qntag=1',
    'batchModification': 'plmodify.html?qntag=1',
    'babyTesting': 'baby_medical.html?qntag=1',
    'stores_medical':'stores_medical.html?qntag=1',
    'mobileDesc': 'bbmobilenew.html',
    'titleOptimization':  "title_optimize_index.html?qntag=1",
    'autoWindow' :  "zdcc.html",
    'copyBaby' :   "copybaby.html",
    'associatedSales' :  "relatsales.html?qntag=1",
    'promotionWatermark' :  "watermark.html?qntag=1",
    'masterVideo' :  "videoindex.html?qntag=1",
    'badWordTesting' :  "badWordDetection.html?qntag=1",
    'ordermanagement' :  "ordermanagement.html?qntag=1",
    'discountsPage' :  "discountsPage.html?qntag=1",
    'shopTesting' : "stores_medical.html?qntag=1",
    'seting' : "setting.html",
    'releaseBaby' : "releaseBaby.html"
};
//交易页面链接
const tradeLinks = {
    'redux': 'batchPrint.html',
    'tradeManagement': 'tradeManagement.html#/tradeManagement',
    'logisticsManagement': 'tradeManagement.html#/logisticsManagement',
    'refundManagement': 'tradeManagement.html#/refundManagement',
    'refuseNegativeComment':'interceptor.html#/refuseNegativeComment',
    'autoRate': 'autoeva.html',
    'tradeManagement': 'index.html#/tradeManagement',
    'reminderPay':  'setting.html#/phrase',
    'logisticsManagement' :  'logistics.html?qntag=1',
    'refundManagement' :  'refundmgt.html?qntag=1',
    'printSendnew' :   'printSendnew.html?qntag=1',
    'customPrint' :  'customPrint.html?qntag=1',
    'fastMo' :  'fastMo.html?qntag=1',
    'sendMo' :  'sendMo.html?qntag=1',
    'titleSet' :  'setting.html#/item',
    'printSet' :  'printSet.html?qntag=1',
    'printLog' :  'printLog.html?qntag=1',
    'evaluate' :  'evaluate.html?qntag=1',
    'batchEvaluation' : 'batchEvaluation.html#/batchComment',
    'smsCare' :  'smscare.html#/smsCare',
    'smspay'  :  'smscare.html#/noticePage/:cftx',
    'smsgood'  :  'smscare.html#/noticePage/:pjgx',
    'smssend'  :  'smscare.html#/noticePage/:fhtx',
    'smsbad'  :  'smscare.html#/noticePage/:cpwh',
    'setting' : 'setting.html',
    'cuxiaopc' :  'cuxiaopc.html?qntag=1',
    'bannerPage':'//q.aiyongbao.com/gx/html/gx_banner_page.html?qntag=1',
    'fuwu':'//qianniu.fuwu.taobao.com/ser/detail.html?service_code=FW_GOODS-1834215&tracelog=sp'
};
//商品导航数据
const itemDefaultNavigation = [
    {
        'key':'mobileDesc',
        'text':'手机详情',
        'order':'0',
        'imgurl':'//q.aiyongbao.com/item/web/images/mobileDesc.png'
    },
    {
        'key':'autoJust',
        'text':'自动上下架',
        'order':'1',
        'imgurl':'//q.aiyongbao.com/item/web/images/autoJust.png'
    },
    {
        'key':'autoWindow',
        'text':'自动橱窗',
        'order':'2',
        'imgurl':'//q.aiyongbao.com/item/web/images/autoWindow.png'
    },
    {
        'key':'titleOptimization',
        'text':'标题优化',
        'order':'3',
        'imgurl':'//q.aiyongbao.com/item/web/images/titleOptimization.png'
    },
    {
        'key':'promotionWatermark',
        'text':'促销水印',
        'order':'4',
        'imgurl':'//q.aiyongbao.com/item/web/images/syyd4.png'
    },
    {
        'key':'badWordTesting',
        'text':'违规词检测',
        'order':'5',
        'imgurl':'//q.aiyongbao.com/item/web/images/badWordTesting.png'
    },
    {
        'key':'batchModification',
        'text':'批量修改',
        'order':'6',
        'imgurl':'//q.aiyongbao.com/item/web/images/batchModification.png'
    }
];
//交易导航数据
const tradeDefaultNavigation = [
    {
        'key':'logisticsManagement',
        'text':'物流管理',
        'order':'0',
        'imgurl':'//q.aiyongbao.com/trade/web/img/logisticsManagement.png'
    },
    {
        'key':'printSendnew',
        'text':'批量打印',
        'order':'1',
        'imgurl':'//q.aiyongbao.com/trade/web/img/printSendnew.png'
    },
    {
        'key':'customPrint',
        'text':'自由打印',
        'order':'2',
        'imgurl':'//q.aiyongbao.com/trade/web/img/customPrint.png'
    },
    {
        'key':'refuseNegativeComment',
        'text':'差评师拦截',
        'order':'3',
        'imgurl':'//q.aiyongbao.com/trade/web/img/refuseNegativeComment.png'
    },
    {
        'key':'autoRate',
        'text':'自动评价',
        'order':'4',
        'imgurl':'//q.aiyongbao.com/trade/web/img/autoRate.png'
    },
    {
        'key':'batchEvaluation',
        'text':'批量评价',
        'order':'5',
        'imgurl':'//q.aiyongbao.com/trade/web/img/batchEvaluation.png'
    },
    {
        'key':'evaluate',
        'text':'评价管理',
        'order':'6',
        'imgurl':'//q.aiyongbao.com/trade/web/img/evaluate.png'
    }
];
class newGavigation extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            vipFlag:'免费版',
            vipTime:(<font>限时特惠<font className = "nav-warring">6</font>折</font>),
            vipBut:'立即升级',
            itemPid:888,
            tradePid:783,
            //控制赠送短信小浮窗显示
            tipVisible:false,
            //控制DIY导航弹框
            DIYVisible:false,
            //导航内容
            itemContent:[],
            //差评挽回
            smsbad:'',
            //好评感谢
            smsgood:'',
            //发货提醒
            smssend:'',
            //催付提醒
            smspay:'',
        }
    }
    watermarkOver() {
        if(window.page != "promotionWatermark") {
            let watermark = document.querySelector('.waterMarkDiv');
            watermark.setAttribute("style","background-image:url(//q.aiyongbao.com/item/web/images/syyd3.png);");
        }
    }
    watermarkOut() {
        if(window.page != "promotionWatermark") {
            let watermark = document.querySelector('.waterMarkDiv');
            watermark.setAttribute("style","background-image:url(//q.aiyongbao.com/item/web/images/syyd4.png);");
        }
    }
    componentWillMount() {
        if(!isEmpty(window.userInfo)) {
            if(window.userInfo.vipFlag == 1 && window.userInfo.vipTime != 'off') {
                let days = moment(window.userInfo.vipTime).diff(moment(),'days');
                if(this.props.type == "item") {
                    this.setState({
                        vipFlag: "高级版",
                        vipTime: (<font>剩<font className = "nav-warring">{days}</font>天到期</font>),
                        vipBut:"立即续费",
                        itemPid:889
                    });
                } else {
                    this.setState({
                        vipFlag: "高级版",
                        vipTime: (<font>剩<font className = "nav-warring">{days}</font>天到期</font>),
                        vipBut:"立即续费",
                        tradePid:784
                    });
                }
            }
        }
        if(this.props.type == "trade") {
            // youxiaowei 2017-10-23
            //购买成功tip
            //获取localStorage tipVisible 判断tip 是否显示
            let tipVisible;
            try {
                tipVisible = window.localStorage.getItem(window.userInfo.userNick + 'tipVisible');
            } catch(e) {
                console.error(e);
            }
            if(!isEmpty(tipVisible) ){
                smsNum = tipVisible;
                window.localStorage.removeItem(window.userInfo.userNick + 'tipVisible');
                this.setState({
                    tipVisible:true
                });
            }
            // 获取短信通知开关状态
            this.getSmsSwitch();
        }
        //点击空白处，关闭全部功能列表
        document.addEventListener('click',this.closeDiv.bind(this));
        //动态改变导航的个数
        let items = [],navigationList = '';
        //如果为空，可能是清缓存了，或者换电脑了，所以要从 数据库里面取上次的记录
        if(this.props.type == "item") {
            navigationList = window.localStorage.getItem(window.userInfo.userNick + 'itemNavigationList');
        } else {
            navigationList = window.localStorage.getItem(window.userInfo.userNick + 'tradeNavigationList');
        }
        if(!isEmpty(navigationList)) {
            navigationList = JSON.parse(decodeURIComponent(navigationList));
            if(navigationList.length > 0) {
                for(let i = 0;i < navigationList.length;i++) {
                    if(navigationList[i].key == "promotionWatermark") {
                        items.push (
                            <li className="next-navigation-item next-navigation-item-align-center" style={{height:'65px'}} onMouseEnter={this.closeAllFun.bind(this)}>
                                <div className="waterMarkDiv" onClick={this.jumpLink.bind(this,'promotionWatermark')} onMouseOver={this.watermarkOver.bind(this)} onMouseOut={this.watermarkOut.bind(this)}>

                                </div>
                            </li>
                        );
                    } else {
                        items.push (
                            <Item className={navigationList[i].key} key={navigationList[i].key} text={navigationList[i].text} onClick={this.jumpLink.bind(this)} onMouseEnter={this.closeAllFun.bind(this)}>
                                <img src={navigationList[i].imgurl}></img>
                            </Item>
                        );
                    }
                }
            }
            this.setState({
                itemContent:items
            });
       } else {
            let method = '',list = '';
            if(this.props.type == "item") {
                method = '/itemnavigation/gettopposition';
            } else {
                method = '/set/gettopposition';
            }
            api({
                method:method,
                mode:'json',
                callback:(e)=>{
                    let data = '';
                    if(this.props.type == "item") {
                        if(e.result[0] != undefined) {
                            data = e.result[0].content;
                        }
                    } else {
                        if(e.result.content != undefined) {
                            data = e.result.content;
                        }
                    }
                    if(data) {
                        let list = decodeURIComponent(data);
                        navigationList = JSON.parse(list);
                    } else {
                        if(this.props.type == "item") {
                            navigationList = [...itemDefaultNavigation];
                        } else {
                            navigationList = [...tradeDefaultNavigation];
                        }
                    }
                    if(navigationList.length > 0) {
                        for(let i = 0;i < navigationList.length;i++) {
                            if(navigationList[i].key == "promotionWatermark") {
                                items.push (
                                    <li className="next-navigation-item next-navigation-item-align-center" style={{height:'65px'}} onMouseEnter={this.closeAllFun.bind(this)}>
                                        <div className="waterMarkDiv" onClick={this.jumpLink.bind(this,'promotionWatermark')} onMouseOver={this.watermarkOver.bind(this)} onMouseOut={this.watermarkOut.bind(this)}>
                                            
                                        </div>
                                    </li>
                                );
                            } else {
                                items.push (
                                    <Item className={navigationList[i].key} key={navigationList[i].key} text={navigationList[i].text} onClick={this.jumpLink.bind(this)} onMouseEnter={this.closeAllFun.bind(this)}>
                                        <img src={navigationList[i].imgurl}></img>
                                    </Item>
                                );
                            }
                        }
                    }
                    this.setState({
                        itemContent:items
                    });
                    window.localStorage.setItem(window.userInfo.userNick + 'itemNavigationList',encodeURIComponent(JSON.stringify(navigationList)));
                },
                err_callback:(msg)=>{
                    console.error(msg);
                    ErrorDialog('温馨提示','操作失败！',msg);
                }
            })
        }
    }
    //点击短信关怀，或者我知道了，关闭tip
    onClick() {
        this.setState({
            tipVisible:false
        });
    }
    /**
     * [onClose 关闭子组件的弹框]
     * @author  Jiang
     * @return {[type]} [description]
     */
    onClose() {
        this.setState({
            DIYVisible:false
        });
    }
    //获取开关状态 点全部功能的时候，
    getSmsSwitch() {
        api({
            method:'/iytrade2/sms',
            callback:(e)=>{
                this.setState({
                    smsbad:e.smsbad,
                    smsgood:e.smsgood,
                    smssend:e.smssend,
                    smspay:e.smspay
                });
            },
            err_callback:(msg)=>{
                ErrorDialog('温馨提示','操作失败！',msg);
            }
        });
    }
    /**
     * [buyVip 旗标升级点击]
     * @author  Jiang
     * @return {[type]} [description]
     */
    buyVip() {
        if(this.props.type == "item") {
            beacon('TD20170622100602','1205flagclick',window.userInfo.userNick);
            let deaconObj = '';
            if(this.state.itemPid == 889) {
                deaconObj = ['TD20170622100602','0614-renew','旗标立即续费'];
            } else {
                deaconObj = ['TD20170622100602','0614-update','旗标-立即升级'];
            }
            ModalAD(this.state.itemPid,1,deaconObj);
        } else {
            ModalAD(this.state.tradePid,1);
        }
    }
    /**
     * 打开设置页面
     * @author  Jiang
     * @return {[type]} [description]
     */
    onClickSetting=()=>{
        localStorage.setItem('settingPage', ['sendSetting']);
        localStorage.setItem('settingOpen', '1');
        window.location.href=  'setting.html';
    }
    /**
     * [publicbaby 发布宝贝]
     * @author  Jiang
     * @return {[type]} [description]
     */
    publicbaby() {
        beacon('TD20170622100602','1205index-newbaby',window.userInfo.userNick);
        QN.application.invoke({
            "cmd": "translateUrl",
            "param": {
                'url': '//upload.taobao.com/auction/sell.jhtml?spm=a1z0e.1.0.0.rLGeyT&mytmenu=wym&utkn=g,mrzgk43tmezhu1431568417808&scm=1028.1.1.101'
            },
            "success": function(e) {
                if (typeof e === 'string') {
                    e = JSON.parse(e);
                }
                QN.application.invoke({
                    "cmd": "browserUrlEmbedded",
                    "param": {
                        "url": e.url,
                        "id": '10086',
                        "title": '发布宝贝',
                        "width": '1200',
                        "height": '600'
                    }
                });
            }
        });
    }
    /**
     * [isShowAllList 是否展现所有功能下的列表导航]
     * @author  Jiang
     * @param  {[type]}  type [description]
     * @return {Boolean}      [description]
     */
    isShowAllList(type) {
        if(type == 'open') {
            let allList = document.getElementsByClassName('allList');
            allList[0].style.display = 'inline-block';
        } else {
            let allList = document.getElementsByClassName('allList');
            allList[0].style.display = 'none';
        }
    }
    allListOnClick() {
        allListVisible = !allListVisible;
        if(allListVisible) {
            this.isShowAllList('open');
        } else {
            this.isShowAllList('close');
        }
    }
    onMouseEnter() {
        this.isShowAllList('open');
    }
    onMouseLeave() {
        this.isShowAllList('close');
    }
    closeDiv() {
        this.isShowAllList('close');
    }
    closeAllFun() {
        this.isShowAllList('close');   
    }
    /**
     * [onClose 关闭弹框]
     * @author  Jiang
     * @return {[type]} [description]
     */
    onClose() {
        this.setState({
            DIYVisible:false
        });
    }
    /**
     * [setHeader 导航栏那个浮上去显示的设置导航]
     * @author  Jiang
     */
    setHeader() {
        this.setState({
            DIYVisible:true
        });
        if(this.props.type == "item") {
            beacon('TD20170622100602','1210index-setsort',window.userInfo.userNick);
        } else {
            if(!isEmpty(window.userInfo)){
                if(window.userInfo.vipFlag == '1'){
                    //导航设置点击高级版
                    beacon('TD20170614170642','1106navsetclickvip',window.userInfo.userNick);
                }else{
                    //导航设置点击初级版
                    beacon('TD20170614170642','1106navsetclickf',window.userInfo.userNick);
                }
            }
        }
    }
    /**
     * [jumpLink 跳转页面]
     * @param  {[type]} value [description]
     * @return {[type]}       [description]
     */
    jumpLink(value) {
        if(value == "itemSeting") {
            localStorage.setItem('settingPage', ['sendSetting']);
            localStorage.setItem('settingOpen', '1');
            if(this.props.type == "trade") {
                value = "setting";   
            } else {
                beacon('TD20170622100602', '1210index-set', window.userInfo.userNick);
            }
        }
        if(value == "releaseBaby") {
            if(document.getElementsByClassName(window.page)[0] != null) {
                let firstChild = document.getElementsByClassName(window.page)[0].firstChild;
                firstChild.style.backgroundColor = "#1170bc";
            }
            if(document.getElementsByClassName("releaseBaby")[0] != null) {
                let releaseBaby = document.getElementsByClassName("releaseBaby")[0].firstChild;
                releaseBaby.style.backgroundColor = "#3089dc";
                setTimeout(function() {
                    releaseBaby.style.backgroundColor = "";
                },500);
            }
            this.publicbaby();
            return;
        }
        if(this.props.type == "item") {
            switch(itemLinks[value]) {
                case 'mobileDesc':
                    beacon('TD20170622100602', '1205index-mdetails', window.userInfo.userNick);
                break;
                case 'autoJust':
                    beacon('TD20170622100602', '1205index-autoadjust', window.userInfo.userNick);
                break;
                case 'autoWindow':
                    beacon('TD20170622100602', '1205index-autowindow', window.userInfo.userNick);
                break;
                case 'titleOptimization':
                    beacon('TD20170622100602', '1205index-titleseo', window.userInfo.userNick);
                break;
                case 'promotionWatermark':
                    beacon('TD20170622100602', '1205index-watermark', window.userInfo.userNick);
                break;
                case 'badWordTesting':
                    beacon('TD20170622100602', '1205index-wordexam', window.userInfo.userNick);
                break;
                case 'batchModification':
                    beacon('TD20170622100602', '1205index-update', window.userInfo.userNick);
                break;
                case 'activePageDecoration':
                    beacon('TD20170622100602', '1205index-salespage', window.userInfo.userNick);
                break;
                case 'babyTesting':
                    beacon('TD20170622100602', '1205index-babyexam', window.userInfo.userNick);
                break;
                case 'shopTesting':
                    beacon('TD20170622100602', '1205index-storeexam', window.userInfo.userNick);
                break;
                case 'associatedSales':
                    beacon('TD20170622100602', '1205index-relatedsale', window.userInfo.userNick);
                break;
                case 'copyBaby':
                    beacon('TD20170622100602', '1205index-copybaby', window.userInfo.userNick);
                break;
                case 'masterVideo':
                    beacon('TD20170622100602', '1205index-graphvideo', window.userInfo.userNick);
                break;
            }
            setTimeout(function(){
                window.location.href = itemLinks[value];
            },200);
        } else {
            window.location.href = tradeLinks[value];
        }
    }
    callback(value) {
        let items = [];
        if(value.length > 0) {
            for(let i = 0;i < value.length;i++) {
                if(value[i].key == "promotionWatermark") {
                    items.push (
                        <li className="next-navigation-item next-navigation-item-align-center" style={{height:'65px'}} onMouseEnter={this.closeAllFun.bind(this)}>
                            <div className="waterMarkDiv" onClick={this.jumpLink.bind(this,"promotionWatermark")} onMouseOver={this.watermarkOver.bind(this)} onMouseOut={this.watermarkOut.bind(this)}>
                            </div>
                        </li>
                    );
                } else {
                    items.push (
                        <Item className={value[i].key} key={value[i].key} text={value[i].text} onClick={this.jumpLink.bind(this)} onMouseEnter={this.closeAllFun.bind(this)}>
                            <img src={value[i].imgurl}></img>
                        </Item>
                    );
                }
            }
        }
        this.setState({
            itemContent:items
        });
        setTimeout(function() {
            if(window.page == "promotionWatermark") {
                let watermark = document.querySelector('.waterMarkDiv');
                if(watermark != null) {
                    watermark.setAttribute("style","background-image:url(//q.aiyongbao.com/item/web/images/syyd3.png);");
                }
            }
        },500);
    }
    /**
     * [renderContent 渲染页面]
     * @author  Jiang
     * @return {[type]} [description]
     */
    renderContent() {
        if(this.props.type == "item") {
            return (
                <div className="allListContainer">
                    <div className='allList' id='allList' onMouseLeave={this.onMouseLeave.bind(this)} style={{zIndex: 999}}>
                        <Menu className="customize-limit" header={<h3>宝贝管理</h3>}>
                            <Menu.Item key="1"><a href={itemLinks.itemManagement}><span>宝贝列表</span></a></Menu.Item>
                            <Menu.Item key="2"><a onClick={this.publicbaby.bind(this)}><span>发布宝贝</span></a></Menu.Item>
                            <Menu.Item key="3"><a href={itemLinks.copyBaby}><span>复制宝贝</span></a></Menu.Item>
                            <Menu.Item key="4"><a href={itemLinks.batchModification}><span>批量修改</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>引流优化</h3>}>
                            <Menu.Item key="1"><a href={itemLinks.autoJust} className='outstanding'><span>自动上下架</span></a></Menu.Item>
                            <Menu.Item key="2"><a href={itemLinks.autoWindow}><span>自动橱窗</span></a></Menu.Item>
                            <Menu.Item key="3"><a href={itemLinks.titleOptimization}><span>标题优化</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>宝贝装修</h3>}>
                            <Menu.Item key="1"><a href={itemLinks.mobileDesc} className='outstanding'><span>手机详情</span></a></Menu.Item>
                            <Menu.Item key="2"><a href={itemLinks.activePageDecoration}><span>活动页装修</span></a></Menu.Item>
                            <Menu.Item key="3"><a href={itemLinks.associatedSales}><span>关联销售</span></a></Menu.Item>
                            <Menu.Item key="4"><a href={itemLinks.promotionWatermark}><span>促销水印</span></a></Menu.Item>
                            <Menu.Item key="5"><a href={itemLinks.masterVideo}><span>主图视频</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>店铺检测</h3>}>
                            <Menu.Item key="5"><a href={itemLinks.badWordTesting} className='outstanding'><span>违规词检测</span></a></Menu.Item>
                            <Menu.Item key="6"><a href={itemLinks.babyTesting}><span>宝贝体检</span></a></Menu.Item>
                            <Menu.Item key="4"><a href={itemLinks.shopTesting}><span>店铺体检</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>轻松管店</h3>}>
                            <Menu.Item key="1"><a href="https://isv069.bbs.taobao.com/detail.html?postId=8281525" target="_blank"><span>订单列表</span></a></Menu.Item>
                            <Menu.Item key="2"><a href="https://isv069.bbs.taobao.com/detail.html?postId=8281525" target="_blank"><span>物流管理</span></a></Menu.Item>
                            <Menu.Item key="3"><a href="https://isv069.bbs.taobao.com/detail.html?postId=8281525" target="_blank"><span>退款管理</span></a></Menu.Item>
                            <Menu.Item key="4"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1816623" target="_blank"><span>店铺评价</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>提升效率</h3>}>
                            <Menu.Item key="1"><a href="https://isv069.bbs.taobao.com/detail.html?spm=a210m.7841133.0.0.702a642e0S44Js&postId=1818313" target="_blank" className='outstanding'><span>打单发货</span></a></Menu.Item>
                            <Menu.Item key="2"><a href="https://isv069.bbs.taobao.com/detail.html?spm=a210m.7841133.0.0.702a642e0S44Js&postId=1820262" target="_blank"><span>自定义打印</span></a></Menu.Item>
                            <Menu.Item key="3"><a href="https://isv069.bbs.taobao.com/detail.html?spm=a210m.7841133.0.0.702a642e0S44Js&postId=1821241" target="_blank" className='outstanding'><span>差评师拦截</span></a></Menu.Item>
                            <Menu.Item key="4"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1819812" target="_blank"><span>自动评价</span></a></Menu.Item>
                            <Menu.Item key="5"><a href="https://isv069.bbs.taobao.com/detail.html?spm=a210m.7841133.0.0.782488160tW9we&postId=1819807" target="_blank"><span>批量评价</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>客户关怀</h3>}>
                            <Menu.Item key="1"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821033" target="_blank"><span>群发短信</span></a></Menu.Item>
                            <Menu.Item key="2"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821033" target="_blank"><span>催付提醒</span></a></Menu.Item>
                            <Menu.Item key="3"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821033" target="_blank"><span>发货提醒</span></a></Menu.Item>
                            <Menu.Item key="4"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821033" target="_blank"><span>好评感谢</span></a></Menu.Item>
                            <Menu.Item key="5"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821033" target="_blank" className='outstanding'><span>差评挽回</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>促销转化</h3>}>
                            <Menu.Item key="2"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821287" target="_blank"><span>限时打折</span></a></Menu.Item>
                            <Menu.Item key="3"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821288" target="_blank"><span>满就送</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>数据分析</h3>}>
                            <Menu.Item key="1"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1818450" target="_blank"><span>流量分析</span></a></Menu.Item>
                            <Menu.Item key="2"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1818451" target="_blank"><span>销售分析</span></a></Menu.Item>
                            <Menu.Item key="3"><a href="https://isv069.bbs.taobao.com/detail.html?postId=8157170" target="_blank"><span>时段分析</span></a></Menu.Item>
                        </Menu>
                    </div>
                </div>
            );
        } else {
            return (
                <div className="allListContainer">
                    <div className='allList' id='allList' onMouseLeave={this.onMouseLeave.bind(this)} style={{zIndex: 999}}>
                        <Menu className="customize-limit" header={<h3>轻松管店</h3>}>
                            <Menu.Item key="1"><a href={tradeLinks.tradeManagement}><span>订单列表</span></a></Menu.Item>
                            <Menu.Item key="2"><a href={tradeLinks.logisticsManagement}><span>物流管理</span></a></Menu.Item>
                            <Menu.Item key="3"><a href={tradeLinks.refundManagement}><span>退款管理</span></a></Menu.Item>
                            <Menu.Item key="4"><a href={tradeLinks.evaluate}><span>店铺评价</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>提升效率</h3>}>
                            <Menu.Item key="1"><a href={tradeLinks.printSendnew} className='outstanding'><span>打单发货</span></a></Menu.Item>
                            <Menu.Item key="2"><a href={tradeLinks.customPrint}><span>自定义打印</span></a></Menu.Item>
                            <Menu.Item key="3"><a href={tradeLinks.refuseNegativeComment} className='outstanding'><span>差评师拦截</span></a></Menu.Item>
                            <Menu.Item key="4"><a href={tradeLinks.autoRate}><span>自动评价</span></a></Menu.Item>
                            <Menu.Item key="4"><a href={tradeLinks.batchEvaluation}><span>批量评价</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>客户关怀</h3>}>
                            <Menu.Item key="1"><a href={tradeLinks.smsCare}><span>群发短信</span></a></Menu.Item>
                            <Menu.Item key="2"><a href={this.state.smspay == 'on' ? tradeLinks.smspay:tradeLinks.smsCare}><span>催付提醒</span></a></Menu.Item>
                            <Menu.Item key="3"><a href={this.state.smssend == 'on' ? tradeLinks.smssend:tradeLinks.smsCare}><span>发货提醒</span></a></Menu.Item>
                            <Menu.Item key="4"><a href={this.state.smsgood == 'on' ? tradeLinks.smsgood:tradeLinks.smsCare}><span>好评感谢</span></a></Menu.Item>
                            <Menu.Item key="5"><a href={this.state.smsbad == 'on' ? tradeLinks.smsbad:tradeLinks.smsCare} className='outstanding'><span>差评挽回</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>商品管理</h3>}>
                            <Menu.Item key="5"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1816691" target="_blank"><span>商品列表</span></a></Menu.Item>
                            <Menu.Item key="6"><a href="https://isv069.bbs.taobao.com/detail.html?postId=8156576" target="_blank"><span>发布宝贝</span></a></Menu.Item>
                            <Menu.Item key="4"><a href="https://isv069.bbs.taobao.com/detail.html?postId=8156573" target="_blank"><span>复制宝贝</span></a></Menu.Item>
                            <Menu.Item key="4"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1816732" target="_blank"><span>批量修改</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>引爆流量</h3>}>
                            <Menu.Item key="2"><a href="https://isv069.bbs.taobao.com/detail.html?spm=a210m.7841133.0.0.1e702dd53NXnAr&postId=5676054" target="_blank"><span>自动上下架</span></a></Menu.Item>
                            <Menu.Item key="3"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1816784" target="_blank"><span>自动橱窗</span></a></Menu.Item>
                            <Menu.Item key="1"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821295" className='outstanding' target="_blank"><span>标题优化</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>店铺装修</h3>}>
                            <Menu.Item key="1"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821314" className='outstanding' target="_blank"><span>手机详情</span></a></Menu.Item>
                            <Menu.Item key="2"><a href="https://isv069.bbs.taobao.com/detail.html?postId=7513322" target="_blank"><span>活动页装修</span></a><span className='triangle-new'>new<div className='triangle-down'></div></span></Menu.Item>
                            <Menu.Item key="3"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1820861" target="_blank"><span>关联销售</span></a></Menu.Item>
                            <Menu.Item key="1"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821328" target="_blank"><span>促销水印</span></a></Menu.Item>
                            <Menu.Item key="4"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821263" target="_blank"><span>主图视频</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>店铺体检</h3>}>
                            <Menu.Item key="1"><a href="https://isv069.bbs.taobao.com/detail.html?postId=8157363" className='outstanding' target="_blank"><span>违规词检测</span></a></Menu.Item>
                            <Menu.Item key="2"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1816713" target="_blank"><span>宝贝体检</span></a></Menu.Item>
                            <Menu.Item key="3"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821069" target="_blank"><span>店铺体检</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>促销转化</h3>}>
                            <Menu.Item key="2"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821287" target="_blank"><span>限时打折</span></a></Menu.Item>
                            <Menu.Item key="3"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1821288" target="_blank"><span>满就送</span></a></Menu.Item>
                        </Menu>
                        <Menu className="customize-limit" header={<h3>数据分析</h3>}>
                            <Menu.Item key="1"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1818450" target="_blank"><span>流量分析</span></a></Menu.Item>
                            <Menu.Item key="2"><a href="https://isv069.bbs.taobao.com/detail.html?postId=1818451" target="_blank"><span>销售分析</span></a></Menu.Item>
                            <Menu.Item key="3"><a href="https://isv069.bbs.taobao.com/detail.html?postId=8157170" target="_blank"><span>时段分析</span></a></Menu.Item>
                        </Menu>
                    </div>
                </div>
            );
        }
    }
    render() {
        //Balloon 中 trigger所绑定的元素
        const tip = <div className='adTip' onClick={this.onClick.bind(this)}></div>;
        const content = (
            <div className='tipBalloon'>
                <p className='tipBalloonText'>赠送你的<span>{smsNum}</span>条短信已经到账，<br/>稍后可以在<a href="smscare.html" className='gotoSmsCare'>&nbsp;短信关怀&nbsp;</a>中查看。</p>
                <Button type="primary"  onClick={this.onClick.bind(this)} className='knowButton'>
                    我知道了
                </Button>
            </div>
        );
        let icon = '',liTip = (
            <li>
            </li>
        ),itemHead = '';
        if(this.props.type == "item") {
            icon = (
                <li className="navigation-logo-zone">
                    <img style={{width: '36px', verticalAlign: 'middle'}} src="//q.aiyongbao.com/trade/web/img/wn.png"/>
                    <span style={{'marginLeft':'3px'}}>爱用商品</span>
                </li>
            );
            itemHead = (
                <Item
                    className="itemManagement"
                    key="itemManagement"
                    text="宝贝列表"
                    onClick={this.jumpLink.bind(this)}
                   >
                   <img src="//q.aiyongbao.com/trade/web/img/tradeManagement.png"></img>
                </Item>
            );
        } else {
            icon = (
                <li className="navigation-logo-zone">
                    <img style={{width: '36px', verticalAlign: 'middle'}} src="//q.aiyongbao.com/trade/web/img/wn.png"/>
                    <span style={{'marginLeft':'3px'}}>爱用交易</span>
                </li>
            );
            liTip = (
                <li className='tip'>
                    {
                        this.state.tipVisible ? (<Balloon trigger={tip} triggerType="click" closable={false} align='br' visible={this.state.tipVisible}>{content}</Balloon>) : ''
                    }
                </li>
            );
            itemHead = (
                <Item
                   key="tradeManagement"
                   text="订单列表"
                   onClick={this.jumpLink.bind(this)}
                   >
                   <img src="//q.aiyongbao.com/trade/web/img/tradeManagement.png"></img>
                </Item>
            );
        }
        return (
            <div>
                <Navigation
                    className = "layout-header"
                    selectedKey = {window.page}
                    type="filling"
                    leaf='none'
                    activeDirection="bottom"
                    >
                    {icon}
                    {itemHead}
                    {[...this.state.itemContent]}
                    <Item
                        className="seting"
                        key="seting"
                        text="设置"
                        onClick={this.jumpLink.bind(this)}
                        onMouseEnter={this.closeAllFun.bind(this)}
                        >
                        <img src="//q.aiyongbao.com/trade/web/img/setting.png"></img>
                    </Item>
                    <li className='next-navigation-item next-navigation-item-align-center ' key="allList" onClick={this.allListOnClick.bind(this)} onMouseEnter={this.onMouseEnter.bind(this)} >
                        <div className='next-navigation-item-content'>
                            <a className='next-navigation-item-content-inner'>
                                <span>全部功能</span>
                            </a>
                        </div>
                        <div>
                            <img src="//q.aiyongbao.com/trade/web/img/allList.png"></img>
                        </div>
                    </li>
                    <li className='next-navigation-item next-navigation-item-align-center setHeader' key="setHeader" onClick={this.setHeader.bind(this)} onMouseEnter={this.closeAllFun.bind(this)}>
                        <div className='next-navigation-item-content'>
                            <a className=''>
                                <span></span>
                            </a>
                        </div>
                        <div>
                            <img src="//q.aiyongbao.com/trade/web/img/DIYSetting.png"></img>
                        </div>
                        {
                            this.state.DIYVisible ? <DiyNavigation DIYVisible={this.state.DIYVisible} defaultNavigation={ this.props.type == "item" ? itemDefaultNavigation:tradeDefaultNavigation} onClose={this.onClose.bind(this)} buyVip={this.buyVip.bind(this)} callback={this.callback.bind(this)} type={this.props.type} itemPid={this.state.itemPid} tradePid={this.state.tradePid} /> :''
                        }
                    </li>
                    {liTip}
                    <li className="navigation-toolbar" onMouseEnter={this.closeAllFun.bind(this)}>
                        <ul>
                            <li style={{lineHeight: '0'}} onClick = {this.buyVip.bind(this)}>
                                <div className = "nav-vipshow" >
                                    <span className = "infos" id = "header-info">{this.state.vipFlag}<br/></span>
                                    <span className = "time" id = "header-time">{this.state.vipTime}<br/></span>
                                    <span className = "live" id = "header-live">{this.state.vipBut}</span>
                                </div>
                            </li>
                            <li className='header-second'>
                                <div className='wangwang-style-div' onClick={() => {ww({nick:'爱用科技'})}} >
                                    <img src='//q.aiyongbao.com/trade/web/images/online.png'/>
                                </div>
                            </li>
                        </ul>
                   </li>
                </Navigation>
                {this.renderContent()}
            </div>
        )
    }
}
export default newGavigation;