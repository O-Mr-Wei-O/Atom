import React from 'react';
import {Button} from 'qnui';

/**
 * 错误弹窗下部按钮组件
 * @author zdh
 */
class ErrorDialogFooter extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            error_show:false
        };
    }

    makeErrorShow(){
        this.setState({error_show:true});
    }

    render(){
        const {error_show} = this.state;
        const {closeDialog,title,content,error} = this.props;
        let error_btn = null;
        if(error){
            error_btn = (
                <Button className="error-dialog-foot-button" style={{display:error_show?'none':'inline'}} type="primary" onClick={this.makeErrorShow.bind(this)}>查看错误源</Button>
            );
        }
        return (
            <div className="error-dialog-div">
                <div className="error-dialog-for-center">
                    <div className="error-dialog-content">
                        <div className="error-dialog-head">
                            <div className="error-dialog-head-div">
                                {
                                    title
                                }
                            </div>
                            <span onClick={closeDialog} className="error-dialog-head-close">
                                <i className="next-icon next-icon-close next-icon-small"></i>
                            </span>
                        </div>
                        <div className="error-dialog-line"></div>
                        <div className="error-dialog-body">
                            <div className="error-dialog-body-div">
                                {
                                    content
                                }
                            </div>
                        </div>
                        {/* display:error_show?'inherit':'none' */}
                        <div style={{display:error_show?'inherit':'none'}} className="error-dialog-line-2"></div>
                        <div className="error-dialog-foot">
                            <div style={{display:error_show?'inherit':'none'}} className="error-dialog-foot-error">
                                <div>
                                    错误源：
                                </div>
                                <div>
                                    {error}
                                </div>
                            </div>
                            <div className="error-dialog-foot-btn-div">
                                {
                                    error_btn
                                }
                                <Button className="error-dialog-foot-button" type="normal" onClick={closeDialog}>关闭</Button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default ErrorDialogFooter;
