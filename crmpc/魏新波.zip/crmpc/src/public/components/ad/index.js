import React from 'react';
import ReactDom from 'react-dom';
import moment from 'moment';
import fetchJsonp from 'fetch-jsonp';
import {api,ww,beacon,isEmpty} from 'utils/index';
import {Dialog} from 'qnui';
import SurePayDialog from '../modalAD/surePayDialog'
import ADDialog from '../modalAD/adDialog'

/**
 * 开始进入运营广告
 * @author Cbl
 * @return {[type]} [description]
 */
var item_vip = 0;
var g_loginuid = '000000';
var tbtime = moment().format('YYYY-MM-DD H:mm:ss');
var h_user;
var isSubuser=false;
var groupName='';           //订购商品类别
var successImageUrl='';     //订购成功图片url
var typeText = '';
successImageUrl='http://q.aiyongbao.com/trade/web/images/ad-trade-success.png';
function ShowAd(type){
    if(isEmpty(window.userInfo)){
        return;
        if(isEmpty(window.userInfo.vipFlag)) return;
    }
    //如果vipFlag不存在，默认为0 （youxiaowei）
    if(!isEmpty(window.userInfo)){
        item_vip =window.userInfo.vipFlag ? window.userInfo.vipFlag:0;
        g_loginuid = window.userInfo.userId;
    }
    if (g_loginuid) {
        g_loginuid = '000000';
    }
    if(type == 'smscare'){
        api({
            // host:"http://trade.ljn.aiyongbao.com",
            method:'/iytrade2/getOneUserForSmsPayLog',
            mode:'json',
            callback:(rsp)=>{
                if(rsp == 1){
                    if(isEmpty(window.userInfo.userType)){
                        runModal(type);
                    }else if(window.userInfo.userType != 'H'){

                            runModal(type);

                    }
                }
            },
            errCallback:(error)=>{

            },
            isloading:false
        })
        /*再获取modal信息*/

    }else{
        typeText=window.userInfo.vipFlag==1?'续费':'升级';
        tbtime = moment().format('YYYY-MM-DD H:mm:ss');
        //console.debug("Ad信息:"+user_nick+","+item_vip+","+viptime+","+type+","+tbtime+","+g_loginuid);
        if(vipDate('get')){
            return;
        }

        let element = document.getElementById('banner');
        if(element){
            //已经存在有广告了，不需要再初始化AD信息
        }else{
            initAd(type);
        }
    }



}

/**
 * 初始化Ad信息
 * @type {[type]}
 */
function initAd(type){
    let userType = window.userInfo.userType;
    if(userType == 'H'){

    }else{
            /*先获取banner信息*/
            runBanner(type);
            /*再获取modal信息*/
            runModal(type);

    }
    // api({
    //     method:'/trade/gethuser',
    //     callback:(data)=>{
    //         console.log("方便测试查看H版本："+data);
    //         h_user = data;
    //         if (h_user == '1' || h_user == 'fail') {/*如果是双11的用户*/
    //             return;
    //         }
    //         if ( !(type == 'index' || type == 'itemdetail')) {
    //             return;
    //         }
    //
    //     },
    //     errCallback:(error)=>{
    //         console.error(error);
    //         h_user = 0;
    //         if ( !(type == 'index' || type == 'itemdetail')) {
    //             return;
    //         }
    //         /*先获取banner信息*/
    //         runBanner(type);
    //         /*再获取modal信息*/
    //         runModal(type);
    //     }
    // })
}
/**
 * 获取Modal信息并展现
 * @return [type] [description]
 */
function runModal(type){
    let localItemString = window.userInfo.userNick + 'runModal';
    if(type == 'smscare'){//解决 首页和详情页广告弹两次问题
        localItemString = localItemString+type;
    }
    let lastshowday = window.localStorage.getItem(localItemString);
    let Tdate = new Date(tbtime).toLocaleDateString();
    if(lastshowday && lastshowday == Tdate){
        return;
    }
    let temppid = '439';
    if (type == 'itemdetail') {
        temppid = '447';
    }
    //判断是否为第一天使用爱用交易
    if(!isEmpty(window.userInfo) ){
        if(!isEmpty(window.userInfo.createdate)){
            let date=window.userInfo.createdate.split(' ')[0].split('-');
            let now=new Date();
            if(date[0]==now.getFullYear()&&date[1]==(now.getMonth()+1)&&date[2]==now.getDate()&&window.userInfo.vipFlag){
                temppid='1016';
            }
        }
    }

    if(type == 'smscare'){
        temppid = '1509';
    }

    //商品首页
    if(type == 'itemindex'){
        temppid = '436';
        //判断是否为第一天使用爱用商品
        if(!isEmpty(window.userInfo) ){
            if(!isEmpty(window.userInfo.createdate)){
                let date=window.userInfo.createdate.split(' ')[0].split('-');
                let now=new Date();
                if(date[0]==now.getFullYear()&&date[1]==(now.getMonth()+1)&&date[2]==now.getDate()&&window.userInfo.vipFlag){
                    temppid='1020';
                }
            }
        }
    }
    //商品详情页
    if(type == 'itemsdetail'){
        temppid = '437';
        //判断是否为第一天使用爱用商品
        if(!isEmpty(window.userInfo) ){
            if(!isEmpty(window.userInfo.createdate)){
                let date=window.userInfo.createdate.split(' ')[0].split('-');
                let now=new Date();
                if(date[0]==now.getFullYear()&&date[1]==(now.getMonth()+1)&&date[2]==now.getDate()&&window.userInfo.vipFlag){
                    temppid='1020';
                }
            }
        }
    }
    let feedbackUrl = 'https://oa-panther.data.aliyun.com/get_creative?pid='+ temppid +'&did=913181696&nf=1&n=10&mo=PC&IMEI='+g_loginuid+'&rs=0&f=creative_id,creative_name,img_size,category,dest_url,user_define';
    fetchJsonp(feedbackUrl,{
        jsonpCallback:'cb'
    })
    .then((response) => {
        return response.json();
    })//返回数据类型json
    .then((data) => {
        if (data == 'Param parse failed') {
            return;
        }
        if (data.status == '200') {/*获取信息成功*/
            let {imgPath,imgSize,destUrl,creativeId,closeable,couponFlag,subuser,creativeName,res} = initModalAD(data,temppid);
            imgPath = imgPath.replace(/https:|http:/,"");
            /*子账号判断*/
            if(window.userInfo.subUserNick){
                isSubuser = true;
            }

            /*优惠券判断*/
            if(couponFlag=='1'){
                console.log('discount');
            }else{
                localStorage.setItem(localItemString, Tdate);
                let adDialog = Dialog.alert({
                    needWrapper: false,
                    content: "",
                    title: "",
                    autoFocus:false,
                    footer: <div className="modal-ad-div">
                                    <div className="modal-ad-for-center">
                                        <div className="ad-dialog-con" style={{backgroundColor:'transparent'}}>
                                            { closeable ? <span onClick={()=>{adDialog.hide();}} className="icon-cancel-span">
                                                <svg className="ad-icon-cancel">
                                                    <use xlinkHref="#icon-cancel"></use>
                                                </svg>
                                            </span> : <span></span>}
                                            <div className="ad-dialog-con-img" style={{cursor:'pointer'}} onClick={()=>{
                                                beacon('TD20170614170642', 'zdtcdjmd', window.userInfo.userNick, temppid,creativeName,creativeId);
                                                if (!isEmpty(window.userInfo.subUserNick) && subuser!= undefined) {
                                                    let contactstr = "";
                                                    
                                                    contactstr = subuser.replace(/【URL】/,'【'+destUrl+'】');
                                                    wangwangPCModalAD(contactstr,0);
                                                 
                                                } else {
                                                    if(type == 'smscare'){
                                                        localStorage.setItem(window.userInfo.userNick + 'buyOneSmsPay', JSON.stringify(userInfo));
                                                    }
                                                    window.open(destUrl, '_blank');

                                                }
                                                feedbackClicked(data,res,creativeId,temppid,destUrl);}}>
                                                <img width={imgSize.split('*')[0]} height={imgSize.split('*')[1]} src={imgPath}/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                });
            }

        }
    })
    .catch((error) => {

    });

}

/**
 * 获取banner信息并展现
 * @return [type] [description]
 */
function runBanner(type){
    let element = document.getElementById('banner');
    if(element){
        return;
    }
    let lastshowday = window.localStorage.getItem(window.userInfo.userNick + 'bannerClose'+type);
    let Tdate = new Date(parseInt(tbtime)).toLocaleDateString();
    if(lastshowday && lastshowday == Tdate){
        return;
    }
    let temppid = '438';
    if (type == 'itemdetail') {
        temppid = '446';
    }
    if(!isEmpty(window.userInfo) ){
        if(!isEmpty(window.userInfo.createdate)){
            let date=window.userInfo.createdate.split(' ')[0].split('-');
            let now=new Date();
            if(date[0]==now.getFullYear()&&date[1]==(now.getMonth()+1)&&date[2]==now.getDate()&&window.userInfo.vipFlag){
                temppid='1017';
            }
        }
    }

    //商品首页
    if(type == 'itemindex'){
        temppid = '415';
        //判断是否为第一天使用爱用商品
        if(!isEmpty(window.userInfo) ){
            if(!isEmpty(window.userInfo.createdate)){
                let date=window.userInfo.createdate.split(' ')[0].split('-');
                let now=new Date();
                if(date[0]==now.getFullYear()&&date[1]==(now.getMonth()+1)&&date[2]==now.getDate()&&window.userInfo.vipFlag){
                    temppid='1021';
                }
            }
        }
    }
    //商品详情页
    if(type == 'itemsdetail'){
        temppid = '435';
        //判断是否为第一天使用爱用商品
        if(!isEmpty(window.userInfo) ){
            if(!isEmpty(window.userInfo.createdate)){
                let date=window.userInfo.createdate.split(' ')[0].split('-');
                let now=new Date();
                if(date[0]==now.getFullYear()&&date[1]==(now.getMonth()+1)&&date[2]==now.getDate()&&window.userInfo.vipFlag){
                    temppid='1021';
                }
            }
        }
    }

    let feedbackUrl = 'https://oa-panther.data.aliyun.com/get_creative?pid='+ temppid +'&did=913181696&nf=1&n=10&mo=PC&IMEI='+g_loginuid+'&rs=0&f=creative_id,creative_name,img_size,category,dest_url,user_define';
    fetchJsonp(feedbackUrl,{
        jsonpCallback:'cb'
    })
    .then((response) => {
        return response.json();
    })//返回数据类型json
    .then((data) => {
        if (data == 'Param parse failed') {
            return;
        }
        if (data.status == '200') {/*获取信息成功*/
            let result = [];
            let res = {};
            let adNum=0;
            for (let i in data.results) {
                let user_define = JSON.parse(data.results[i].user_define);
                if (user_define.body.vipflag == item_vip) {
                    result[result.length] = data.results[i];
                }
            }
            if (result.length == 1) {
                res = result[0];
            }else{
                let rdom = Math.floor((Math.random() * result.length) + 1);
                res = result[rdom - 1];
                adNum=rdom-1;
            }
            let img_path = res.img_path+'?qntag=3';
            img_path = img_path.replace(/https:|http:/,"");
            let user_define = res.user_define;
            user_define = JSON.parse(user_define);
            let dest_url = '';
            if(user_define.body.url){
                dest_url = user_define.body.url;
            }else{
                dest_url = res.dest_url.replace(/{equal}/,'=');
            }
            let subuser = user_define.body.subuser;
            let closable = user_define.body.closable;
            let func = ()=>{

                localStorage.setItem(window.userInfo.userNick + 'bannerClose'+type, Tdate);
                let element = document.getElementById('banner');
                if(element) element.parentNode.removeChild(element);
                var e = document.createEvent("Event");
                e.initEvent("resize", true, true);
                window.dispatchEvent(e);
            }

            let div = document.createElement('div');
            div.id = 'banner';
            document.getElementById('content_banner').insertBefore(div,document.getElementById('content_banner').childNodes[0]);

            let close_html = [];
            if (closable != 'false') {
                close_html.push(<span style={{float: 'right',marginLeft:'-10px'}} onClick={func}>
                    <img src='http://q.aiyongbao.com/trade/web/img/bannerClose.png' style={{width:'16px',position:'relative',bottom:'5px',opacity:'0.6'}}/>
                </span>);
            }
            let htmlstr = [];
            if (!isEmpty(window.userInfo.subUserNick)  && subuser!=undefined) {
                var contactstr = subuser.replace(/【URL】/,"【"+dest_url+"】");
                htmlstr.push(<a style={{display:'flex'}} href='javascript:void(0);'>
                                <img id="feedback1" onClick={()=>{beacon('TD20170614170642', 'zdtcdjmd', window.userInfo.userNick, temppid,user_define.body.creative_name,user_define.body.creative_id);wangwangPCModalAD(contactstr,0);feedbackClicked(data,res,res.creative_id,temppid,dest_url); }} src={img_path} alt=""/>
                                {close_html}
                           </a>);

            }else{
                htmlstr.push(<a style={{display:'flex'}} href="javascript:void(0);">
                                <img id="feedback1" onClick={()=>{beacon('TD20170614170642', 'zdtcdjmd', window.userInfo.userNick, temppid,user_define.body.creative_name,user_define.body.creative_id);window.open(dest_url, '_blank');feedbackClicked(data,res,res.creative_id,temppid,dest_url); }} src={img_path} alt=""/>
                                {close_html}
                           </a>);
            }
            feedbackShowed(data,adNum,temppid);
            ReactDom.render(
                <div style={{display:'flex',flex:1,flexDirection:'row',alignItems:'center',justifyContent:'center',width:'100%',marginBottom:'12px'}}>
                    {htmlstr}
                </div>,
                document.getElementById('banner')
            );
            setTimeout(()=>{
                var e = document.createEvent("Event");
                e.initEvent("resize", true, true);
                window.dispatchEvent(e);
            },500);

        }
    })
    .catch((error) => {

    });
}

/**
 * 子账号联系主账号
 * @return [type] [description]
 */
function wangwangPCModalAD(content,type){
    let nick='';
    if(type==0){
        nick = window.userInfo.userNick;
    }else{
        nick = '爱用科技';
    }
    ww({nick:nick,content:content});
}

/**
 * 判断是否为今日成功付费用户
 *
 */
function vipDate(type,pid,length){
    pid=pid?pid:'000';
    length=length?length:1;
    let loginUserNick;/*登录的userNick*/
    if(window.userInfo.subUserNick){
        loginUserNick = window.userInfo.subUserNick;
    }else {
        loginUserNick = window.userInfo.userNick;
    }

    //日期计算从当日6:00am-次日6:00am为一天
    let now_hour = moment().hour();
    let now;
    if(now_hour>=0&&now_hour<6){/*前一天*/
        now = moment().subtract(1, 'days').format('YYYY-MM-DD H:mm:ss');
    }else {
        now = moment().format('YYYY-MM-DD H:mm:ss');
    }

    if(type=='save'){           // 写入付费成功日期
        localStorage.setItem("vipDate"+loginUserNick,now);
        return;
    }else if(type=='get'){      // 判断是否为免广告日
        let vipDate=localStorage.getItem("vipDate"+loginUserNick);
        if(typeof vipDate!='undefined'&&vipDate!=null){
            if(moment(now).isSame(vipDate)){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }else if(type=='adNum'){    // A/B广告选择
        // update yxm 广告数组中0是初级班1是高级版
        let adNum=localStorage.getItem("adNum"+loginUserNick+pid);
        if(typeof adNum!='undefined'&&adNum!==null){
            adNum=JSON.parse(adNum);
            let adNumDate = adNum.date;
            if(moment(now).isSame(adNumDate)){
                adNum.number = window.userInfo.vipFlag=='1'?1:0;
                return adNum.number;
            }
        }
        let randomNum=Math.floor(Math.random()*length);
        randomNum = window.userInfo.vipFlag=='1'?1:0;
        localStorage.setItem("adNum"+loginUserNick+pid,JSON.stringify({date:now,number:randomNum}));
        return randomNum;
    }
}
function feedbackShowed(result,adNum,pid){
    if(result.open_id){
        var open_id=result.open_id;
        var open_cid=result.results[adNum].creative_id;
    }else{
        return;
    }
    feedback(open_id,open_cid,window.userInfo.userId,1,pid);
}

function feedbackClicked(result,res,open_cid,pid,url){
    let SMSgift = 0;//赠送短信，1为赠送，0为不赠送
    if(!isEmpty(res.user_define)){
        let user_define = JSON.parse(res.user_define);
        if(user_define.body.SMSgift) SMSgift = user_define.body.SMSgift;
    }
    if(SMSgift == 1 && window.userInfo.userType != 'H'){//测试0，正式改1
        let json = {};
        json.userNick = window.userInfo.userNick;
        json.cid = open_cid;
        json.vipTime = window.userInfo.vipTime;
        json.vipFlag = window.userInfo.vipFlag;
        json.now = moment().format('YYYY-MM-DD');
        window.localStorage.setItem(json.userNick+ 'SmsActs',JSON.stringify(json));
    }
    if(result.open_id){
        var open_id=result.open_id;
        feedback(open_id,open_cid,window.userInfo.userId,2,pid,url);
    }else{
        return;
    }
}

function feedback(open_id, open_cid, imei, type,pid, url) {
	url=url||'';

	let feedbackUrl = 'https://oa-markhor.data.aliyun.com/feedback?open_id=' + open_id + '&open_cid=' + open_cid + '&type=' + type + '&imei=' + imei+'&pid='+pid+'&cb=callbacksAd';
	if (url){
		feedbackUrl += '&url=' + encodeURIComponent(url);
	}

    fetchJsonp(feedbackUrl,{

    })
    .then((response) => {
        return response.json();
    })//返回数据类型json
    .then((result) => {

    })
    .catch((error) => {

    });

}
window.callbacksAd = (json) =>{}
/**
 * 初始化订购页面
 * @author zdh
 * @dateTime 2017-08-13T12:45:46+080
 * @param    {[type]}                result [description]
 * @param    {[type]}                pid    [description]
 * @return   {[type]}                       [description]
 */
function initModalAD(data, pid){
    //let adNum=vipDate('adNum',pid,data.results.length);/*选取广告*/
    let result = [];
    for (let i in data.results) {
        let user_define = JSON.parse(data.results[i].user_define);
        if (user_define.body.vipflag == item_vip) {
            result[result.length] = data.results[i];
        }
    }
    let adNum = 0;
    let res = '';
    if (result.length == 1) {
        res = result[0];
    }else{
        let rdom = Math.floor((Math.random() * result.length) + 1);
        res = result[rdom - 1];
        adNum=rdom-1;
    }

    let userDefine=JSON.parse(res.user_define).body;

    let obj={};
    obj.imgPath=res.img_path;
    obj.imgSize=res.img_size;
    obj.destUrl=res.dest_url;
    obj.closeable=userDefine['closable'];
    obj.adText=userDefine['ad-text'];
    obj.subuser=userDefine['subuser'];
    obj.creativeName=res.creative_name;
    obj.creativeId=res.creative_id||'';
    obj.res = {...res};
    feedbackShowed(result,adNum,pid);
    return obj;
}

export default ShowAd;
