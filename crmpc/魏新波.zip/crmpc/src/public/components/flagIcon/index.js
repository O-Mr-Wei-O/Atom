import React from 'react';
import './index.scss';

/**
 * 旗子图标  type  旗子类型 对应内容如下
 * @type {[type]}
 */
class FlagIcon extends React.Component {
    constructor(props) {
        super(props);
    }
    /**
     * 0 灰色：989898
     * 1 红色：FF0000
       2 黄色：FBF700
       3 绿色：00FF00
       4 蓝色：004DFF
       5 紫色：F700FF
     * @author zdh
     * @dateTime 2017-08-08T10:42:31+080
     * @return   {[type]}                [description]
     */
    render(){
        const {type} = this.props;
        let fill_color = "";
        switch (type) {
            case 0:
                fill_color = "#989898";
                break;
            case 1:
                fill_color = "#FF0000";
                break;
            case 2:
                fill_color = "#FBF700";
                break;
            case 3:
                fill_color = "#00FF00";
                break;
            case 4:
                fill_color = "#004DFF";
                break;
            case 5:
                fill_color = "#F700FF";
                break;
            default:
                fill_color = "#989898";    
        }
        return (
            <svg className="icon-flag" style={{fill:fill_color}}>
                <use xlinkHref="#icon-icon-life-flag"></use>
            </svg>
        );
    }
}
export default FlagIcon;
