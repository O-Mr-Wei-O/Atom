//从./containers/index.js导入
import {Demo, Reverse} from './containers/index';

const createRoutes = {
    path: '/',
    // component: Layout,
    indexRoute: {component: Demo},
    childRoutes: [
        {
            path: 'demo',
            component: Demo
        },

        /**
         *author:Sinpo
         *Date: 2018/1/16
         *Function:添加新的路由reverse
         */

        {
            path: 'reverse',
            component: Reverse
        }
    ]
}
export default createRoutes;
