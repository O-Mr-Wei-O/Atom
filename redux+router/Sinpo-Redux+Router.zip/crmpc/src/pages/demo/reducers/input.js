/** input.js
 *author:Sinpo
 *Date: 2018/1/16
 *Function:reducer
 */

//创建一个初始化的state
const initialState = {
    arr: []
}

function pushInArrayReducer(state = initialState, action) {
    switch (action.type) {

        /** input.js
         *author:Sinpo
         *Date: 2018/1/16
         *Function:获取state，并将input输入值push进数组
         */
        case 'PUSH_IN':
            const Arr = state.arr;
            Arr.push(action.value);
            // console.log(Arr);
            return {
                arr: Arr
            };

        /**
         *author:Sinpo
         *Date: 2018/1/16
         *Function:获取state，并将input输入值unshift进数组
         */

        case 'UNSHIFT_IN':
            const Arr_shift = state.arr;
            Arr_shift.unshift(action.value);
            // console.log(Arr);
            return {
                arr: Arr_shift
            };

        /**
         *author:Sinpo
         *Date: 2018/1/16
         *Function:通过splice删除对应值并返回state
         */
        case 'deleteRow':
            const Arr_del = state.arr;
            Arr_del.splice(action.index, 1);
            // console.log("deleteRow"+Arr_del);
            return {
                arr: Arr_del
            };
        default:
            return state
    }
}

export default pushInArrayReducer;
