'use strict';

import {combineReducers} from 'redux';
import {routerReducer} from 'react-router-redux';
import pushInArrayReducer from './input';

/**
 *author:Sinpo
 *Date: 2018/1/16
 *Function:将现有的reduces加上路由的reducer
 */
const rootReducer = combineReducers({
    pushInArrayReducer,
    routing: routerReducer
});

export default rootReducer;
