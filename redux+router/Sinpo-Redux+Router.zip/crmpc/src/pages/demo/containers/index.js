import Demo from './Input/index';
import Reverse from './reverse/index'

/**
 *author:Sinpo
 *Date: 2018/1/16
 *Function:导出相应模块
 */
export {
    Demo,
    Reverse
}
