import React from 'react';
import './index.scss';
import Input from './input';
import Result from './result';
import {connect} from 'react-redux';
import {Link} from 'react-router';

/**
 * [constructor description]
 *
 * @author Sinpo
 * @date   2018-1-16 16:53:50
 * @param  {[type]}                props [description]
 * @return {[type]}                [description]
 */


class Reverse extends React.Component {
    render() {
        return (
            <div>
                {/*链接向原来的页面*/}
                <Link to="/demo" id="linkToOrigin">To Original</Link>
                <Input/>
                <Result/>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return state
}


export default connect(mapStateToProps)(Reverse);
