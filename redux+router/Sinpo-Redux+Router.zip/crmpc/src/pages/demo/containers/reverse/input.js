import React, {Component} from 'react';
import {connect} from 'react-redux';

/**
 *author:Sinpo
 *Date: 2018/1/16
 *Function:
 */

class input extends Component {
    render() {
        return (
            <div>
                <span>请输入：</span>
                <br/>
                <input id='text' type="text" maxLength="24" placeholder="最大输入长度为24个字符"/>
                <button className='btn' onClick={this.props.pushInArray}>A d d</button>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return state
}

function mapDispatchToProps(dispatch) {
    return {
        pushInArray() {
            const text = document.getElementById('text').value;
            if (text !== '') {
                document.getElementById('text').value = '';
                // unshift进数组
                dispatch({
                    type: 'UNSHIFT_IN',
                    value: text
                })
            }
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(input);
