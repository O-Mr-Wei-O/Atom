import React, {Component} from 'react';
import {connect} from 'react-redux';

/**
 *author:Sinpo
 *Date: 2018/1/16
 *Function:输入框和按钮
 */

class input extends Component {
    render() {
        return (
            <div>
                <span>请输入：</span>
                <br/>
                <input id='text' type="text" maxLength="24" placeholder="最大输入长度为24个字符"/>
                <button className='btn' onClick={this.props.pushInArray}>A d d</button>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return state
}

function mapDispatchToProps(dispatch) {
    return {
        pushInArray() {
            // 若是input不为空再进行插入，不然默认会有一个空位
            const text = document.getElementById('text').value;
            if (text !== '') {
                document.getElementById('text').value = '';
                // push进数组
                dispatch({
                    type: 'PUSH_IN',
                    value: text
                })
            }
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(input);
