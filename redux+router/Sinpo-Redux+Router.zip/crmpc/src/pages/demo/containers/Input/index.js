import React from 'react';
import './index.scss';
import Input from './input';
import Result from './result';
import {connect} from 'react-redux';
import {Link} from 'react-router';

/**
 * [constructor description]
 *
 * @author Sinpo
 * @date   2018-1-15 11:20:40
 * @param  {[type]}                props [description]
 * @return {[type]}                [description]
 */


class Demo extends React.Component {
    render() {
        return (
            <div>
                {/*链接向反向的页面*/}
                <Link to="/reverse" id="link">To Reverse</Link>
                <Input/>
                <Result/>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return state
}


export default connect(mapStateToProps)(Demo);
