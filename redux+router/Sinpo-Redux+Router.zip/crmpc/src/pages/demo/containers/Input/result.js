import React, {Component} from 'react';
import {connect} from 'react-redux';

/**
 *author:Sinpo
 *Date: 2018/1/16
 *Function:结果展示框
 */


class result extends Component {
    render() {
        const LiArr = [];
        //底下的arr不能直接展示state.pushInArrayReducer.arr,
        //所以将获取到的数组遍历并传入新数组进行赋值
        //空数组split依然有一个长度，所以要先排除为空
        if (this.props.arr !== '') {
            for (let i = 0; i < this.props.arr.split(",").length; i++) {
                LiArr.push(<li className="Li">{this.props.arr.split(",")[i]}<a
                    style={{'cursor': 'pointer', 'marginLeft': '10'}} data-index={i} onClick={this.props.delete}>X </a>
                </li>);
            }
        }

        return (
            <ul>
                {LiArr}
            </ul>
        )
    }
}

function mapStateToProps(state) {
    return {
        arr: state.pushInArrayReducer.arr.toString()
    }
}

function mapDispatchToProps(dispatch) {
    return {
        delete() {
            //获取点击的行index
            const index = event.target.getAttribute("data-index");
            dispatch({
                type: 'deleteRow',
                index: index
            })
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(result);
