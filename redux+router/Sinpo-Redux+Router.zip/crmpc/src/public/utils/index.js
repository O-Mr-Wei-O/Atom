'use strict';
// import apimap from './apimap';
import domain from 'components/biz/env/domain';
// import domain from './domain';
// if(window.location.search.indexOf('servurl') > -1 ){
//     let QNP = require('qn-proxy');
//     try{
//         QN = QNP;
//     }catch(e){
//         setTimeout(()=>{QN=QNP},500);
//     }
// }
import 'whatwg-fetch';
// import reqwest from 'reqwest';
// import QN from 'qn-proxy';
import fetchJsonp from 'fetch-jsonp';
import ErrorDialog from 'public/components/errorDialog/index';
import MsgToast from 'public/components/msgToast/index';
import translateUrl from 'components/biz/agreementApi/translateUrl';
// import SubUserAuthDialog from 'components/subUserAuthDialog/index';
import moment from 'moment';
/*apienv的可选值 local,development,production */
// const apienv = window.apienv || 'local';
var iTime;
var Tools = {
  /**
   * [ajax description]  可以本地模拟服务器返回数据
   * @param  {[type]} param 参数
   * @param  {[type]} suc   成功回调
   * @param  {[type]} err   失败回调
   * @return {[type]}       [description]
   */
  /*ajax: function (param, suc, err) {
    //在demo html中修改window.apienv实现不同环境的数据接口切换
    param.url = apimap[apienv][param.api];
    param.type = 'json';
    return reqwest(param).then((res)=>{
      if(res.code === 200){//默认接口请求成功的判断条件，可以自行修改,也可以按照自己约定来做判断
          suc && suc(res);
          // console.log('接口请求成功',res);
      }else {//在这里可以统一自定义错误返回码异常处理
        //TODO:接口统一异常处理
          err && err(res);
          // console.error('接口请求失败',res);
      }
      return res;
    }).catch((error)=>{ //接口异常处理，返回response.status 非20x或者1223时会进入这里
        throw new Error(`接口${param.api}调用失败！服务端异常！${error.message}`);
    })
  },*/
  isLocal(){
    var host = window.location.host;
    return host.indexOf('127.0.0.1') > -1 || host.indexOf('localhost') > -1;
  },
  getServerTime: function({callback,errorCallback = ()=>{}}){
      try{
          QN.application.invoke( {
              cmd : 'getServerTime',
              param : {

              },
              error : function(msg, cmd, param) {
                 let time  = moment().format('YYYY-MM-DD HH:mm:ss')
                 callback(time);

              },
              success : function(rsp, cmd, param) {
                 // 回调结果
                 let time  = moment(Number(rsp.time)).format('YYYY-MM-DD HH:mm:ss')
                 callback(time);
              }
          });
      }catch(e){
          setTimeout(function(){
              getServerTime({callback,errorCallback});
          },300);
      }
  },
  /**
   * 获取url中指定参数
   * @param  {[type]} name [key]
   * @return {[type]}      [description]
   */
  getUrlParam: function(name) {
    var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)');
    var r = decodeURIComponent(window.location.search.substr(1)).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
  },
  isArray: function(object) {
    return object instanceof Array;
  },
  isWindow: function(obj) {
    return obj != null && obj == obj.window;
  },
  isDocument: function(obj) {
    return obj != null && obj.nodeType == obj.DOCUMENT_NODE;
  },
  isObject: function(obj) {
    return this._type(obj) == 'object';
  },
  isFunction: function(fn) {
    return this._type(fn) == 'function';
  },
  isPlainObject: function(obj) {
    return this.isObject(obj) && !this.isWindow(obj) && Object.getPrototypeOf(obj) == Object.prototype;
  },
  _type: function(obj) {
    var class2type = {};
    var toString = class2type.toString;
    return obj == null ? String(obj) :
    class2type[toString.call(obj)] || 'object';
  },
  isString: function(str) {
    return typeof str === 'string';
  },
  extend: function(target, source) {
    target = target || {};
    source = source || {};
    for (var key in source) {
      target[key] = source[key];
    }
    return target;

  },
  namespace: function(name) {
    return function(v) {
      return name + '-' + v;
    };
  },
  /**
   * 判断一个值是否为空
   * author: cbl
   * @param  {[type]}  key [description]
   * @return {Boolean}     [description]
   */
  isEmpty: function(key){
      if (typeof(key) === 'string') {
          key = key.replace(/(^\s*)|(\s*$)/g, '');
          if (key == '' || key == null || key == 'null' || key == undefined || key == 'undefined') {
              return true
          } else {
              return false
          }
      } else if (typeof(key) === 'undefined') {
          return true;
      } else if (typeof(key) == 'object') {
          for(let i in key){
              return false;
          }
          return true;
      }else if (typeof(key) == 'boolean'){
          return false;
      }
  },
  /**
   * 获取用户信息
   * author: cbl
   * @param  {[type]} options.url      [如果是从入口页进入要带一个标志]
   * @param  {[type]} options.callback [成功回调用户信息json]
   * @return {[type]}                  [description]
   */
  getUserInfo: function({callurl = null,callback = ()=>{}}){
      let url = location.href.indexOf('taobao_user_nick') > -1 ? location.href : '';
      if (url) {
          	window.userInfo = {
          		'userNick'    : getUrlParam('taobao_user_nick'),
          		'userId'      : getUrlParam('taobao_user_id'),
          		'subUserNick' : getUrlParam('sub_taobao_user_id') != 0 ? getUrlParam('nick') : '',
          		'subUserId'   : getUrlParam('sub_taobao_user_id'),
          		'vipFlag'     : getUrlParam('vipflag') ? Number(getUrlParam('vipflag')) : 0,
          		'vipTime'     : getUrlParam('order_cycle_end'),
          		'userType'    : getUrlParam('roleid'),
          		'createdate'  : getUrlParam('createdate')
          	};
            let closeopen = getUrlParam('closeopen');
            if(!this.isEmpty(closeopen)){
                localStorage.setItem('closeopen',closeopen);
            }
            //localStorage.setItem('loginNick',window.userInfo.userNick);//更新当前登陆的用户  by Mothpro

          	if (url && getUrlParam('needauth') != '0') {
          		if (!window.userInfo.subUserNick) {  //主账号才去重新授权
                      translateUrl('tradeindex');
                  } else {
                      let ReactDom = require('react-dom');
                      try{
                  	localStorage.setItem('subUserAuth', 1);
                    }catch(e){}
                      let func = ()=>{
                          let element = document.getElementById("subUserAuth");
                          if(element) element.parentNode.removeChild(element);
                      }
                      let div = document.createElement('div');
                      div.id = 'subUserAuth';
                      document.getElementById('container').appendChild(div);

                      ReactDom.render(
                          <SubUserAuthDialog />,
                        	document.getElementById('subUserAuth')
                      );
                  }
          	} else {
          		localStorage.removeItem('subUserAuth');
          	}




          let now = new Date().getTime();
          let userInfoOld  = localStorage.getItem(window.userInfo.userNick);

          if (userInfoOld && (now - JSON.parse(userInfoOld).modified) < 1209600000) { //缓存里有用户信息 && 缓存里的数据小于14天 无需更新
              // console.log('取缓存');
              userInfoOld = JSON.parse(userInfoOld);

              window.userInfo.sellerInfo = userInfoOld.sellerInfo;
              window.userInfo.shopInfo = userInfoOld.shopInfo;
              window.userInfo.modified = userInfoOld.modified;
                //处理 localStorage满了问题
                try{
                    localStorage.setItem('userLogging',JSON.stringify(window.userInfo));
                }catch(e){
                    console.warn('用户C盘可能已经满了，存储localStorage报错');
                }
              this.confirmUserInfo(window.userInfo);
              callback(window.userInfo);
          } else {  //缓存里没有
              console.log('Nohava');
              window.userInfo.modified = now;
              this.qnapi({
                  api: 'taobao.user.seller.get',
                  params: {
                    fields: 'type,seller_credit'
                  },callback: (result)=>{
                      // console.log(result);
                      window.userInfo.sellerInfo = result.user_seller_get_response.user;
                      this.qnapi({
                          api: 'taobao.shop.get',
                          params: {
                            nick: window.userInfo.userNick,
                            fields:'title,shop_score,pic_path'
                          },
                          callback: (result)=>{
                              if (result.shop_get_response.shop.pic_path) { //店铺图片 没有图片补一个默认的
                                  result.shop_get_response.shop.pic_path = 'http://logo.taobao.com/shop-logo' + result.shop_get_response.shop.pic_path;
                              } else {
                                  result.shop_get_response.shop.pic_path = '//q.aiyongbao.com/trade/web/images/qap_img/mobile/mrtx.jpg';
                              }
                              window.userInfo.shopInfo = result.shop_get_response.shop;
                              try{
                              localStorage.setItem('userLogging',JSON.stringify(window.userInfo));
                              localStorage.setItem(window.userInfo.userNick,JSON.stringify(window.userInfo));
                              }catch(e){}
                              this.confirmUserInfo(window.userInfo);
                              callback(window.userInfo);
                          },errorCallback:(error)=>{
                              // console.log(error);
                              let shopInfo = {
                                pic_path: '//q.aiyongbao.com/trade/web/images/qap_img/mobile/mrtx.jpg',
                                shop_score:{
                                  delivery_score: 'null',
                                  item_score: 'null',
                                  service_score: 'null'
                                },
                                title: window.userInfo.userNick
                              }
                              window.userInfo.modified = 0;
                              window.userInfo.shopInfo = shopInfo;
                              try{
                              localStorage.setItem('userLogging',JSON.stringify(window.userInfo));
                              localStorage.removeItem(window.userInfo.userNick);
                              }catch(e){}
                              this.confirmUserInfo(window.userInfo);
                              callback(window.userInfo);
                          }
                      });
                  },errorCallback:(error)=>{
                      // console.log(error);
                      let sellerInfo = {
                          type: 'C',
                          seller_credit: {
                              good_num: null,
                              level: null,
                              score: null,
                              total_num: null
                          }
                      }
                      window.userInfo.modified   = 0;
                      window.userInfo.sellerInfo = sellerInfo;
                      this.qnapi({
                          api: 'taobao.shop.get',
                          params: {
                            nick: window.userInfo.userNick,
                            fields:'title,shop_score,pic_path'
                          },
                          callback: (result)=>{
                              // console.log(result);
                              if (result.shop_get_response.shop.pic_path) { //店铺图片 没有图片补一个默认的
                                  result.shop_get_response.shop.pic_path = 'http://logo.taobao.com/shop-logo' + result.shop_get_response.shop.pic_path;
                              } else {
                                  result.shop_get_response.shop.pic_path = '//q.aiyongbao.com/trade/web/images/qap_img/mobile/mrtx.jpg';
                              }
                              window.userInfo.shopInfo = result.shop_get_response.shop;
                              try{
                              localStorage.setItem('userLogging',JSON.stringify(window.userInfo));
                              localStorage.removeItem(window.userInfo.userNick);
                              }catch(e){}
                              this.confirmUserInfo(window.userInfo);
                              callback(window.userInfo);
                          },errorCallback:(error)=>{
                              // console.log(error);
                              let shopInfo = {
                                pic_path: '//q.aiyongbao.com/trade/web/images/qap_img/mobile/mrtx.jpg',
                                shop_score:{
                                  delivery_score: 'null',
                                  item_score: 'null',
                                  service_score: 'null'
                                },
                                title: window.userInfo.userNick
                              }
                              window.userInfo.shopInfo = shopInfo;
                              try{
                              localStorage.setItem('userLogging',JSON.stringify(window.userInfo));
                              localStorage.removeItem(window.userInfo.userNick);
                              }catch(e){}
                              this.confirmUserInfo(window.userInfo);
                              callback(window.userInfo);
                          }
                      });
                  }
              });
          }
      } else {
          window.userInfo = localStorage.getItem('userLogging');
          if(this.isEmpty(window.userInfo)){
              let self = this;
              QN.application.invoke( {
                        cmd : 'getLoginuser',
                        param : {

                        },
                        error : function(msg, cmd, param) {
                           window.userInfo = {
                               'userNick'    : 'null',
                               'userId'      : '000000',
                               'subUserNick' : '',
                               'subUserId'   : '',
                               'vipFlag'     : 0,
                               'vipTime'     : '1990-01-01',
                               'userType'    : 'A',
                               'createdate'  : '1990-01-01',
                           };
                           callback(window.userInfo);
                        },
                        success : function(rsp, cmd, param) {
                            window.userInfo = {
                          		'userNick'    : decodeURIComponent(rsp.user_nick),
                          		'userId'      : rsp.user_id,
                          		'subUserNick' : self.isEmpty(rsp.sub_user_nick) ? '' : decodeURIComponent(rsp.sub_user_nick),
                          		'subUserId'   : self.isEmpty(rsp.sub_user_id) ? '' : decodeURIComponent(rsp.sub_user_id),
                          		'vipFlag'     : 0,
                          		'vipTime'     : '1990-01-01',
                          		'userType'    : 'A',
                          		'createdate'  : '1990-01-01',
                          	};
                            self.confirmUserInfo(window.userInfo);
                            callback(window.userInfo);
                        }
                });

          }else{
              window.userInfo = JSON.parse(window.userInfo);
              this.confirmUserInfo(window.userInfo);
              callback(window.userInfo);
          }

      }
  },
  smsActUpdate: function(cid){
      api({
        //   host:"http://trade.ljn.aiyongbao.com",
          method:'/iytrade2/getSmsActNum',
          args:{cid:cid},
          mode:'json',
          callback:(rsp)=>{
              if(rsp != 'fail'){
                  if(rsp != 0 ){
                      try{
                      window.localStorage.setItem(window.userInfo.userNick + "tipVisible",rsp)
                      }catch(e){}
                  }
                  window.localStorage.removeItem(window.userInfo.userNick+ 'SmsActs');
              }
          },
          errCallback:(error)=>{

          },
          isloading:false
      })
  },
  /**
   * 用户登录二次确认用户信息
   * @param  {[type]} userInfo [description]
   * @return {[type]}          [description]
   */
  confirmUserInfo: function(userInfo,callback) {
      setTimeout(()=>{
          fetchJsonp(domain.mhost+'/tc/user', {
            jsonpCallback: 'callback'
          })
          .then((response) => response.json())//返回数据类型json
          .then((data) => {


              /**
               * vipResult 付费结果
               * 1 升级成功
               * -1 升级失败
               * 2 续费成功
               * -2 续费失败
               */
              let vipResult = -1;
              let new_vipFlag = data.vipflag;
              let new_vipTime = data.order_cycle_end.split(' ')[0];

              let smsActs = window.localStorage.getItem(window.userInfo.userNick+ 'SmsActs');
              if(!this.isEmpty(smsActs)){
                  smsActs = JSON.parse(smsActs);
                  let act_vipFlag = smsActs.vipFlag;
                  let act_vipTime = smsActs.vipTime;
                  let cid = smsActs.cid;
                  let actTime = smsActs.now;

                  let now = moment().format('YYYY-MM-DD');
                  let diffDay = moment(now).diff(actTime, 'days');

                  if(diffDay > 1){//超过一天取消活动赠送
                      window.localStorage.removeItem(window.userInfo.userNick+ 'SmsActs');
                  }

                  if(new_vipFlag == 1){
                      if(act_vipFlag == 0){
                          //赠送短信
                          this.smsActUpdate(cid);
                      }else{
                          let diff = moment(new_vipTime).diff(act_vipTime, 'days');
                          if(diff > 0){
                              //赠送短信
                              this.smsActUpdate(cid);
                          }
                      }
                  }
              }

              if(!this.isEmpty(callback)){

                  let old_vipFlag = userInfo.vipFlag;
                  let old_vipTime = userInfo.vipTime;

                  if(old_vipFlag == 0){/*升级*/
                      if(new_vipFlag == 0){/*升级失败*/
                          vipResult = -1;
                      }else {/*升级成功*/
                          vipResult = 1;
                      }
                  }else {/*续费  old_vipFlag==1*/
                      if(new_vipFlag == 0){/*续费失败*/
                          vipResult = -2;
                      }else {/*续费*/
                          if(moment(old_vipTime).isSame(new_vipTime)){/*续费失败*/
                              vipResult = -2;
                          }else {/*续费成功*/
                              vipResult = 2;
                          }
                      }
                  }
              }



              userInfo.vipFlag  = new_vipFlag;
              userInfo.vipTime  = new_vipTime;
              if(data.roleid){
                  userInfo.userType = data.roleid;
              }
              if(data.notice!=undefined){
                  try{
                  localStorage.setItem(`${userInfo.userNick}AYTextAlert`,JSON.stringify(data.notice));
                  }catch(e){}
              }else{
                  localStorage.removeItem(`${userInfo.userNick}AYTextAlert`);
              }
              try{
              localStorage.setItem('userLogging',JSON.stringify(userInfo));
              localStorage.setItem(userInfo.userNick,JSON.stringify(userInfo));
              }catch(e){}
              window.userInfo = userInfo;

              if(!this.isEmpty(callback)){
                  callback(vipResult);
              }
          })
          .catch((error) => {
              console.error('从服务器获取用户信息失败');
          });
      },1000)

  },
  /**
   * 调用淘宝api
   * author: cbl
   * @param {[type]} options.api          [api名字]
   * @param {[type]} options.params       [api所需要的参数]
   * @param {String} options.method       [请求方式 默认是post]
   * @param {[type]} options.callback     [成功回调]
   * @param {[type]} options.errCallback [失败回调 默认为空]
   */
  qnapi: function({api,params,method = 'post',callback,errCallback = undefined,withoutTry = false}){
      if(params!=undefined){
          if(params.nick) params.nick=decodeURI(params.nick);//解决nick中文编码的影响
      }
      var self = this;
          if (this.isEmpty(localStorage.getItem('dataFromRouter'))) {
              try{
                  QN.top.invoke({
                      cmd    : api,
                      param  : params,
                      method : method,
                      success: function (rsp){
                          try {
                              callback(rsp);
                          } catch (e) {
                              console.error("淘宝api调用失败"+api,e);
                          }
                      },
                      error: function(msg){
                          console.log(msg);
                          self.loading('hide');
                          if (errCallback) {
                              errCallback(msg);
                          } else {

                          }
                      }
                  });
              }catch(e){
                  if (withoutTry) {
                    if (errCallback) {
                        errCallback(e);
                    }
                  } else {
                    setTimeout(function(){
                        qnapi({api,params,method,callback,errCallback});
                    },300);
                  }

              }
          } else {
              let data = {
                  method:api,
                  param:params
              }
              this.api({
                  method:'/router/rest',
                  args:data,
                  mode:'jsonp',
                  callback:(rsp)=>{
                      callback(rsp);
                  },
                  errCallback:(error)=>{
                      self.loading('hide');
                      if (errCallback) {
                          errCallback(error);
                      } else {

                      }
                  },
                  isloading:false
              })
          }

  },
  /**
   * json转换字符串并进行uri编码
   * author: cbl
   * @param  {[type]} obj [json]
   * @return {[type]}     [uri]
   */
  toQueryString: function(obj) {
    return obj ? Object.keys(obj).sort().map(function (key) {
        var val = obj[key];
        if (Array.isArray(val)) {
            return val.sort().map(function (val2) {
                return encodeURIComponent(key) + '=' + encodeURIComponent(val2);
            }).join('&');
        }
        return encodeURIComponent(key) + '=' + encodeURIComponent(val);
    }).join('&') : '';
  },
  /**
   * 把json解析成字符串
   * author 张文
   * @param  {[type]} data [description]
   * @return {[type]}      [description]
   */
  childStr: function (data) {
    let childArr = [];
    if(typeof(data) == 'object'){
      for (let key in data) {
        for (let i in this.childStr(data[key])) {
          childArr.push('[' + key + ']' + this.childStr(data[key])[i]);
        }
      }
    } else {
      childArr.push(('=' + encodeURIComponent(data)));
    }
    return childArr;
  },
  /**
   * 把json解析成字符串
   * author 张文
   * @param  {[type]} data [description]
   * @return {[type]}      [description]
   */
  buildStr: function (data){
    let str = '';
    for (let key in data) {
      for (let i in this.childStr(data[key])) {
        str += (key + this.childStr(data[key])[i] + '&');
      }
    }
    return str.substr(0, str.length-1);
  },
  /**
   * 调用php接口方法
   * author: cbl
   * @param  {[type]}   method   [接口名称]
   * @param  {String}   args     [参数 默认为空]
   * @param  {String}   mode     [默认jsonp 否则为json]
   * @param  {Function} callback [成功回调]
   * @return {[type]}            [description]
   */
  api: function({method,args='',mode='jsonp',callback,errCallback = undefined,isloading = true,host = domain.host}){
      var self = this;
    if(isloading)self.loading('show','数据加载中，请稍后……');
    if (mode == 'jsonp') {
      args = this.buildStr(args);
      if(args!=''){
          args = '?'+args;
      }
      fetchJsonp(host + method + args, {
        jsonpCallback: 'callback'
      })
      .then((response) => response.json())//返回数据类型json
      .then((responseText) => {
          if (isloading) {
              self.loading('hide');
          } else {
            // statement
          }

        if(responseText == 'fail'){
          //遇见错误时弹框提示   by Mothpro
          //session获取失败登录失效
          ErrorDialog('温馨提示','登录失效，请重新打开插件！','fail');
        }else{
            try {
                callback(responseText);
            } catch (e) {
                console.error("后台php调用失败"+method,e);
            }
        }
      })
      .catch((error) => {
          if (isloading) {
              self.loading('hide');
          } else {
            // statement
          }

          //错误处理，待补充
          // console.log(error);
          if (errCallback) {
            errCallback(error);
          } else {

          }
      });
    } else {
        var formData = new FormData();
        formData = this.buildArgs(formData,args);
        fetch(`${host}${method}`, {
            method : 'POST',
            mode : 'cors',
            credentials: 'include',
            body : formData
        }).then((res)=>res.json()).then(function(responseText){
            if (isloading) {
                self.loading('hide');
            } else {
              // statement
            }
            if(responseText == 'fail'){
                //遇见错误时弹框提示   by Mothpro
                //session获取失败登录失效
                ErrorDialog('温馨提示','登录失效，请重新打开插件！','fail');
            }else{
                callback(responseText);
            }
        }, function(error){
            if (isloading) {
                self.loading('hide');
            } else {
              // statement
            }
            //错误处理，待补充
            // console.log(error);
            if (errCallback) {
                errCallback(error);
            } else {

            }
        });
    }
  },
  buildArgs:function(formData,args,keys = []){
    for(let i in args){
        if(typeof(args[i]) == 'object'){
            let newkeys = [...keys];
            if(newkeys.length > 0){
                newkeys[0] = newkeys[0] + `[${i}]`;
            }else{
                newkeys.push(i);
            }
            this.buildArgs(formData,args[i],newkeys);
        }else{
            let key = '';
            keys.map( c => {
                this.isEmpty(key) ? key = c : key += `[${c}]`;
            })
            this.isEmpty(key) ? formData.append(i,args[i]) : formData.append(key+`[${i}]`,args[i]);
        }
    }
    return formData;
  },
  /**
   * 同步方式调用api
   *
   * @author Mothpro
   * @date   2017-08-09T12:05:17+080
   * @param  {[type]}                method [description]
   * @param  {[type]}                param  [description]
   * @return {[type]}                [description]
   */
  apiAwait:async function(method,param){
      param = this.toQueryString(param);
      let msg = {}
      let url = `${domain.host}${method}?${param}`;
      try {
        let response = await fetch(url);
        let data = await response.json();
        msg.code = true;
        msg.response = data;
        return msg;
      } catch(e) {
             msg.code = false;
             msg.response = e;
            return msg;
      }
  },
  /**
   * 呼起旺旺
   * author: cbl
   * @param  {String} options.nick     [nick 不填默认为联系客服]
   * @param  {String} options.content  [内容 联系客服有默认值]
   * @param  {[type]} options.callback [回调]
   * @return {[type]}                  [description]
   */
  ww: function({nick = undefined,content = undefined,callback = undefined}){
    if (nick) {
      QN.wangwang.invoke({
        category: 'wangwang',
        cmd: 'chat',
        param: {
            'uid': 'cntaobao' + nick
        },
        success: function(rsp) {
            if (!Tools.isEmpty(content)) {  //content非空时才能插入文字否则报错
              //插入文本
              QN.wangwang.invoke({
                  category: 'wangwang',
                  cmd: 'insertText2Inputbox',
                  param: {
                      'uid': 'cntaobao' + nick,
                      'text': content,
                      'type': 0
                  },
                  success: function(rsp) {
                      if (callback) {
                        callback(rsp);
                      } else {

                      }
                  },
                  error: function(msp) {
                      ErrorDialog('温馨提示','登录失效，请重新打开插件！',JSON.stringify(msp));
                  }
              });
            } else {

            }
        },
        error: function(msp) {
            ErrorDialog('温馨提示','登录失效，请重新打开插件！',JSON.stringify(msp));
        }
      });
    } else {
        var info = '';
        var os = navigator.platform;
        var userAgent = navigator.userAgent;
        if (os.indexOf('Win') > -1) {
            if (userAgent.indexOf('Windows NT 5.0') > -1) {
                info += 'Win2000';
            } else if (userAgent.indexOf('Windows NT 5.1') > -1) {
                info += 'WinXP';
            } else if (userAgent.indexOf('Windows NT 5.2') > -1) {
                info += 'Win2003';
            } else if (userAgent.indexOf('Windows NT 6.0') > -1) {
                info += 'WindowsVista';
            } else if (userAgent.indexOf('Windows NT 6.1') > -1 || userAgent.indexOf('Windows 7') > -1) {
                info += 'Win7';
            } else if (userAgent.indexOf('Windows 8') > -1 || userAgent.indexOf('Windows NT 6.2') > -1) {
                info += 'Win8';
            } else if (userAgent.indexOf('Windows NT 6.3') > -1) {
                info += 'Win8.1';
            } else {
                info += 'Other';
            }
        } else if (os.indexOf('Mac') > -1) {
            info += 'Mac';
        } else if (os.indexOf('X11') > -1) {
            info += 'Unix';
        } else if (os.indexOf('Linux') > -1) {
            info += 'Linux';
        } else {
            info += 'Other';
        }
        var content = '电脑系统【' + info + '】_插件应用：【爱用交易管理2.5.x】_PC千牛新版本：【';
        api({
            method:'/iytrade2/getchatnick',
            mode:'jsonp',
            callback:(rsp)=>{
                if (rsp == 'fail') return false;
                QN.application.invoke({
                    cmd: 'getVersion',
                    success: function(e) {
                        if (typeof e === 'string') {
                            e = JSON.parse(e);
                        }
                        content = content + e.version + '】';
                        Tools.ww({
                          nick:rsp,
                          content:content
                        });
                    }
                });
            }
        })
    }
  },
  beacons:function(exparams){
      let h = (t, e)=>{
          return t && t.getAttribute ? t.getAttribute(e) || "": ""
      }
      var beacon = document.getElementById("ay-beacon");
      if(exparams === undefined || exparams === '' || exparams === null){
          exparams = h(beacon, "exparams");
      }
      if(exparams === undefined || exparams === '' || exparams === null){
          return;
      }else{
          var n = new Image;
          var url = "//mcs.aiyongbao.com/1.gif" + "?t="  + new Date().getTime() + "&" + exparams;
          n.src=url;
      }
      return;
  },
  /**
   * 埋点方法
   * author: cbl
   * @param  {[type]} ProjectCode   [项目id]
   * @param  {[type]} EventCode     [事件id]
   * @param  {[type]} UserNick      [nick]
   * @param  {[type]} pid           [description]
   * @param  {[type]} creative_name [description]
   * @param  {[type]} open_cid      [description]
   * @return {[type]}               [description]
   */
  beacon:function(ProjectCode,EventCode,UserNick,pid=undefined,creative_name=undefined,open_cid=undefined){

    //   let url = '//mcs.aiyongbao.com/1.gif?t=' + (new Date).getTime() + '&p=' + ProjectCode + '&n=' + encodeURIComponent(UserNick) + '&e=' + EventCode;
      let url = 'p=' + ProjectCode + '&n=' + encodeURIComponent(UserNick) + '&e=' + EventCode;

      //如果含有推广位埋点信息，则打入
      if(pid){
        let c_name=creative_name;
        url+='&m1='+pid+'&m2='+c_name+'&m3='+open_cid;
      }
      url+='&m4='+'pc';

      this.beacons(url)
    //   fetch(url, {
    //       method: 'POST',
    //       mode: 'cros',
    //       credentials: 'include'
    //   })
    //   .then(response => {
    //         // console.log('埋点成功',ProjectCode,EventCode,response.code);
    //   })
    //   .catch(error => {
    //         // console.log('埋点失败',ProjectCode,EventCode,error);
    //   });
  },
  tradeLoading:function(time = 500, text = "订单数据加载中，请稍后", type = 1){
      let element = document.getElementById("c-loading-trade");
      if(this.isEmpty(element)){
          let html =`<div id="c-loading-trade" >
              <div style="background: #000;position: fixed;width: 100%;height: 100%;top: 0;left: 0;z-index: 1001;transition: opacity .3s;opacity: 0.05;"></div>
              <div  style="position: fixed;right: 40%;bottom: 45%;z-index:999999;margin-right:10px;padding: 20px;background-color: white;">
                  <div>
                  <img src = "//q.aiyongbao.com/trade/img/loading.gif" style="margin-right:10px;vertical-align: middle;"/>
                  <font style="vertical-align: middle;color:#999">${text}</font>
                  </div>
              </div>
          </div>`;
          let div = document.createElement('div');
          div.innerHTML = html;
          document.getElementById('container').appendChild(div);
          setTimeout(()=>{
              let elements = document.getElementById("c-loading-trade");
              if(elements) elements.parentNode.removeChild(elements);
          },time)
      }
  },
  loading:function(state,text = "订单数据加载中，请稍后",type = 1){
      let element = document.getElementById("c-loading");
      if(state == 'show'){
          if(this.isEmpty(element)){
              let html =`<div id="c-loading" style="display:none">
                  <div style="background: #000;position: fixed;width: 100%;height: 100%;top: 0;left: 0;z-index: 1001;transition: opacity .3s;opacity: 0.05;"></div>
                  <div  style="position: fixed;right: 40%;bottom: 45%;z-index:999999;margin-right:10px;padding: 20px;background-color: white;">
                      <div>
                      <img src = "//q.aiyongbao.com/trade/img/loading.gif" style="margin-right:10px;vertical-align: middle;"/>
                      <font style="vertical-align: middle;color:#999">${text}</font>
                      </div>
                  </div>
              </div>`;
              if(type == 0) html = `<div id="c-loading" style="display:none;position: fixed;right: 40%;bottom: 45%;z-index: 999999;margin-right:10px;"><img src = "//q.aiyongbao.com/trade/img/loading.gif" style="margin-right:10px;vertical-align: middle;"/><font style="vertical-align: middle;color:#999">${text}</font></div>`;
              let div = document.createElement('div');
              div.innerHTML = html;
              document.getElementById('container').appendChild(div);
              iTime = setTimeout(function(){
                  try{
                      document.getElementById("c-loading").style.display = "block";
                  }catch(e){
                  }
                  setTimeout(()=>{
                      let element = document.getElementById("c-loading");
                      if (iTime !="")clearTimeout(iTime);
                      if(element) element.parentNode.removeChild(element);
                  },5000)
              },600);

          }

      }else{
          if (iTime !="")clearTimeout(iTime);
          if(element) element.parentNode.removeChild(element);

      }
  },
  copy:function(text,ishowSuccess = undefined){
      workbench.platform.clipboard.setData(0, text);
      if (ishowSuccess) {
        MsgToast('success','复制成功！',1000,'18px');
      } else {

      }
  }
};
// export const ajax = Tools.ajax.bind(Tools)
export const api = Tools.api.bind(Tools);
export const ww = Tools.ww.bind(Tools);
export const beacon = Tools.beacon.bind(Tools);
export const nameSpace = Tools.namespace.bind(Tools);
export const qnapi = Tools.qnapi.bind(Tools);
export const getUserInfo = Tools.getUserInfo.bind(Tools);
export const confirmUserInfo = Tools.confirmUserInfo.bind(Tools);
export const isEmpty = Tools.isEmpty.bind(Tools);
export const loading = Tools.loading.bind(Tools);
export const tradeLoading = Tools.tradeLoading.bind(Tools);
export const getUrlParam = Tools.getUrlParam.bind(Tools);
export const getServerTime = Tools.getServerTime.bind(Tools);
export default Tools;
