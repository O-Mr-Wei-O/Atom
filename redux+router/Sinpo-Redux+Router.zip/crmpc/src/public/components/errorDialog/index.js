import {Dialog} from 'qnui';
import ErrorDialogFooter from './errorDialogFooter'
import './index.scss';

/**
 * 失败弹窗
 *  title 传入的标题 string 必须
 *  content 显示的内容 any 必须
 *  error 错误内容 string 可空
 * @author zdh
 */

function ErrorDialog(title,content,error){
    const dialog = Dialog.alert({
        needWrapper: false,
        content: "",
        title: "",
        autoFocus:false,
        footer: <ErrorDialogFooter title={title} content={content} error={error} closeDialog={()=>{dialog.hide();}}/>
    });
}


export default ErrorDialog;
