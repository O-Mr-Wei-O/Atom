import {Feedback,Icon,Dialog} from 'qnui';
import './index.scss';
import fetchJsonp from 'fetch-jsonp';

/**
 * 成功弹窗
 *  type 类型 success error
 *  text 显示内容
 *  time 存在时间，单位毫秒，0时不消失
 *  fontSize  提示内容过多用其控制字体大小  正常传 18px
 *  pid 广告id
 * @author zdh
 */

function MsgToast(type,text,time,fontSize,pid){
    let showIcon = null;
    switch (type) {
        case 'success':
            showIcon = (<Icon style={{color:'#5ECD37'}} size="xl" type="success" />);
            break;
        case 'error':
            showIcon = (<Icon style={{color:'#FF0000'}} size="xl" type="error" />);
            break;
        default:

    }

    if(pid){
        // let did = "913181696";
        // let imei = "00000";
        //
        // let url ='https://oa-panther.data.aliyun.com/get_creative?pid='+pid+'&did='+did+"&n=10&nf=1&mo=PC&IMEI="+imei+"&rs=0&f=creative_name,creative_id,category,user_define";
        //
        //
        // fetch(url,{
        //     dataType: 'jsonp',
    	// 	jsonp: "cb",
    	// 	jsonpCallback : "__"+new Date().getTime(),
    	// 	cache:true,
        //     mode:"no-cors"
        // })
        // .then((response) => {
        //     debugger;
        //     return response.json();
        // })//返回数据类型json
        // .then((responseText) => {
        //     console.log(responseText);
        // })
        // .catch((error) => {
        //     console.log(error);
        // });


        Feedback.toast.success({
            content: (
                <div className="msg-toast-ad-con-div">
                    <div className="msg-toast-ad-toast">
                        <div className="msg-toast-ad-toast-div">
                            <div className="msg-toast-ad-toast-content">
                                {showIcon}
                                 <font style={{fontSize:fontSize}} className="msg-toast-ad-toast-content-right-font">
                                     {text}
                                 </font>
                             </div>
                        </div>
                    </div>
                    <img className="msg-toast-ad-img" width={300} height={160} src="https://img.alicdn.com/bao/uploaded/i2/552522139/TB2F9YLbXXXXXb4XpXXXXXXXXXX_!!552522139.jpg_300x300.jpg" alt=""/>

                    <div className="msg-toast-hook-div" >
                        <img className="msg-toast-hook-left" width={8} height={42} src="//q.aiyongbao.com/trade/img/pc_toast_hook.png" alt=""/>

                        <img className="msg-toast-hook-right" width={8} height={42} src="//q.aiyongbao.com/trade/img/pc_toast_hook.png" alt=""/>
                    </div>

                    <div className="msg-toast-icon" onClick={()=>{
                        Feedback.toast.hide();
                    }}>
                        <svg className="icon-chushaixuanxiang">
                            <use xlinkHref="#icon-chushaixuanxiang"></use>
                        </svg>
                    </div>

                </div>
            ),
            duration: 0,
            hasMask:true
        });
    }else {
        Feedback.toast.success({
            content: (
                <div className="msg-toast-con-div">
                        {showIcon}
                        <font style={{fontSize:fontSize}} className="msg-toast-con-right-font">
                            {text}
                        </font>
                </div>
            ),
            duration: time
        });
    }




}


export default MsgToast;
