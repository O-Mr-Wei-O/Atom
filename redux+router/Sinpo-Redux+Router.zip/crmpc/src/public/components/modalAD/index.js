import {Dialog} from 'qnui';
import ADDialog from './adDialog'
import SurePayDialog from './surePayDialog'
import './index.scss';
import fetchJsonp from 'fetch-jsonp';
import {isEmpty,ww,beacon} from 'utils'
import moment from 'moment'

function ModalAD(pid,group,deaconObj = []){
    pid=pid?pid:'727';
    let did='913181696';
    let payUrl='';				//支付宝支付链接
    let isSubuser=false;		//是否子账号
    let groupName='';			//订购商品类别
	let successImageUrl='';		//订购成功图片url
	let typeText=userInfo.vipFlag==1?"续费":"升级";

    if(group==1){
		groupName="交易";
		successImageUrl="http://q.aiyongbao.com/trade/web/images/ad-trade-success.png";
	}else if(group==2){
		groupName="商品";
		successImageUrl="http://q.aiyongbao.com/trade/web/images/ad-item-success.png";
	}

    let url ='https://oa-panther.data.aliyun.com/get_creative?pid='+pid+'&did='+did+"&n=10&nf=1&mo=PC&IMEI="+userInfo.userId+"&rs=0&f=creative_name,creative_id,category,user_define";


    fetchJsonp(url,{
        jsonpCallback:'cb'
    })
    .then((response) => {
        return response.json();
    })//返回数据类型json
    .then((result) => {
        /*兜底广告*/
		if(result.status!="200"){
			result={results:[{
				'img_path':'http://q.aiyongbao.com/trade/web/images/Intelligence.png',
				'creative_name':'兜底创意',
				'user_define':'{"body":{"service":"618大促】现在订购立享优惠 ，点击【URL】 即可订购","type":"iphone","re-button":"4","btn1-text":"52元/季度","btn1-url":"https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170630195953;agentId:fuwu.taobao.com|marketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002030739]&subParams=cycleNum:3,cycleUnit:2,itemCode:FW_GOODS-1827490-v2&sign=4035B88340D2BD759D9CAAC8430B47BC","btn2-text":"138/年","btn2-url":"https://fuwu.taobao.com/ser/confirmOrder.htm?&commonParams=activityCode:ACT_877021141_170630195953;agentId:fuwu.taobao.com|marketing-0;marketKey:FWSPP_MARKETING_URL;promIds:[1002030739]&subParams=cycleNum:12,cycleUnit:2,itemCode:FW_GOODS-1827490-v2&sign=F5ECA56F1C6AC7400A122887C2B53089","coupon-flag":"0","subuser":"我要订购，需要主账号才能订购，帮我订下，点击链接即可：【URL】","ad-text":"升级高级版","button-image":""}}'
			}]};
			deaconObj=['TD20170614170642','zdtcdjmd','兜底创意'];
		}

        let {imgPath,btnGroup,adText,couponFlag,reButton,buttonImage,subuser,creativeName,creativeId } = initModalAD(result,pid);
        imgPath = imgPath.replace(/https:||http:/,"");

        /*子账号判断*/
        if(!isEmpty(userInfo.subUserNick)){
            isSubuser = true;
        }

        let loginUserNick;/*登录的userNick*/
        if(userInfo.subUserNick){
            loginUserNick = userInfo.subUserNick;
        }else {
            loginUserNick = userInfo.userNick;
        }

        /*优惠券判断*/
        if(couponFlag=='1'){
            console.log("discount");
        }else{
            let adDialog = Dialog.alert({
                needWrapper: false,
                content: "",
                title: "",
                autoFocus:false,
                footer: <ADDialog adBeacon={()=>{
                    if(isEmpty(deaconObj)){
                        beacon(deaconObj[0],deaconObj[1],loginUserNick,pid,creativeName,creativeId);
                    }

                }} feedbackClicked={(payUrl)=>{
                    feedbackClicked(result,creativeId,pid,payUrl);
                }} wangwangPCModalAD={wangwangPCModalAD} clickPay={(clickPay,isSubuser,subuser,btnUrl)=>{
                    let surePayDialog = Dialog.alert({
                        needWrapper: false,
                        content: "",
                        title: "",
                        autoFocus:false,
                        footer: <SurePayDialog clickPay={clickPay} isSubuser={isSubuser} subuser={subuser} btnUrl={btnUrl} wangwangPCModalAD={wangwangPCModalAD} successImageUrl={successImageUrl} groupName={groupName} typeText={typeText} vipDate={vipDate} adDialog={adDialog} closeDialog={()=>{surePayDialog.hide();}}/>
                    });
                }} imgPath={imgPath} adText={adText} btnGroup={btnGroup} creativeId={creativeId} creativeName={creativeName} pid={pid} groupName={groupName} reButton={reButton} buttonImage={buttonImage} subuser={subuser} isSubuser={isSubuser} closeDialog={()=>{adDialog.hide();}}/>
            });
        }
    })
    .catch((error) => {
    });





}

/**
 * 初始化订购页面
 * @author zdh
 * @dateTime 2017-08-13T12:45:46+080
 * @param    {[type]}                result [description]
 * @param    {[type]}                pid    [description]
 * @return   {[type]}                       [description]
 */
function initModalAD(result,pid){
    let adNum=vipDate('adNum',pid,result.results.length);/*选取广告*/
	let res=result.results[adNum];

	let	userDefine=JSON.parse(res.user_define).body;
	let	reButton=userDefine["re-button"];
    let rebtn=reButton;
	let	btnGroup=[];

    for(let i=1;i<=4;i++){
		let btnText=userDefine['btn'+i+'-text'];
		let btnUrl=userDefine['btn'+i+'-url'];
        if(btnText){
            btnGroup.push({btnText:btnText,btnUrl:btnUrl});
        }else{
			if(reButton>i){
				rebtn--;
			}else if(reButton==i){
				rebtn=0;
			}
        }
	}
	reButton=rebtn;

    let obj={};
    obj.imgPath=res.img_path;
    obj.adText=userDefine["ad-text"];
    obj.btnGroup=btnGroup;
    obj.reButton=reButton-1;
    obj.subuser=userDefine["subuser"];
	obj.creativeName=res.creative_name;
	obj.creativeId=res.creative_id||'';
	obj.buttonImage=userDefine["button-image"];
	feedbackShowed(result,adNum,pid);
    return obj;
}

/**
 * 判断是否为今日成功付费用户
 *
 */
function vipDate(type,pid,length){
    pid=pid?pid:'000';
    length=length?length:1;
    let loginUserNick;/*登录的userNick*/
    if(userInfo.subUserNick){
        loginUserNick = userInfo.subUserNick;
    }else {
        loginUserNick = userInfo.userNick;
    }

    //日期计算从当日6:00am-次日6:00am为一天
    let now_hour = moment().hour();
    let now;
    if(now_hour>=0&&now_hour<6){/*前一天*/
        now = moment().subtract(1, 'days').format("l");
    }else {
        now = moment().format("l");
    }

    if(type=='save'){       	// 写入付费成功日期
        localStorage.setItem("vipDate"+loginUserNick,now);
        return;
    }else if(type=='get'){   	// 判断是否为免广告日
        let vipDate=localStorage.getItem("vipDate"+loginUserNick);
        if(typeof vipDate!='undefined'&&vipDate!=null){
            if(moment(now).isSame(vipDate)){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }else if(type=='adNum'){	// A/B广告选择
        let adNum=localStorage.getItem("adNum"+loginUserNick+pid);
        if(typeof adNum!='undefined'&&adNum!==null){
            adNum=JSON.parse(adNum);
            let adNumDate = adNum.date;
            if(moment(now).isSame(adNumDate)){
                return adNum.number;
            }
        }
        let randomNum=Math.floor(Math.random()*length);
        localStorage.setItem("adNum"+loginUserNick+pid,JSON.stringify({date:now,number:randomNum}));
        return randomNum;
    }
}

/**
 * 呼出旺旺
 * @author zdh
 * @dateTime 2017-08-14T17:38:37+080
 * @param    {string}                content 发送内容
 * @param    {int}                type    发送对象  0 主账号  1 客服
 * @return   {[type]}                        [description]
 */
function wangwangPCModalAD(content,type){
    let nick='';
    if(type==0){
        nick = userInfo.userNick;
    }else{
        nick = '爱用科技';
    }
    ww({nick:nick,content:content});
}


function feedbackShowed(result,adNum,pid){
	if(result.open_id){
		var open_id=result.open_id;
		var open_cid=result.results[adNum].creative_id;
	}else{
		return;
	}
  	feedback(open_id,open_cid,userInfo.userId,1,pid);
}

function feedbackClicked(result,open_cid,pid,url){
	if(result.open_id){
		var open_id=result.open_id;
		feedback(open_id,open_cid,userInfo.userId,2,pid,url);
	}else{
		return;
	}
}
window.callbacksAd = (json) =>{}
function feedback(open_id, open_cid, imei, type,pid, url) {
	url=url||'';

	let feedbackUrl = 'https://oa-markhor.data.aliyun.com/feedback?open_id=' + open_id + '&open_cid=' + open_cid + '&type=' + type + '&imei=' + imei+'&pid='+pid+'&cb=callbacksAd';
	if (url){
		feedbackUrl += '&url=' + encodeURIComponent(url);
	}

    fetchJsonp(feedbackUrl,{

    })
    .then((response) => {
        return response.json();
    })//返回数据类型json
    .then((result) => {

    })
    .catch((error) => {

    });

}



export default ModalAD;
