import React from 'react';
import {Button} from 'qnui';

class PayFailDialog extends React.Component {
    constructor(props) {
        super(props);

    }

    payMoneyAgainByFail(){
        const {closeDialog,clickPay,isSubuser,subuser,btnUrl,wangwangPCModalAD} = this.props;
        closeDialog();

        // ModalAD(pid,group);

        let subuserStr = subuser;
        clickPay(clickPay,isSubuser,subuser,btnUrl);
        /*判断子账号*/
        if(isSubuser){
            subuserStr=subuserStr.replace("【URL】",btnUrl);
            wangwangPCModalAD(subuserStr,0);
        }else{
            /*跳转支付宝*/
            window.open(btnUrl);
        }
        // beaconAD(deaconObj[0],deaconObj[1],pid,obj.creative_name,obj.creative_id);
        // feedbackClicked(result,obj.creative_id,pid,payUrl);
    }

    render(){
        const {closeDialog,title,lxkf} = this.props;
        return (
            <div className="modal-ad-div">
                <div className="modal-ad-for-center">
                    <div className="pay-fail-dialog-div">
                        <span onClick={closeDialog} className="icon-cancel-span">
                            <svg className="ad-icon-cancel">
                                <use xlinkHref="#icon-cancel"></use>
                            </svg>
                        </span>
                        <div className="pay-fail-dialog-div-head">
                            <svg className="pfd-icon-cancel">
                                <use xlinkHref="#icon-cancel"></use>
                            </svg>
                            <span className="pay-fail-dialog-div-head-span">
                                {title}
                            </span>
                        </div>
                        <div className="pay-fail-dialog-div-body">
                            <div className="pay-fail-dialog-div-body-title">
                                尊敬的用户，您可能在支付过程中遇到以下问题：
                            </div>
                            <div className="pay-fail-dialog-div-body-div">
                                <div className="pay-fail-dialog-div-body-item">
                                    1.您的支付宝余额不足，建议您先对您的支付宝账户进行充值，完成后再重新支付。
                                </div>
								<div className="pay-fail-dialog-div-body-item">
                                    2.您的手机或电脑与支付宝的网络通讯暂时不通，遇到此情况，建议您检查网络后再重新支付。
                                </div>
								<div className="pay-fail-dialog-div-body-item">
                                    3.如遇到支付宝已扣款，但订单状态仍显示“待付款”？这可能是银行网络传输发生故障或延时造成的，淘宝会在2个工作日内恢复金额，请耐心等待。
                                </div>
								<div className="pay-fail-dialog-div-body-item">
                                    4.如遇“校验错误”，可能是您有“待付款”的订单，请先完成付款，或关闭订单后重新订购。
                                </div>
                                <div>
                                    5.如果问题仍不能解决，请联系客服。
                                </div>
                            </div>
                        </div>
                        <div className="pay-fail-dialog-div-foot">
                            <Button onClick={this.payMoneyAgainByFail.bind(this)} style={{fontSize: "16px"}} size="large" type="primary">重新支付</Button>
                            <Button onClick={lxkf} style={{fontSize: "16px",marginLeft: "100px"}} size="large" type="secondary">联系客服</Button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default PayFailDialog;
