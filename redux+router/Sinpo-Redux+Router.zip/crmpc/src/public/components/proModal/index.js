import React from 'react';
import {Dialog,Progress} from 'qnui';
import './index.scss';

/**
 * 进度条组件
 *  visible 控制进度条弹窗显示
 *  title 标题
 *  finish 完成的数量
 *  total 总数量
 *  foot 自定义进度文本
 *  用法 当需要显示进度是 在操作开始时 设置visible为true 显示进度条弹窗 设置total设置进度总量，在执行过程中通过state修改finish来显示进度，当任务完场时通过设置visible为false来关闭进度条弹窗
 * @author zdh
 */

class ProModal extends React.Component {
    constructor(props) {
        super(props);
    }
    render(){
        const {visible,title,finish,total,foot} = this.props;
        let percent = parseInt(((finish/total)*100).toFixed(0));
        return (
            <Dialog className="pro-modal" visible={visible} closable={false} footer={false}>
                <div className="pro-modal-head">{title}</div>
                <Progress percent={percent} size="large" showInfo={false}/>
                <div className="pro-modal-foot">{foot}</div>
            </Dialog>
        );
    }
}

export default ProModal;
