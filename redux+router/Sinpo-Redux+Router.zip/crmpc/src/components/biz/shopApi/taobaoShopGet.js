import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';
/**
 * 获取卖家店铺的基本信息
 * @param  {[type]}   query       查询字段
 * @param  {Function} callback    成功之后的回调函数
 * @param  {[Function]}   errCallback 失败之后的回调函数
 */
function taobaoShopGet({query,callback,errCallback=undefined}){
    qnapi({
        api:'taobao.shop.get',
        params:query,
        callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','获取卖家店铺的基本信息失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}
export  default taobaoShopGet;