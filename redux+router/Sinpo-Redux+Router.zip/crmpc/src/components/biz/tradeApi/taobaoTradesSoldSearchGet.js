import {isEmpty} from 'utils/index';
import WebSql from 'components/biz/webSql/index';

/**
 * [taobao.trades.sold.get]
 * @param  {[type]}  options.query        [description]
 * @param  {[type]}  options.callback     [description]
 * @param  {[type]}  options.errCallback  [description]
 * @param  {Boolean} options.forceRefresh [默认为false  为websql做容错如果 websql出了问题 会在调一次这个强制去取淘宝数据]
 * @return {[type]}                       [description]
 */
function taobaoTradesSoldSearchGet({query,callback,errCallback=undefined,forceRefresh = false,getIncrementGet = true}){
    // console.log(query);
    let search = query.search;
    let page_no = query.page_no;
    let page_size = 100;//query.page_size;
    let where = '';
    if(!isEmpty(search.userKey) && !(!isNaN(search.userKey) && search.userKey.length > 15)){  //买家昵称
        where += " and buyer_nick like '%" + search.userKey + "%'";
    }
    if(!isEmpty(search.babyKey)){//宝贝关键词
        where += "and tid in (SELECT tid FROM subOrder WHERE  title like '%"+ search.babyKey +"%')";
    }
    if(!isEmpty(search.name)){//收件人姓名
        where += " and receiver_name like '%"+ search.name +"%'"
    }
    if(!isEmpty(search.phone)){//收件人手机或者电话
        where += " and (receiver_mobile like '%"+ search.phone +"%' OR receiver_phone like '%"+ search.phone +"%')"
    }
    if(!isEmpty(search.addrKey)){//收件地址关键字
        where += " and (receiver_address like '%"+ search.addrKey +"%' OR receiver_city like '%"+ search.addrKey +"%' OR receiver_district like '%"+ search.addrKey +"%' OR receiver_state like '%"+ search.addrKey +"%')"
    }
    if(!isEmpty(search.waybillNum)){//运单号
        where += "and tid in (SELECT tid FROM subOrder WHERE  invoice_no like '%"+ search.waybillNum +"%')";
    }





    if(search.memo == '1'){//留言情况
        where += " and has_buyer_message = 'true'";
    }else if(search.memo == '0'){
        where += " and has_buyer_message <> 'true'";
    }
    if(search.remarkFlag.length > 0 && search.remarkFlag.length < 6){//筛选备注旗帜情况
        where += " and seller_flag in (" + search.remarkFlag.join(',') + ")";
    }else if(search.remark == '1'){//筛选备注情况
        where += " and seller_flag <> '0'";
    }else if(search.remark == '0'){
        where += " and seller_flag == '0'";
    }

    if(query.end_created){//下单时间
        where += ` and (created > '${query.start_created}' and created < '${query.end_created}') `;
    }

    if(!isEmpty(search.addr) ){//地区筛选
        let subWhere = '(';
        search.addr.map(c => {
            if(c == '江浙沪'){
                if(subWhere == '('){
                    subWhere += `receiver_state ='浙江省' or receiver_state = '上海' or receiver_state = '江苏省'`
                }else{
                    subWhere += `or receiver_state ='浙江省' or receiver_state = '上海' or receiver_state = '江苏省'`
                }
            }else if(c == '珠三角'){
                if(subWhere == '('){
                    subWhere += ` receiver_city ='广州市' or receiver_city = '深圳市' or receiver_city = '佛山市' or receiver_city = '东莞市' or receiver_city = '中山市' or receiver_city = '珠海市' or receiver_city = '江门市' or receiver_city = '肇庆市' or receiver_city = '惠州市'`;
                }else{
                    subWhere += ` or receiver_city ='广州市' or receiver_city = '深证市' or receiver_city = '佛山市' or receiver_city = '东莞市' or receiver_city = '中山市' or receiver_city = '珠海市' or receiver_city = '江门市' or receiver_city = '肇庆市' or receiver_city = '惠州市'`;
                }

            }else if(c == '京津冀'){
                if(subWhere == '('){
                    subWhere += `receiver_state ='北京' or receiver_state = '天津' or receiver_state = '河北省'`
                }else{
                    subWhere += `or receiver_state ='北京' or receiver_state = '天津' or receiver_state = '河北省'`
                }
            }else if(c == '东三省'){
                if(subWhere == '('){
                    subWhere += `receiver_state ='辽宁省' or receiver_state = '吉林省' or receiver_state = '黑龙江省'`
                }else{
                    subWhere += `or receiver_state ='辽宁省' or receiver_state = '吉林省' or receiver_state = '黑龙江省'`
                }
            }else if(c == '港澳台'){
                if(subWhere == '('){
                    subWhere += `receiver_state ='香港特别行政区' or receiver_state = '澳门特别行政区' or receiver_state = '台湾'`
                }else{
                    subWhere += `or receiver_state ='香港特别行政区' or receiver_state = '澳门特别行政区' or receiver_state = '台湾'`
                }
            }else{
                if(subWhere == '('){
                    subWhere += `receiver_state ='${search.addr}'`
                }else{
                    subWhere += `or receiver_state ='${search.addr}'`
                }
            }
        })
        if(subWhere != '(') where += 'and '+subWhere + ')';

    }
    if(search.searchType == 'dfh'){
        query.status = "WAIT_SELLER_SEND_GOODS' OR status = 'SELLER_CONSIGNED_PART";
    }else if (search.searchType == 'yfh'){
        query.status = "WAIT_BUYER_CONFIRM_GOODS";
    }else{
        query.status = "";
    }
    let limit = 'LIMIT ? OFFSET ?';
    let param = [page_size, (page_no - 1) * page_size];//翻页器
    switch (search.orderType) {
        case '1'://普通订单
            if(query.status == "WAIT_SELLER_SEND_GOODS' OR status = 'SELLER_CONSIGNED_PART"){
                query.status = 'WAIT_SELLER_SEND_GOODS';
            }
            where += ` and type != 'cod'`;
        break;
        case '2'://货到付款
            where += ` and type = 'cod'`;
        break;
        case '3':
            query.status = 'SELLER_CONSIGNED_PART';
        break;
        case '4'://退款订单不需要翻页
            limit = 'LIMIT 1 OFFSET 10000';
            param = [];
        break;
        default:

    }

    if(search.kdPrint == '1'){
         where += ` and tid in (${window.printState.couriers})`;
    }else if(search.kdPrint == '0'){
        where += ` and tid not in (${window.printState.couriers})`;
    }

    if(search.willPrint == '1'){
         where += ` and tid in (${window.printState.invoices})`;
    }else if(search.willPrint == '0'){
        where += ` and tid not in (${window.printState.invoices})`;
    }

    if(search.sendPrint == '1'){
         where += ` and tid in (${window.printState.surfaces})`;
    }else if(search.sendPrint == '0'){
        where += ` and tid not in (${window.printState.surfaces})`;
    }
    if(!isEmpty(query.status)){
        where = `(status = '${query.status}') ${where}`;
    }else{
        where = search.orderType == 1 ?  `(status <> 'SELLER_CONSIGNED_PART') ${where}` : `(status <> '') ${where}`
    }







    let countSql = `SELECT COUNT(tid) AS total FROM trade WHERE ${where}`;
    // console.log(countSql);

    WebSql.tradeSearch({//先获取结果总数
        query:countSql,
        param:[],
        callback:(rsp)=>{
            let total_results = rsp.rows[0].total;
            let results = {
                trades_sold_get_response:{
                    total_results: total_results
                }
            }
            if(total_results == 0){
                callback(results);
            }else{
                let sql = `SELECT * FROM trade WHERE  ${where} ORDER BY created desc ${limit}`;
                WebSql.tradeSearch({//获取主订单数据
                    query:sql,
                    param:param,
                    callback:(rsp)=>{
                        let tradeResult = rsp.rows;
                        let tids = [];
                        let trades = [];//模拟的订单返回数组
                        for (let index in tradeResult) {
                            let trade = tradeResult[index];
                            if(trade.tid){
                                tids.push(trade.tid);
                                trades.push(trade);
                            }
                        }

                        let subSql = 'SELECT * FROM subOrder WHERE tid in (' + tids.join(',') + ') ';
                        WebSql.tradeSearch({//获取主订单数据
                            query:subSql,
                            param:[],
                            callback:(rsp)=>{
                                let orderResult = rsp.rows;
                                for (let trade of trades){   //循环组子订单
                                    let orders = [];
                                    for (let index in orderResult){
                                        let order = orderResult[index];
                                        if (order.tid == trade.tid) orders.push(order);
                                    }
                                    trade.orders = {
                                        order: orders
                                    }
                                }
                                if(search.orderType == '4'){//退款订单
                                    let dataSource = [];
                                    trades.map(c =>{
                                        for(let order of c.orders.order){
                                            if(order.refund_status == 'WAIT_SELLER_AGREE' || order.refund_status == 'WAIT_BUYER_RETURN_GOODS' || order.refund_status == 'WAIT_SELLER_CONFIRM_GOODS'){
                                                dataSource.push(c);
                                                break;
                                            }
                                        }
                                    })
                                    if(dataSource.length == 0 ){
                                        results.trades_sold_get_response.total_results = 0;
                                    }else{
                                        results.trades_sold_get_response.trades = {
                                            trade: dataSource
                                        }
                                    }
                                }else if(search.orderType == '1'){//普通订单
                                    let dataSource = [];
                                    trades.map(c =>{
                                        let noTkz = true;
                                        for(let order of c.orders.order){
                                            if(order.refund_status == 'WAIT_SELLER_AGREE' || order.refund_status == 'WAIT_BUYER_RETURN_GOODS' || order.refund_status == 'WAIT_SELLER_CONFIRM_GOODS'){
                                                noTkz = false;
                                                break;
                                            }
                                        }
                                        if(noTkz) dataSource.push(c);
                                    })
                                    results.trades_sold_get_response.trades = {
                                        trade: dataSource
                                    }
                                }else{
                                    results.trades_sold_get_response.trades = {
                                        trade: trades
                                    }
                                }
                                callback(results);
                            },
                            errCallback:(error)=>{
                                errCallback(error);
                            }
                        })
                    },
                    errCallback:(error)=>{
                        errCallback(error);
                    }
                })
            }
        },
        errCallback:(error)=>{
            errCallback(error);
        }
    })

}

export default taobaoTradesSoldSearchGet;
