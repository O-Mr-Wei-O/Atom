import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';
import WebSql from 'components/biz/webSql/index';
import moment from 'moment';

let defaultFields   = 'modified,timeout_action_time,end_time,pay_time,consign_time,rate_status,seller_nick,shipping_type,cod_status,orders.oid,orders.oid_str,orders.outer_iid,orders.outer_sku_id,orders.consign_time,tid,tid_str,status,end_time,buyer_nick,trade_from,credit_card_fee,buyer_rate,seller_rate,created,num,payment,pic_path,has_buyer_message,receiver_country,receiver_state,receiver_city,receiver_district,receiver_town,receiver_address,receiver_zip,receiver_name,receiver_mobile,receiver_phone,orders.timeout_action_time,orders.end_time,orders.title,orders.status,orders.price,orders.payment,orders.sku_properties_name,orders.num_iid,orders.refund_id,orders.pic_path,orders.refund_status,orders.num,orders.logistics_company,orders.invoice_no,seller_flag,type,post_fee,is_daixiao,has_yfx,yfx_fee,buyer_message,buyer_flag,buyer_memo,seller_memo,orders.seller_rate,orders.cid,service_orders.tmser_spu_code';
let defaultType     = 'tmall_i18n,fixed,auction,guarantee_trade,step,independent_simple_trade,independent_shop_trade,auto_delivery,ec,cod,game_equipment,shopex_trade,netcn_trade,external_trade,instant_trade,b2c_cod,hotel_trade,super_market_trade,super_market_cod_trade,taohua,waimai,nopaid,step,eticket,o2o_offlinetrade';
let defaultPageNo   = 1;
let defaultPageSize = 40;

function taobaoTradesSoldIncrementGet({query,callback,errCallback=undefined}){
    let querys = {};
    querys.fields    = query.fields ? query.fields : defaultFields;
    querys.type      = query.type ? query.type : defaultType;
    querys.page_no   = query.page_no ? query.page_no : defaultPageNo;
    querys.page_size = query.page_size ? query.page_size : defaultPageSize;
    querys.end_modified = query.end_modified ? query.end_modified : moment().format('YYYY-MM-DD HH:mm:ss');

    let lastIncrementGetTime = localStorage.getItem('lastIncrementGetTime_' + window.userInfo.userNick);

    if (lastIncrementGetTime && moment().diff(moment(lastIncrementGetTime, 'YYYY-MM-DD HH:mm:ss')) < 1800000) {  //小于30分钟  取最近半个小时的
        querys.start_modified = query.start_modified ? query.start_modified : moment().subtract(30, 'm').format('YYYY-MM-DD HH:mm:ss');
    } else if(moment().diff(moment(lastIncrementGetTime, 'YYYY-MM-DD HH:mm:ss')) < 21600000) { //不超过6小时
        querys.start_modified = query.start_modified ? query.start_modified : moment().subtract(6, 'h').format('YYYY-MM-DD HH:mm:ss');
    } else {  //重新拉数据
        localStorage.setItem('hasGetAll_' + window.userInfo.userNick,-10000);
        localStorage.setItem('lastIncrementGetTime_' + window.userInfo.userNick,querys.end_modified);
        return;
    }
    localStorage.setItem('lastIncrementGetTime_' + window.userInfo.userNick,querys.end_modified);
    querys.status = '';
    qnapi({
    	api:'taobao.trades.sold.increment.get',
    	params:querys,
    	callback:(rsp)=>{
            // console.error('taobao.trades.sold.increment.get  result')
            // console.log(rsp);
            let trades = [];
            let tids = [];
            if (rsp.trades_sold_increment_get_response.trades && rsp.trades_sold_increment_get_response.trades.trade) {  //有订单时才操作
              for (let trade of rsp.trades_sold_increment_get_response.trades.trade) {
                  if (trade.status == 'WAIT_SELLER_SEND_GOODS' || trade.status == 'WAIT_BUYER_CONFIRM_GOODS' || trade.status == 'SELLER_CONSIGNED_PART') {  // 要保存的订单
                      trades.push(trade);
                  } else {
                      tids.push(trade.tid);
                  }
              }
              callback(trades);
              //删除脏数据
              WebSql.orderDelete({
                  query:{
                    tid : tids
                  },
                  callback:(rsp)=>{
                  },
                  errCallback:(error)=>{  //删数据有问题了 出现脏数据了 下次重新拉数据吧
                      localStorage.setItem('hasGetAll_' + window.userInfo.userNick, -10000);
                  }
              })
              if (rsp.trades_sold_increment_get_response.total_results < query.page_no * query.page_size) {
                  // statement
              } else {
                  querys.page_no = query.page_no + 1;
                  taobaoTradesSoldIncrementGet({
                      query: querys,
                      callback:callback,
                      errCallback:errCallback
                  })
              }
            }

        },
        errCallback:(error)=>{
            if (errCallback) {
            	errCallback(error);
            } else {
              console.error(error);
            	ErrorDialog('温馨提示','获取订单失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoTradesSoldIncrementGet;
