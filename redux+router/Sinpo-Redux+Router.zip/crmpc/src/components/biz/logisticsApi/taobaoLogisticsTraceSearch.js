import { qnapi, isEmpty } from 'utils/index';
import moment from 'moment';
import ErrorDialog from 'publicComponents/errorDialog/index';

function taobaoLogisticsTraceSearch({query,callback,errCallback=undefined,reflsh = false}){
    let myTag = query.tid + 'logisticsTrace';               // 标识符
    // 区分是否拆单发货
    if (query.is_split && query.is_split*1 == 1 && query.sub_tid) {
        // 使用subtid唯一标识
        myTag = query.sub_tid.join('') + 'logisticsTrace';
    }
    let json    = localStorage.getItem(myTag);
    let nowDate = moment().format('YYYY-MM-DD');
    if (isEmpty(json) || reflsh) {
        qnapi({
            api:'taobao.logistics.trace.search',
            params:query,
            callback:(rsp)=>{
                json = {
                    modify     : nowDate,
                    dataSource : rsp
                };
                try{
                    localStorage.setItem(myTag, JSON.stringify(json));
                }catch(e){
                    console.warn('用户C盘可能已经满了，存储localStorage报错');
                }
                // console.log('请求数据', query);
                // console.log('接口结果', rsp);
                callback(rsp);
            },
            errCallback:(error)=>{
                if (errCallback) {
                    errCallback(error);
                } else {
                    ErrorDialog('温馨提示','物流流转信息查询失败，请稍候再试！',JSON.stringify(error));
                }
            }
        });
    } else {
        json = JSON.parse(json);
        if (nowDate != json.modify) {
        // if (nowDate - json.modify > 24 * 60 * 60 * 1000) {
            // 大于一天
            qnapi({
                api:'taobao.logistics.trace.search',
                params:query,
                callback:(rsp)=>{
                    json = {
                        modify     : nowDate,
                        dataSource : rsp
                    };
                    // 处理Failed to execute 'setItem' on 'Storage': Setting the value
                    try{
                        localStorage.setItem(myTag, JSON.stringify(json));
                    }catch(e){
                        console.warn('用户C盘可能已经满了，存储localStorage报错');
                    }
                    callback(rsp);
                },
                errCallback:(error)=>{
                    if (errCallback) {
                        errCallback(error);
                    } else {
                        ErrorDialog('温馨提示','物流流转信息查询失败，请稍候再试！',JSON.stringify(error));
                    }
                }
            });
        } else {
            callback(json.dataSource);
        }
    }
}

export default taobaoLogisticsTraceSearch;
