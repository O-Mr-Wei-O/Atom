import {qnapi} from 'utils/index';
import ErrorDialog from 'publicComponents/errorDialog/index';

//批量评价
function taobaoTraderateListAdd({query,callback,errCallback=undefined}){
    qnapi({
        api : 'taobao.traderate.list.add',
        params : {
            tid:query.tid,
            result: query.result,
            content: query.content,
            role:query.role,
            anony:query.anony
        },
       	callback:(rsp)=>{
            callback(rsp);
        },
        errCallback:(error)=>{
            if (errCallback) {
                errCallback(error);
            } else {
                ErrorDialog('温馨提示','批量评价失败，请稍候再试！',JSON.stringify(error));
            }
        }
    })
}

export default taobaoTraderateListAdd;
